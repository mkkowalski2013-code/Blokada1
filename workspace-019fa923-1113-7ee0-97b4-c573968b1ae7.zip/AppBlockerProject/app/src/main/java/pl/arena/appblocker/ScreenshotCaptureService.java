package pl.arena.appblocker;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.MediaStore;
import android.util.DisplayMetrics;
import android.view.WindowManager;

import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class ScreenshotCaptureService extends Service {
    public static final String ACTION_START = "pl.arena.appblocker.action.START_SCREENSHOTS";
    public static final String ACTION_STOP = "pl.arena.appblocker.action.STOP_SCREENSHOTS";
    public static final String EXTRA_RESULT_CODE = "result_code";
    public static final String EXTRA_RESULT_DATA = "result_data";
    public static final String EXTRA_INTERVAL_MIN = "interval_min";

    private static final int NOTIFICATION_ID = 9101;
    private static final String CHANNEL_ID = "appblocker_screenshots";

    private final Handler handler = new Handler(Looper.getMainLooper());
    private MediaProjection projection;
    private VirtualDisplay virtualDisplay;
    private ImageReader imageReader;
    private int width;
    private int height;
    private int density;
    private long intervalMs = 5L * 60_000L;
    private long nextCaptureAt = 0L;
    private boolean saving = false;

    @Override public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        startForeground(NOTIFICATION_ID, buildNotification("Monitor screenshotów czeka na zgodę"));
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            if (Prefs.isCuffsLocked(this)) {
                startForeground(NOTIFICATION_ID, buildNotification("Stop zablokowany przez różowe kajdanki · możesz cofnąć zgodę w ustawieniach Androida"));
                return START_STICKY;
            }
            stopSelf();
            return START_NOT_STICKY;
        }

        if (intent != null && ACTION_START.equals(intent.getAction())) {
            int minutes = intent.getIntExtra(EXTRA_INTERVAL_MIN, Prefs.getScreenshotIntervalMin(this));
            if (minutes < 2) minutes = 2;
            if (minutes > 20) minutes = 20;
            intervalMs = minutes * 60_000L;
            Prefs.setScreenshotIntervalMin(this, minutes);

            int resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0);
            Intent resultData = intent.getParcelableExtra(EXTRA_RESULT_DATA);
            startForeground(NOTIFICATION_ID, buildNotification("Monitor aktywny · co " + minutes + " min · Pictures/monitor"));
            startProjection(resultCode, resultData);
            return START_STICKY;
        }

        return START_STICKY;
    }

    private void startProjection(int resultCode, Intent resultData) {
        if (resultCode == 0 || resultData == null) {
            stopSelf();
            return;
        }

        stopProjectionOnly();

        try {
            MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
            if (mpm == null) throw new Exception("MediaProjectionManager null");
            projection = mpm.getMediaProjection(resultCode, resultData);
            if (projection == null) throw new Exception("MediaProjection null");

            projection.registerCallback(new MediaProjection.Callback() {
                @Override public void onStop() {
                    stopSelf();
                }
            }, handler);

            DisplayMetrics metrics = new DisplayMetrics();
            WindowManager wm = (WindowManager) getSystemService(WINDOW_SERVICE);
            if (wm != null) wm.getDefaultDisplay().getRealMetrics(metrics);
            else metrics = getResources().getDisplayMetrics();
            width = Math.max(1, metrics.widthPixels);
            height = Math.max(1, metrics.heightPixels);
            density = metrics.densityDpi;

            imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2);
            imageReader.setOnImageAvailableListener(reader -> handleImageAvailable(reader), handler);

            virtualDisplay = projection.createVirtualDisplay(
                    "AppBlocker screenshots",
                    width,
                    height,
                    density,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                    imageReader.getSurface(),
                    null,
                    handler
            );
            nextCaptureAt = System.currentTimeMillis() + 1200L;
        } catch (Exception e) {
            stopSelf();
        }
    }

    private void handleImageAvailable(ImageReader reader) {
        Image image = null;
        try {
            image = reader.acquireLatestImage();
            if (image == null) return;

            long now = System.currentTimeMillis();
            if (saving || now < nextCaptureAt) return;
            saving = true;
            nextCaptureAt = now + intervalMs;

            Bitmap bitmap = imageToBitmap(image);
            if (bitmap != null) {
                saveBitmap(bitmap);
                bitmap.recycle();
            }
        } catch (Exception ignored) {
        } finally {
            if (image != null) {
                try { image.close(); } catch (Exception ignored) { }
            }
            saving = false;
        }
    }

    private Bitmap imageToBitmap(Image image) {
        Image.Plane[] planes = image.getPlanes();
        if (planes == null || planes.length == 0) return null;
        ByteBuffer buffer = planes[0].getBuffer();
        int pixelStride = planes[0].getPixelStride();
        int rowStride = planes[0].getRowStride();
        int rowPadding = rowStride - pixelStride * width;
        int bitmapWidth = width + rowPadding / pixelStride;

        Bitmap padded = Bitmap.createBitmap(bitmapWidth, height, Bitmap.Config.ARGB_8888);
        padded.copyPixelsFromBuffer(buffer);
        Bitmap cropped = Bitmap.createBitmap(padded, 0, 0, width, height);
        padded.recycle();
        return cropped;
    }

    private void saveBitmap(Bitmap bitmap) {
        String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
        String name = "appblocker_" + stamp + ".png";

        OutputStream out = null;
        Uri uri = null;
        try {
            ContentResolver resolver = getContentResolver();
            ContentValues values = new ContentValues();
            values.put(MediaStore.Images.Media.DISPLAY_NAME, name);
            values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
            if (Build.VERSION.SDK_INT >= 29) {
                values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/monitor");
                values.put(MediaStore.Images.Media.IS_PENDING, 1);
            }
            uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            if (uri == null) return;
            out = resolver.openOutputStream(uri);
            if (out == null) return;
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, out);
            out.flush();
            if (Build.VERSION.SDK_INT >= 29) {
                values.clear();
                values.put(MediaStore.Images.Media.IS_PENDING, 0);
                resolver.update(uri, values, null, null);
            }
        } catch (Exception ignored) {
            if (uri != null) {
                try { getContentResolver().delete(uri, null, null); } catch (Exception ignored2) { }
            }
        } finally {
            if (out != null) {
                try { out.close(); } catch (Exception ignored) { }
            }
        }
    }

    private Notification buildNotification(String text) {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent openPi = PendingIntent.getActivity(
                this,
                11,
                open,
                Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0
        );

        Intent stop = new Intent(this, ScreenshotCaptureService.class);
        stop.setAction(ACTION_STOP);
        PendingIntent stopPi = PendingIntent.getService(
                this,
                12,
                stop,
                Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0
        );

        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);

        return builder
                .setSmallIcon(android.R.drawable.ic_menu_camera)
                .setContentTitle("AppBlocker · jawny monitor screenshotów")
                .setContentText(text)
                .setContentIntent(openPi)
                .setOngoing(true)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop", stopPi)
                .build();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationChannel ch = new NotificationChannel(
                CHANNEL_ID,
                "AppBlocker screenshot monitor",
                NotificationManager.IMPORTANCE_LOW
        );
        ch.setDescription("Jawny zapis screenshotów do Pictures/monitor");
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm != null) nm.createNotificationChannel(ch);
    }

    private void stopProjectionOnly() {
        if (virtualDisplay != null) {
            try { virtualDisplay.release(); } catch (Exception ignored) { }
            virtualDisplay = null;
        }
        if (imageReader != null) {
            try { imageReader.close(); } catch (Exception ignored) { }
            imageReader = null;
        }
        if (projection != null) {
            try { projection.stop(); } catch (Exception ignored) { }
            projection = null;
        }
    }

    @Override public void onDestroy() {
        stopProjectionOnly();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) {
        return null;
    }
}
