package pl.arena.appblocker;

import android.content.Context;
import android.content.SharedPreferences;

import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.List;

import org.json.JSONObject;

final class Prefs {
    static final String PREFS = "appblocker_prefs";

    // Stare klucze z pierwszych wersji — zostawione tylko do łagodnej migracji.
    static final String KEY_PACKAGES = "blocked_packages";
    static final String KEY_END_TIME = "end_time";

    // Blokady per aplikacja.
    static final String KEY_APP_END_TIMES = "app_end_times";

    // Tryb dyscypliny.
    static final String KEY_DISCIPLINE_ENABLED = "discipline_enabled";
    static final String KEY_ATTEMPTS = "attempt_counts";
    static final String KEY_LAST_ATTEMPTS = "last_attempt_times";
    static final String KEY_LAST_PENALTY = "last_penalty_times";
    static final String KEY_PENALTY_MS = "penalty_ms";

    // Bezpieczne moduły dodatkowe.
    static final String KEY_WALLPAPER_URI = "wallpaper_uri";
    static final String KEY_WALLPAPER_END_TIME = "wallpaper_end_time";
    static final String KEY_SCREENSHOT_INTERVAL_MIN = "screenshot_interval_min";

    static final String KEY_CONTROL_MODE = "control_mode";
    static final String KEY_CONTROL_CODE_HASH = "control_code_hash";
    static final String KEY_CUFFS_END_TIME = "cuffs_end_time";

    static final String KEY_SETTINGS_LOCK_END_TIME = "settings_lock_end_time";
    static final String KEY_SETTINGS_LOCK_CODE_HASH = "settings_lock_code_hash";

    static final String KEY_INSTALL_LOCK_END_TIME = "install_lock_end_time";
    static final String KEY_INSTALL_LOCK_CODE_HASH = "install_lock_code_hash";
    static final String KEY_BROWSER_LOCK_END_TIME = "browser_lock_end_time";
    static final String KEY_BROWSER_LOCK_CODE_HASH = "browser_lock_code_hash";
    static final String KEY_SILENCE_END_TIME = "silence_end_time";
    static final String KEY_SILENCE_CODE_HASH = "silence_code_hash";

    static final String KEY_POLICE_TASKS = "police_tasks";

    static final String POLICE_ACTION_CUFFS = "cuffs";
    static final String POLICE_ACTION_SETTINGS = "settings";
    static final String POLICE_ACTION_BROWSER = "browser";
    static final String POLICE_ACTION_INSTALL = "install";
    static final String POLICE_ACTION_SILENCE = "silence";

    static final int MODE_FREE = 0;
    static final int MODE_ANKLET = 1;
    static final int MODE_CUFFS = 2;

    private static final String SEP = "|";
    private static final long ATTEMPT_COOLDOWN_MS = 2500L;
    private static final long PENALTY_COOLDOWN_MS = 10000L;
    private static final long PENALTY_STEP_MS = 60_000L;
    private static final long PENALTY_CAP_MS = 10L * 60_000L;

    private Prefs() {}

    static SharedPreferences sp(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    static Map<String, Long> getBlockMap(Context context) {
        migrateOldGlobalBlockIfNeeded(context);
        Map<String, Long> map = new HashMap<>();
        Set<String> raw = sp(context).getStringSet(KEY_APP_END_TIMES, new HashSet<String>());
        long now = System.currentTimeMillis();
        boolean changed = false;

        for (String entry : raw) {
            ParsedEntry parsed = parseEntry(entry);
            if (parsed == null) {
                changed = true;
                continue;
            }
            if (parsed.value <= now) {
                changed = true;
                continue;
            }
            map.put(parsed.packageName, parsed.value);
        }

        if (changed) saveMap(context, KEY_APP_END_TIMES, map, true);
        return map;
    }

    static Set<String> getBlockedPackages(Context context) {
        return new HashSet<>(getBlockMap(context).keySet());
    }

    static boolean hasAnyActive(Context context) {
        return !getBlockMap(context).isEmpty();
    }

    static int activeCount(Context context) {
        return getBlockMap(context).size();
    }

    static boolean isActive(Context context) {
        return hasAnyActive(context);
    }

    static boolean isPackageActive(Context context, String packageName) {
        return getEndTime(context, packageName) > System.currentTimeMillis();
    }

    static long getEndTime(Context context, String packageName) {
        if (packageName == null) return 0L;
        Long end = getBlockMap(context).get(packageName);
        return end == null ? 0L : end;
    }

    // Kompatybilność ze starszym kodem: zwraca najdłuższą aktywną blokadę.
    static long getEndTime(Context context) {
        long max = 0L;
        for (Long end : getBlockMap(context).values()) {
            if (end != null && end > max) max = end;
        }
        return max;
    }

    static long remainingMillis(Context context) {
        return Math.max(0L, getEndTime(context) - System.currentTimeMillis());
    }

    static long remainingMillis(Context context, String packageName) {
        return Math.max(0L, getEndTime(context, packageName) - System.currentTimeMillis());
    }

    static void saveBlock(Context context, String packageName, long endTimeMillis) {
        if (packageName == null || packageName.trim().isEmpty()) return;
        Map<String, Long> map = getBlockMap(context);
        Long existing = map.get(packageName);
        // Ważne: nie skracamy aktywnej blokady. Można tylko dodać nową albo przedłużyć.
        if (existing == null || endTimeMillis > existing) {
            map.put(packageName, endTimeMillis);
            saveMap(context, KEY_APP_END_TIMES, map, true);
        }
    }

    static void saveBlocks(Context context, Set<String> packages, long endTimeMillis) {
        if (packages == null || packages.isEmpty()) return;
        Map<String, Long> map = getBlockMap(context);
        for (String pkg : packages) {
            if (pkg == null || pkg.trim().isEmpty()) continue;
            Long existing = map.get(pkg);
            if (existing == null || endTimeMillis > existing) {
                map.put(pkg, endTimeMillis);
            }
        }
        saveMap(context, KEY_APP_END_TIMES, map, true);
    }

    static boolean isDisciplineEnabled(Context context) {
        // Domyślnie włączone, bo ta edycja ma być surowsza. Jest limit bezpieczeństwa.
        return sp(context).getBoolean(KEY_DISCIPLINE_ENABLED, true);
    }

    static void setDisciplineEnabled(Context context, boolean enabled) {
        sp(context).edit().putBoolean(KEY_DISCIPLINE_ENABLED, enabled).apply();
    }

    static void setWallpaperUri(Context context, String uri) {
        sp(context).edit().putString(KEY_WALLPAPER_URI, uri == null ? "" : uri).apply();
    }

    static String getWallpaperUri(Context context) {
        return sp(context).getString(KEY_WALLPAPER_URI, "");
    }

    static void setWallpaperEndTime(Context context, long endTimeMillis) {
        sp(context).edit().putLong(KEY_WALLPAPER_END_TIME, endTimeMillis).apply();
    }

    static long getWallpaperEndTime(Context context) {
        return sp(context).getLong(KEY_WALLPAPER_END_TIME, 0L);
    }

    static boolean isWallpaperActive(Context context) {
        String uri = getWallpaperUri(context);
        return uri != null && uri.length() > 0 && getWallpaperEndTime(context) > System.currentTimeMillis();
    }

    static long wallpaperRemainingMillis(Context context) {
        return Math.max(0L, getWallpaperEndTime(context) - System.currentTimeMillis());
    }

    static void clearWallpaperTimer(Context context) {
        sp(context).edit().putLong(KEY_WALLPAPER_END_TIME, 0L).apply();
    }

    static int getControlMode(Context context) {
        int mode = sp(context).getInt(KEY_CONTROL_MODE, MODE_FREE);
        if (mode == MODE_CUFFS && getCuffsRemainingMillis(context) <= 0) {
            sp(context).edit().putInt(KEY_CONTROL_MODE, MODE_FREE).putLong(KEY_CUFFS_END_TIME, 0L).apply();
            return MODE_FREE;
        }
        if (mode != MODE_FREE && mode != MODE_ANKLET && mode != MODE_CUFFS) return MODE_FREE;
        return mode;
    }

    static String getControlModeName(Context context) {
        int mode = getControlMode(context);
        if (mode == MODE_ANKLET) return "Różowa opaska na kostkę";
        if (mode == MODE_CUFFS) return "Różowe kajdanki";
        return "Wolny";
    }

    static void setFreeMode(Context context) {
        sp(context).edit()
                .putInt(KEY_CONTROL_MODE, MODE_FREE)
                .putLong(KEY_CUFFS_END_TIME, 0L)
                .apply();
    }

    static void setAnkletMode(Context context, String code) {
        sp(context).edit()
                .putInt(KEY_CONTROL_MODE, MODE_ANKLET)
                .putString(KEY_CONTROL_CODE_HASH, hashCode(code))
                .putLong(KEY_CUFFS_END_TIME, 0L)
                .apply();
    }

    static void setCuffsMode(Context context, String code, long endTimeMillis) {
        setCuffsModeHashed(context, hashCode(code), endTimeMillis);
    }

    static void setCuffsModeHashed(Context context, String codeHash, long endTimeMillis) {
        sp(context).edit()
                .putInt(KEY_CONTROL_MODE, MODE_CUFFS)
                .putString(KEY_CONTROL_CODE_HASH, codeHash == null ? "" : codeHash)
                .putLong(KEY_CUFFS_END_TIME, endTimeMillis)
                .apply();
    }

    static boolean verifyControlCode(Context context, String code) {
        String saved = sp(context).getString(KEY_CONTROL_CODE_HASH, "");
        return saved != null && saved.length() > 0 && saved.equals(hashCode(code));
    }

    static long getCuffsRemainingMillis(Context context) {
        return Math.max(0L, sp(context).getLong(KEY_CUFFS_END_TIME, 0L) - System.currentTimeMillis());
    }

    static boolean isCuffsLocked(Context context) {
        return getControlMode(context) == MODE_CUFFS && getCuffsRemainingMillis(context) > 0;
    }

    static void setSettingsLock(Context context, long endTimeMillis, String code) {
        sp(context).edit()
                .putLong(KEY_SETTINGS_LOCK_END_TIME, endTimeMillis)
                .putString(KEY_SETTINGS_LOCK_CODE_HASH, hashCode(code))
                .apply();
    }

    static boolean isSettingsLockActive(Context context) {
        return getSettingsLockRemainingMillis(context) > 0L;
    }

    static long getSettingsLockEndTime(Context context) {
        long end = sp(context).getLong(KEY_SETTINGS_LOCK_END_TIME, 0L);
        if (end <= System.currentTimeMillis()) {
            if (end != 0L) clearSettingsLock(context);
            return 0L;
        }
        return end;
    }

    static long getSettingsLockRemainingMillis(Context context) {
        return Math.max(0L, sp(context).getLong(KEY_SETTINGS_LOCK_END_TIME, 0L) - System.currentTimeMillis());
    }

    static void clearSettingsLock(Context context) {
        sp(context).edit()
                .putLong(KEY_SETTINGS_LOCK_END_TIME, 0L)
                .remove(KEY_SETTINGS_LOCK_CODE_HASH)
                .apply();
    }

    static boolean verifySettingsLockCode(Context context, String code) {
        return verifyHashedCode(context, KEY_SETTINGS_LOCK_CODE_HASH, code);
    }

    static void setInstallLock(Context context, long endTimeMillis, String code) {
        setTimedCodeLock(context, KEY_INSTALL_LOCK_END_TIME, KEY_INSTALL_LOCK_CODE_HASH, endTimeMillis, code);
    }

    static boolean isInstallLockActive(Context context) {
        return getTimedRemaining(context, KEY_INSTALL_LOCK_END_TIME) > 0L;
    }

    static long getInstallLockEndTime(Context context) {
        return getTimedEnd(context, KEY_INSTALL_LOCK_END_TIME);
    }

    static long getInstallLockRemainingMillis(Context context) {
        return getTimedRemaining(context, KEY_INSTALL_LOCK_END_TIME);
    }

    static void clearInstallLock(Context context) {
        clearTimedCodeLock(context, KEY_INSTALL_LOCK_END_TIME, KEY_INSTALL_LOCK_CODE_HASH);
    }

    static boolean verifyInstallLockCode(Context context, String code) {
        return verifyHashedCode(context, KEY_INSTALL_LOCK_CODE_HASH, code);
    }

    static void setBrowserLock(Context context, long endTimeMillis, String code) {
        setTimedCodeLock(context, KEY_BROWSER_LOCK_END_TIME, KEY_BROWSER_LOCK_CODE_HASH, endTimeMillis, code);
    }

    static boolean isBrowserLockActive(Context context) {
        return getTimedRemaining(context, KEY_BROWSER_LOCK_END_TIME) > 0L;
    }

    static long getBrowserLockEndTime(Context context) {
        return getTimedEnd(context, KEY_BROWSER_LOCK_END_TIME);
    }

    static long getBrowserLockRemainingMillis(Context context) {
        return getTimedRemaining(context, KEY_BROWSER_LOCK_END_TIME);
    }

    static void clearBrowserLock(Context context) {
        clearTimedCodeLock(context, KEY_BROWSER_LOCK_END_TIME, KEY_BROWSER_LOCK_CODE_HASH);
    }

    static boolean verifyBrowserLockCode(Context context, String code) {
        return verifyHashedCode(context, KEY_BROWSER_LOCK_CODE_HASH, code);
    }

    static void setSilenceLock(Context context, long endTimeMillis, String code) {
        setTimedCodeLock(context, KEY_SILENCE_END_TIME, KEY_SILENCE_CODE_HASH, endTimeMillis, code);
    }

    static boolean isSilenceLockActive(Context context) {
        return getTimedRemaining(context, KEY_SILENCE_END_TIME) > 0L;
    }

    static long getSilenceLockEndTime(Context context) {
        return getTimedEnd(context, KEY_SILENCE_END_TIME);
    }

    static long getSilenceLockRemainingMillis(Context context) {
        return getTimedRemaining(context, KEY_SILENCE_END_TIME);
    }

    static void clearSilenceLock(Context context) {
        clearTimedCodeLock(context, KEY_SILENCE_END_TIME, KEY_SILENCE_CODE_HASH);
    }

    static boolean verifySilenceLockCode(Context context, String code) {
        return verifyHashedCode(context, KEY_SILENCE_CODE_HASH, code);
    }

    private static void setTimedCodeLock(Context context, String endKey, String codeKey, long endTimeMillis, String code) {
        setTimedCodeLockHashed(context, endKey, codeKey, endTimeMillis, hashCode(code));
    }

    private static void setTimedCodeLockHashed(Context context, String endKey, String codeKey, long endTimeMillis, String codeHash) {
        sp(context).edit()
                .putLong(endKey, endTimeMillis)
                .putString(codeKey, codeHash == null ? "" : codeHash)
                .apply();
    }

    private static long getTimedEnd(Context context, String endKey) {
        long end = sp(context).getLong(endKey, 0L);
        return end > System.currentTimeMillis() ? end : 0L;
    }

    private static long getTimedRemaining(Context context, String endKey) {
        return Math.max(0L, sp(context).getLong(endKey, 0L) - System.currentTimeMillis());
    }

    private static void clearTimedCodeLock(Context context, String endKey, String codeKey) {
        sp(context).edit().putLong(endKey, 0L).remove(codeKey).apply();
    }

    private static boolean verifyHashedCode(Context context, String codeKey, String code) {
        String saved = sp(context).getString(codeKey, "");
        return saved != null && saved.length() > 0 && saved.equals(hashCode(code));
    }

    static boolean hasAnySpecialTimedLock(Context context) {
        return isSettingsLockActive(context)
                || isInstallLockActive(context)
                || isBrowserLockActive(context)
                || isSilenceLockActive(context);
    }

    static long getSpecialLockEndTimeForKind(Context context, String kind) {
        if ("settings".equals(kind)) return getSettingsLockEndTime(context);
        if ("install".equals(kind)) return getInstallLockEndTime(context);
        if ("browser".equals(kind)) return getBrowserLockEndTime(context);
        return 0L;
    }


    static List<PoliceTask> getPoliceTasks(Context context) {
        Set<String> raw = sp(context).getStringSet(KEY_POLICE_TASKS, new HashSet<String>());
        List<PoliceTask> tasks = new ArrayList<>();
        boolean changed = false;
        for (String entry : raw) {
            PoliceTask task = PoliceTask.fromJson(entry);
            if (task == null) {
                changed = true;
            } else {
                tasks.add(task);
            }
        }
        if (changed) savePoliceTasks(context, tasks);
        return tasks;
    }

    static void addPoliceTask(Context context, String title, long deadlineMillis, String actions, int penaltyMinutes, String code,
                              String scheduleType, int dailyHour, int dailyMinute) {
        List<PoliceTask> tasks = getPoliceTasks(context);
        PoliceTask task = new PoliceTask();
        task.id = String.valueOf(System.currentTimeMillis()) + "_" + Math.abs((title == null ? "" : title).hashCode());
        task.title = title == null ? "Zadanie" : title.trim();
        if (task.title.length() == 0) task.title = "Zadanie";
        task.deadlineMillis = deadlineMillis;
        task.action = POLICE_ACTION_CUFFS;
        task.actions = actions == null || actions.trim().isEmpty() ? POLICE_ACTION_CUFFS : actions;
        task.penaltyMinutes = Math.max(1, Math.min(1440, penaltyMinutes));
        task.codeHash = hashCode(code);
        task.createdAtMillis = System.currentTimeMillis();
        task.done = false;
        task.punished = false;
        task.scheduleType = "daily".equals(scheduleType) ? "daily" : "once";
        task.dailyHour = Math.max(0, Math.min(23, dailyHour));
        task.dailyMinute = Math.max(0, Math.min(59, dailyMinute));
        task.doneCount = 0;
        task.punishedCount = 0;
        tasks.add(task);
        savePoliceTasks(context, tasks);
    }

    static boolean markPoliceTaskDone(Context context, String id) {
        List<PoliceTask> tasks = getPoliceTasks(context);
        boolean changed = false;
        for (PoliceTask task : tasks) {
            if (task.id.equals(id) && !task.punished) {
                if ("daily".equals(task.scheduleType)) {
                    task.doneCount++;
                    task.done = false;
                    task.punished = false;
                    task.deadlineMillis = nextDailyDeadlineAfter(System.currentTimeMillis(), task.dailyHour, task.dailyMinute);
                } else {
                    task.done = true;
                }
                changed = true;
            }
        }
        if (changed) savePoliceTasks(context, tasks);
        return changed;
    }

    static boolean removePoliceTask(Context context, String id) {
        List<PoliceTask> tasks = getPoliceTasks(context);
        List<PoliceTask> kept = new ArrayList<>();
        boolean removed = false;
        for (PoliceTask task : tasks) {
            if (task.id.equals(id)) removed = true;
            else kept.add(task);
        }
        if (removed) savePoliceTasks(context, kept);
        return removed;
    }

    static boolean hasPendingPoliceTasks(Context context) {
        long now = System.currentTimeMillis();
        for (PoliceTask task : getPoliceTasks(context)) {
            if (!task.done && !task.punished && task.deadlineMillis > now) return true;
        }
        return false;
    }

    static int getPoliceOpenCount(Context context) {
        int count = 0;
        for (PoliceTask task : getPoliceTasks(context)) {
            if (!task.done && !task.punished) count++;
        }
        return count;
    }

    static int getPolicePunishedCount(Context context) {
        int count = 0;
        for (PoliceTask task : getPoliceTasks(context)) {
            if (task.punished) count++;
        }
        return count;
    }

    static int checkPoliceTasksAndApply(Context context) {
        long now = System.currentTimeMillis();
        List<PoliceTask> tasks = getPoliceTasks(context);
        boolean changed = false;
        int applied = 0;
        for (PoliceTask task : tasks) {
            if (task.done || task.punished || task.deadlineMillis > now) continue;
            applyPolicePenalty(context, task);
            task.punishedCount++;
            if ("daily".equals(task.scheduleType)) {
                task.punished = false;
                task.done = false;
                task.deadlineMillis = nextDailyDeadlineAfter(now, task.dailyHour, task.dailyMinute);
            } else {
                task.punished = true;
            }
            changed = true;
            applied++;
        }
        if (changed) savePoliceTasks(context, tasks);
        return applied;
    }

    private static void applyPolicePenalty(Context context, PoliceTask task) {
        long end = System.currentTimeMillis() + Math.max(1, task.penaltyMinutes) * 60_000L;
        String hash = task.codeHash == null ? "" : task.codeHash;
        for (String action : task.actionList()) {
            if (action != null) action = action.trim();
            if (POLICE_ACTION_CUFFS.equals(action)) {
                setCuffsModeHashed(context, hash, end);
            } else if (POLICE_ACTION_SETTINGS.equals(action)) {
                setTimedCodeLockHashed(context, KEY_SETTINGS_LOCK_END_TIME, KEY_SETTINGS_LOCK_CODE_HASH, end, hash);
            } else if (POLICE_ACTION_BROWSER.equals(action)) {
                setTimedCodeLockHashed(context, KEY_BROWSER_LOCK_END_TIME, KEY_BROWSER_LOCK_CODE_HASH, end, hash);
            } else if (POLICE_ACTION_INSTALL.equals(action)) {
                setTimedCodeLockHashed(context, KEY_INSTALL_LOCK_END_TIME, KEY_INSTALL_LOCK_CODE_HASH, end, hash);
            } else if (POLICE_ACTION_SILENCE.equals(action)) {
                setTimedCodeLockHashed(context, KEY_SILENCE_END_TIME, KEY_SILENCE_CODE_HASH, end, hash);
            }
        }
    }

    private static long nextDailyDeadlineAfter(long now, int hour, int minute) {
        java.util.Calendar c = java.util.Calendar.getInstance();
        c.setTimeInMillis(now);
        c.set(java.util.Calendar.HOUR_OF_DAY, Math.max(0, Math.min(23, hour)));
        c.set(java.util.Calendar.MINUTE, Math.max(0, Math.min(59, minute)));
        c.set(java.util.Calendar.SECOND, 0);
        c.set(java.util.Calendar.MILLISECOND, 0);
        if (c.getTimeInMillis() <= now) c.add(java.util.Calendar.DAY_OF_YEAR, 1);
        return c.getTimeInMillis();
    }

    private static void savePoliceTasks(Context context, List<PoliceTask> tasks) {
        Set<String> raw = new HashSet<>();
        for (PoliceTask task : tasks) raw.add(task.toJson());
        sp(context).edit().putStringSet(KEY_POLICE_TASKS, raw).apply();
    }

    static boolean removeBlock(Context context, String packageName) {
        if (packageName == null) return false;
        Map<String, Long> map = getBlockMap(context);
        boolean removed = map.remove(packageName) != null;
        if (removed) saveMap(context, KEY_APP_END_TIMES, map, true);
        return removed;
    }

    private static String hashCode(String code) {
        if (code == null) code = "";
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] bytes = md.digest(("AppBlocker:" + code).getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder();
            for (byte b : bytes) sb.append(String.format("%02x", b & 0xff));
            return sb.toString();
        } catch (Exception e) {
            return String.valueOf(code.hashCode());
        }
    }

    static int getScreenshotIntervalMin(Context context) {
        int value = sp(context).getInt(KEY_SCREENSHOT_INTERVAL_MIN, 5);
        if (value < 2) return 2;
        if (value > 20) return 20;
        return value;
    }

    static void setScreenshotIntervalMin(Context context, int minutes) {
        if (minutes < 2) minutes = 2;
        if (minutes > 20) minutes = 20;
        sp(context).edit().putInt(KEY_SCREENSHOT_INTERVAL_MIN, minutes).apply();
    }

    static int getAttemptCount(Context context, String packageName) {
        if (packageName == null) return 0;
        Long count = getLongMap(context, KEY_ATTEMPTS, false).get(packageName);
        return count == null ? 0 : count.intValue();
    }

    static int getTotalAttemptCount(Context context) {
        int total = 0;
        for (Long value : getLongMap(context, KEY_ATTEMPTS, false).values()) {
            if (value != null) total += value.intValue();
        }
        return total;
    }

    static long getPenaltyMillis(Context context, String packageName) {
        if (packageName == null) return 0L;
        Long value = getLongMap(context, KEY_PENALTY_MS, false).get(packageName);
        return value == null ? 0L : value;
    }

    static AttemptResult recordDisciplineHit(Context context, String packageName) {
        AttemptResult result = new AttemptResult();
        if (packageName == null || packageName.trim().isEmpty()) return result;
        if (!isPackageActive(context, packageName)) return result;

        long now = System.currentTimeMillis();
        Map<String, Long> attempts = getLongMap(context, KEY_ATTEMPTS, false);
        Map<String, Long> lastAttempts = getLongMap(context, KEY_LAST_ATTEMPTS, false);
        Map<String, Long> lastPenalty = getLongMap(context, KEY_LAST_PENALTY, false);
        Map<String, Long> penalties = getLongMap(context, KEY_PENALTY_MS, false);

        long lastAttemptAt = valueOrZero(lastAttempts.get(packageName));
        boolean newAttempt = now - lastAttemptAt >= ATTEMPT_COOLDOWN_MS;

        if (newAttempt) {
            long count = valueOrZero(attempts.get(packageName)) + 1L;
            attempts.put(packageName, count);
            lastAttempts.put(packageName, now);
            saveMap(context, KEY_ATTEMPTS, attempts, false);
            saveMap(context, KEY_LAST_ATTEMPTS, lastAttempts, false);
            result.newAttempt = true;
            result.attemptCount = (int) count;
        } else {
            result.attemptCount = (int) valueOrZero(attempts.get(packageName));
        }

        result.totalPenaltyMs = valueOrZero(penalties.get(packageName));

        if (isDisciplineEnabled(context) && newAttempt) {
            long lastPenaltyAt = valueOrZero(lastPenalty.get(packageName));
            long currentPenalty = valueOrZero(penalties.get(packageName));
            if (now - lastPenaltyAt >= PENALTY_COOLDOWN_MS && currentPenalty < PENALTY_CAP_MS) {
                long add = Math.min(PENALTY_STEP_MS, PENALTY_CAP_MS - currentPenalty);
                Map<String, Long> blocks = getBlockMap(context);
                Long end = blocks.get(packageName);
                if (end != null && end > now) {
                    blocks.put(packageName, end + add);
                    saveMap(context, KEY_APP_END_TIMES, blocks, true);
                    penalties.put(packageName, currentPenalty + add);
                    lastPenalty.put(packageName, now);
                    saveMap(context, KEY_PENALTY_MS, penalties, false);
                    saveMap(context, KEY_LAST_PENALTY, lastPenalty, false);
                    result.penaltyAddedMs = add;
                    result.totalPenaltyMs = currentPenalty + add;
                }
            }
        }

        return result;
    }

    private static long valueOrZero(Long value) {
        return value == null ? 0L : value;
    }

    private static Map<String, Long> getLongMap(Context context, String key, boolean dropExpiredTimestamps) {
        Map<String, Long> map = new HashMap<>();
        Set<String> raw = sp(context).getStringSet(key, new HashSet<String>());
        long now = System.currentTimeMillis();
        boolean changed = false;
        for (String entry : raw) {
            ParsedEntry parsed = parseEntry(entry);
            if (parsed == null) {
                changed = true;
                continue;
            }
            if (dropExpiredTimestamps && parsed.value <= now) {
                changed = true;
                continue;
            }
            map.put(parsed.packageName, parsed.value);
        }
        if (changed) saveMap(context, key, map, dropExpiredTimestamps);
        return map;
    }

    private static void saveMap(Context context, String key, Map<String, Long> map, boolean dropExpiredTimestamps) {
        Set<String> raw = new HashSet<>();
        long now = System.currentTimeMillis();
        for (Map.Entry<String, Long> e : map.entrySet()) {
            String pkg = e.getKey();
            Long value = e.getValue();
            if (pkg == null || value == null) continue;
            if (dropExpiredTimestamps && value <= now) continue;
            raw.add(pkg + SEP + value);
        }
        sp(context).edit().putStringSet(key, raw).apply();
    }

    private static ParsedEntry parseEntry(String entry) {
        if (entry == null) return null;
        int idx = entry.lastIndexOf(SEP);
        if (idx <= 0 || idx >= entry.length() - 1) return null;
        String pkg = entry.substring(0, idx);
        long value;
        try {
            value = Long.parseLong(entry.substring(idx + 1));
        } catch (Exception e) {
            return null;
        }
        if (pkg.length() == 0) return null;
        return new ParsedEntry(pkg, value);
    }

    private static void migrateOldGlobalBlockIfNeeded(Context context) {
        SharedPreferences prefs = sp(context);
        if (prefs.contains(KEY_APP_END_TIMES)) return;

        long oldEnd = prefs.getLong(KEY_END_TIME, 0L);
        Set<String> oldPackages = prefs.getStringSet(KEY_PACKAGES, new HashSet<String>());
        if (oldEnd <= System.currentTimeMillis() || oldPackages == null || oldPackages.isEmpty()) {
            prefs.edit().putStringSet(KEY_APP_END_TIMES, new HashSet<String>()).apply();
            return;
        }

        Set<String> raw = new HashSet<>();
        for (String pkg : oldPackages) {
            if (pkg != null && !pkg.trim().isEmpty()) raw.add(pkg + SEP + oldEnd);
        }
        prefs.edit().putStringSet(KEY_APP_END_TIMES, raw).apply();
    }

    static final class AttemptResult {
        boolean newAttempt = false;
        int attemptCount = 0;
        long penaltyAddedMs = 0L;
        long totalPenaltyMs = 0L;
    }


    static final class PoliceTask {
        String id;
        String title;
        long deadlineMillis;
        String action;
        String actions;
        int penaltyMinutes;
        String scheduleType;
        int dailyHour;
        int dailyMinute;
        int doneCount;
        int punishedCount;
        String codeHash;
        boolean done;
        boolean punished;
        long createdAtMillis;

        String toJson() {
            try {
                JSONObject o = new JSONObject();
                o.put("id", id == null ? "" : id);
                o.put("title", title == null ? "Zadanie" : title);
                o.put("deadline", deadlineMillis);
                o.put("action", action == null ? POLICE_ACTION_CUFFS : action);
                o.put("actions", actions == null || actions.length() == 0 ? (action == null ? POLICE_ACTION_CUFFS : action) : actions);
                o.put("penalty", penaltyMinutes);
                o.put("scheduleType", scheduleType == null ? "once" : scheduleType);
                o.put("dailyHour", dailyHour);
                o.put("dailyMinute", dailyMinute);
                o.put("doneCount", doneCount);
                o.put("punishedCount", punishedCount);
                o.put("codeHash", codeHash == null ? "" : codeHash);
                o.put("done", done);
                o.put("punished", punished);
                o.put("created", createdAtMillis);
                return o.toString();
            } catch (Exception e) {
                return "{}";
            }
        }

        String[] actionList() {
            String source = actions == null || actions.length() == 0 ? action : actions;
            if (source == null || source.length() == 0) source = POLICE_ACTION_CUFFS;
            return source.split(",");
        }

        static PoliceTask fromJson(String json) {
            try {
                JSONObject o = new JSONObject(json);
                PoliceTask t = new PoliceTask();
                t.id = o.optString("id", "");
                t.title = o.optString("title", "Zadanie");
                t.deadlineMillis = o.optLong("deadline", 0L);
                t.action = o.optString("action", POLICE_ACTION_CUFFS);
                t.actions = o.optString("actions", t.action == null ? POLICE_ACTION_CUFFS : t.action);
                t.penaltyMinutes = o.optInt("penalty", 10);
                t.scheduleType = o.optString("scheduleType", "once");
                t.dailyHour = o.optInt("dailyHour", 23);
                t.dailyMinute = o.optInt("dailyMinute", 0);
                t.doneCount = o.optInt("doneCount", 0);
                t.punishedCount = o.optInt("punishedCount", t.punished ? 1 : 0);
                t.codeHash = o.optString("codeHash", "");
                t.done = o.optBoolean("done", false);
                t.punished = o.optBoolean("punished", false);
                t.createdAtMillis = o.optLong("created", 0L);
                if (t.id == null || t.id.length() == 0) return null;
                return t;
            } catch (Exception e) {
                return null;
            }
        }
    }

    private static final class ParsedEntry {
        final String packageName;
        final long value;
        ParsedEntry(String packageName, long value) {
            this.packageName = packageName;
            this.value = value;
        }
    }
}
