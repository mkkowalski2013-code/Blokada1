package pl.arena.appblocker;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (intent == null || intent.getAction() == null) return;

        String action = intent.getAction();
        boolean boot = Intent.ACTION_BOOT_COMPLETED.equals(action)
                || Intent.ACTION_LOCKED_BOOT_COMPLETED.equals(action)
                || Intent.ACTION_USER_PRESENT.equals(action)
                || Intent.ACTION_MY_PACKAGE_REPLACED.equals(action)
                || "android.intent.action.QUICKBOOT_POWERON".equals(action)
                || "com.htc.intent.action.QUICKBOOT_POWERON".equals(action);
        if (!boot) return;

        // Po restarcie uruchamiamy monitor tylko wtedy, gdy faktycznie ma co robić:
        // aktywne blokady aplikacji albo aktywna auto-tapeta.
        if (!Prefs.hasAnyActive(context) && !Prefs.isWallpaperActive(context) && !Prefs.hasAnySpecialTimedLock(context) && !Prefs.hasPendingPoliceTasks(context)) return;

        Intent service = new Intent(context, BlockMonitorService.class);
        try {
            if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(service);
            else context.startService(service);
        } catch (Exception ignored) {
            try { context.startService(service); } catch (Exception ignored2) { }
        }
    }
}
