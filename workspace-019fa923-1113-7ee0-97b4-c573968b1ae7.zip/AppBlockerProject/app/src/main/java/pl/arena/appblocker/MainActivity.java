package pl.arena.appblocker;

import android.accessibilityservice.AccessibilityServiceInfo;
import android.app.AppOpsManager;
import android.app.Dialog;
import android.app.Activity;
import android.app.NotificationManager;
import android.app.admin.DevicePolicyManager;
import android.app.WallpaperManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Process;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.accessibility.AccessibilityManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class MainActivity extends Activity {
    private static final int REQUEST_PICK_WALLPAPER = 7001;
    private static final int REQUEST_SCREEN_CAPTURE = 7002;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private ScrollView mainScroll;
    private final List<AppItem> apps = new ArrayList<>();
    private final Set<String> selectedPackages = new HashSet<>();

    private static final int BLACK = Color.rgb(0, 0, 0);
    private static final int PANEL = Color.rgb(7, 7, 7);
    private static final int CARD = Color.rgb(12, 12, 12);
    private static final int CARD_2 = Color.rgb(18, 18, 18);
    private static final int ORANGE = Color.rgb(255, 144, 0); // #FF9000
    private static final int ORANGE_DARK = Color.rgb(45, 25, 0);
    private static final int TEXT = Color.rgb(245, 245, 245);
    private static final int MUTED = Color.rgb(170, 170, 170);
    private static final int DANGER = Color.rgb(255, 84, 84);
    private static final int OK = Color.rgb(76, 220, 120);

    private TextView status;
    private TextView permissionStatus;
    private TextView selectedCount;
    private EditText minutesInput;
    private LinearLayout appContainer;
    private Button startButton;
    private TextView disciplineStatus;
    private Button disciplineToggle;
    private TextView journalStatus;
    private TextView controlModeStatus;
    private TextView adminStatus;
    private TextView policeStatus;
    private LinearLayout policeTaskContainer;
    private View policeSection;
    private TextView settingsLockStatus;
    private EditText settingsLockMinutesInput;
    private TextView installLockStatus;
    private EditText installLockMinutesInput;
    private TextView browserLockStatus;
    private EditText browserLockMinutesInput;
    private TextView silenceLockStatus;
    private EditText silenceLockMinutesInput;
    private TextView wallpaperStatus;
    private EditText wallpaperMinutesInput;
    private TextView screenshotStatus;
    private TextView screenshotIntervalLabel;
    private int screenshotIntervalMin = 5;

    private final Runnable statusTicker = new Runnable() {
        @Override public void run() {
            refreshStatus();
            if (Prefs.hasAnyActive(MainActivity.this)) renderAppList();
            if (policeTaskContainer != null) renderPoliceTasks();
            handler.postDelayed(this, 1000);
        }
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BLACK);
        getWindow().setNavigationBarColor(BLACK);
        selectedPackages.addAll(Prefs.getBlockedPackages(this));
        buildUi();
        loadApps();
    }

    @Override protected void onResume() {
        super.onResume();
        if ((Prefs.hasAnyActive(this) && hasRequiredPermissions()) || Prefs.isWallpaperActive(this) || Prefs.hasAnySpecialTimedLock(this) || Prefs.hasPendingPoliceTasks(this)) startMonitorService();
        handler.removeCallbacks(statusTicker);
        handler.post(statusTicker);
    }

    @Override protected void onPause() {
        super.onPause();
        handler.removeCallbacks(statusTicker);
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        mainScroll = scroll;
        scroll.setFillViewport(false);
        scroll.setBackgroundColor(BLACK);
        scroll.setClipToPadding(false);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(14), dp(14), dp(14), dp(28));
        content.setBackgroundColor(BLACK);
        scroll.addView(content, new ScrollView.LayoutParams(-1, -2));

        content.addView(buildHeader(), blockLp(0, 0, 0, 14));
        content.addView(buildPermissionCard(), blockLp(0, 0, 0, 12));
        content.addView(buildTimerCard(), blockLp(0, 0, 0, 12));
        content.addView(buildControlModeCard(), blockLp(0, 0, 0, 12));
        content.addView(buildPoliceCard(), blockLp(0, 0, 0, 12));
        content.addView(buildSettingsLockCard(), blockLp(0, 0, 0, 12));
        content.addView(buildInstallerLockCard(), blockLp(0, 0, 0, 12));
        content.addView(buildBrowserLockCard(), blockLp(0, 0, 0, 12));
        content.addView(buildSilenceLockCard(), blockLp(0, 0, 0, 12));
        content.addView(buildWallpaperCard(), blockLp(0, 0, 0, 12));
        content.addView(buildScreenshotCard(), blockLp(0, 0, 0, 12));
        content.addView(buildListHeader(), blockLp(0, 0, 0, 8));

        appContainer = new LinearLayout(this);
        appContainer.setOrientation(LinearLayout.VERTICAL);
        content.addView(appContainer, new LinearLayout.LayoutParams(-1, -2));

        setContentView(scroll);
    }

    private View buildHeader() {
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setPadding(dp(18), dp(18), dp(18), dp(18));
        header.setBackground(gradient(BLACK, Color.rgb(35, 20, 0), GradientDrawable.Orientation.TL_BR, 24, ORANGE, 1));

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        header.addView(top, new LinearLayout.LayoutParams(-1, -2));

        TextView mark = new TextView(this);
        mark.setText("LOCK");
        mark.setTextSize(16);
        mark.setTypeface(null, Typeface.BOLD);
        mark.setTextColor(ORANGE);
        mark.setGravity(Gravity.CENTER);
        mark.setBackground(roundStroke(Color.rgb(10, 10, 10), 16, ORANGE, 2));
        top.addView(mark, new LinearLayout.LayoutParams(dp(74), dp(52)));

        LinearLayout titleBox = new LinearLayout(this);
        titleBox.setOrientation(LinearLayout.VERTICAL);
        titleBox.setPadding(dp(14), 0, 0, 0);
        top.addView(titleBox, new LinearLayout.LayoutParams(0, -2, 1));

        TextView title = new TextView(this);
        title.setText("APPBLOCKER");
        title.setTextSize(28);
        title.setTypeface(null, Typeface.BOLD);
        title.setLetterSpacing(0.08f);
        title.setTextColor(TEXT);
        titleBox.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView subtitle = new TextView(this);
        subtitle.setText("XIAOMI / ANDROID 15 MODE");
        subtitle.setTextSize(12);
        subtitle.setTypeface(null, Typeface.BOLD);
        subtitle.setLetterSpacing(0.12f);
        subtitle.setTextColor(ORANGE);
        titleBox.addView(subtitle, new LinearLayout.LayoutParams(-1, -2));

        Button menuButton = pillButton("MENU", ORANGE, BLACK, true);
        top.addView(menuButton, new LinearLayout.LayoutParams(dp(88), -2));
        menuButton.setOnClickListener(v -> showMainMenu());

        TextView stripes = new TextView(this);
        stripes.setText("▰ ▰ ▰  INDYWIDUALNE CELE  ▰ ▰ ▰");
        stripes.setTextColor(ORANGE);
        stripes.setTextSize(13);
        stripes.setGravity(Gravity.CENTER);
        stripes.setTypeface(null, Typeface.BOLD);
        LinearLayout.LayoutParams stp = new LinearLayout.LayoutParams(-1, -2);
        stp.setMargins(0, dp(16), 0, dp(8));
        header.addView(stripes, stp);

        TextView desc = new TextView(this);
        desc.setText("Ta wersja używa Dostępu do użycia + nakładki ekranowej, bo na Xiaomi/HyperOS usługi Dostępności potrafią reagować dopiero po wyjściu z aplikacji.");
        desc.setTextSize(14);
        desc.setLineSpacing(0, 1.1f);
        desc.setTextColor(MUTED);
        desc.setGravity(Gravity.CENTER);
        header.addView(desc, new LinearLayout.LayoutParams(-1, -2));

        return header;
    }

    private View buildPermissionCard() {
        LinearLayout card = card();
        card.addView(sectionTitle("UPRAWNIENIA WYMAGANE"), new LinearLayout.LayoutParams(-1, -2));

        permissionStatus = new TextView(this);
        permissionStatus.setTextSize(14);
        permissionStatus.setTypeface(null, Typeface.BOLD);
        permissionStatus.setPadding(dp(12), dp(10), dp(12), dp(10));
        LinearLayout.LayoutParams ps = new LinearLayout.LayoutParams(-1, -2);
        ps.setMargins(0, dp(10), 0, dp(10));
        card.addView(permissionStatus, ps);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER);
        card.addView(row, new LinearLayout.LayoutParams(-1, -2));

        Button usage = pillButton("Dostęp do użycia", ORANGE, BLACK, true);
        row.addView(usage, new LinearLayout.LayoutParams(0, -2, 1));
        usage.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)));

        addHorizontalSpace(row, dp(8));

        Button overlay = pillButton("Nakładka", CARD_2, TEXT, false);
        row.addView(overlay, new LinearLayout.LayoutParams(0, -2, 1));
        overlay.setOnClickListener(v -> {
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        });

        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        row2.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams r2p = new LinearLayout.LayoutParams(-1, -2);
        r2p.setMargins(0, dp(8), 0, 0);
        card.addView(row2, r2p);

        Button accessibility = pillButton("Dostępność awaryjna", ORANGE_DARK, ORANGE, true);
        row2.addView(accessibility, new LinearLayout.LayoutParams(0, -2, 1));
        accessibility.setOnClickListener(v -> {
            Toast.makeText(this, "Wybierz: AppBlocker Monitor i włącz usługę. To najważniejszy tryb awaryjny dla Xiaomi.", Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
        });

        addHorizontalSpace(row2, dp(8));

        Button appInfo = pillButton("Ustawienia apki", CARD_2, TEXT, false);
        row2.addView(appInfo, new LinearLayout.LayoutParams(0, -2, 1));
        appInfo.setOnClickListener(v -> {
            Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            intent.setData(Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        });

        TextView note = new TextView(this);
        note.setText("Na Xiaomi włącz minimum: Dostępność awaryjna. Dodatkowo warto dać Dostęp do użycia + Nakładkę + brak ograniczeń baterii. Nowy tryb awaryjny wyrzuca z zablokowanej aplikacji na ekran główny.");
        note.setTextSize(12);
        note.setTextColor(MUTED);
        note.setLineSpacing(0, 1.08f);
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(-1, -2);
        np.setMargins(0, dp(10), 0, 0);
        card.addView(note, np);

        return card;
    }

    private View buildTimerCard() {
        LinearLayout card = card();
        card.addView(sectionTitle("BLOKADA GRUPOWA"), new LinearLayout.LayoutParams(-1, -2));

        status = new TextView(this);
        status.setTextSize(15);
        status.setTypeface(null, Typeface.BOLD);
        status.setPadding(dp(12), dp(10), dp(12), dp(10));
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2);
        sp.setMargins(0, dp(10), 0, dp(12));
        card.addView(status, sp);

        LinearLayout timerRow = new LinearLayout(this);
        timerRow.setOrientation(LinearLayout.HORIZONTAL);
        timerRow.setGravity(Gravity.CENTER_VERTICAL);
        card.addView(timerRow, new LinearLayout.LayoutParams(-1, -2));

        TextView timerLabel = new TextView(this);
        timerLabel.setText("Czas dla zaznaczonych");
        timerLabel.setTextSize(15);
        timerLabel.setTextColor(MUTED);
        timerRow.addView(timerLabel, new LinearLayout.LayoutParams(0, -2, 1));

        minutesInput = new EditText(this);
        minutesInput.setInputType(InputType.TYPE_CLASS_NUMBER);
        minutesInput.setText("30");
        minutesInput.setSelectAllOnFocus(true);
        minutesInput.setGravity(Gravity.CENTER);
        minutesInput.setTextColor(ORANGE);
        minutesInput.setTypeface(null, Typeface.BOLD);
        minutesInput.setTextSize(18);
        minutesInput.setPadding(dp(12), dp(8), dp(12), dp(8));
        minutesInput.setBackground(roundStroke(BLACK, 14, ORANGE, 1));
        timerRow.addView(minutesInput, new LinearLayout.LayoutParams(dp(112), -2));

        LinearLayout quickRow = new LinearLayout(this);
        quickRow.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams qp = new LinearLayout.LayoutParams(-1, -2);
        qp.setMargins(0, dp(12), 0, dp(12));
        card.addView(quickRow, qp);

        int[] quick = new int[]{15, 30, 60};
        for (int i = 0; i < quick.length; i++) {
            int m = quick[i];
            Button b = pillButton(m + " min", ORANGE_DARK, ORANGE, false);
            b.setOnClickListener(v -> minutesInput.setText(String.valueOf(m)));
            quickRow.addView(b, new LinearLayout.LayoutParams(0, -2, 1));
            if (i < quick.length - 1) addHorizontalSpace(quickRow, dp(8));
        }

        startButton = pillButton("START DLA ZAZNACZONYCH", ORANGE, BLACK, true);
        startButton.setTextSize(16);
        startButton.setLetterSpacing(0.06f);
        startButton.setOnClickListener(v -> startGroupBlock());
        card.addView(startButton, new LinearLayout.LayoutParams(-1, -2));

        TextView hint = new TextView(this);
        hint.setText("Indywidualnie: przy każdej aplikacji kliknij USTAW / PRZEDŁUŻ.");
        hint.setTextSize(12);
        hint.setTextColor(MUTED);
        hint.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, -2);
        hp.setMargins(0, dp(9), 0, dp(12));
        card.addView(hint, hp);

        TextView disciplineTitle = sectionTitle("DYSCYPLINA KOMENDANTA");
        card.addView(disciplineTitle, new LinearLayout.LayoutParams(-1, -2));

        disciplineStatus = new TextView(this);
        disciplineStatus.setTextSize(13);
        disciplineStatus.setTypeface(null, Typeface.BOLD);
        disciplineStatus.setPadding(dp(12), dp(10), dp(12), dp(10));
        LinearLayout.LayoutParams dsp = new LinearLayout.LayoutParams(-1, -2);
        dsp.setMargins(0, dp(10), 0, dp(8));
        card.addView(disciplineStatus, dsp);

        disciplineToggle = pillButton("Przełącz karę", ORANGE_DARK, ORANGE, true);
        disciplineToggle.setOnClickListener(v -> {
            Prefs.setDisciplineEnabled(this, !Prefs.isDisciplineEnabled(this));
            refreshStatus();
            Toast.makeText(this, Prefs.isDisciplineEnabled(this) ? "Kara za ucieczkę WŁĄCZONA" : "Kara za ucieczkę WYŁĄCZONA", Toast.LENGTH_SHORT).show();
        });
        card.addView(disciplineToggle, new LinearLayout.LayoutParams(-1, -2));

        journalStatus = new TextView(this);
        journalStatus.setTextSize(12);
        journalStatus.setTextColor(MUTED);
        journalStatus.setGravity(Gravity.CENTER);
        journalStatus.setLineSpacing(0, 1.08f);
        LinearLayout.LayoutParams jp = new LinearLayout.LayoutParams(-1, -2);
        jp.setMargins(0, dp(10), 0, 0);
        card.addView(journalStatus, jp);

        return card;
    }



    private View buildControlModeCard() {
        LinearLayout card = card();
        card.addView(sectionTitle("TRYB KONTROLI"), new LinearLayout.LayoutParams(-1, -2));

        controlModeStatus = new TextView(this);
        controlModeStatus.setTextSize(13);
        controlModeStatus.setTypeface(null, Typeface.BOLD);
        controlModeStatus.setPadding(dp(12), dp(10), dp(12), dp(10));
        LinearLayout.LayoutParams csp = new LinearLayout.LayoutParams(-1, -2);
        csp.setMargins(0, dp(10), 0, dp(8));
        card.addView(controlModeStatus, csp);

        adminStatus = new TextView(this);
        adminStatus.setTextSize(12);
        adminStatus.setTextColor(MUTED);
        adminStatus.setGravity(Gravity.CENTER);
        adminStatus.setPadding(dp(10), dp(8), dp(10), dp(8));
        adminStatus.setBackground(roundStroke(Color.rgb(18, 18, 18), 14, Color.rgb(45, 45, 45), 1));
        LinearLayout.LayoutParams asp = new LinearLayout.LayoutParams(-1, -2);
        asp.setMargins(0, 0, 0, dp(10));
        card.addView(adminStatus, asp);

        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        card.addView(row1, new LinearLayout.LayoutParams(-1, -2));

        Button free = pillButton("Wolny", CARD_2, TEXT, false);
        row1.addView(free, new LinearLayout.LayoutParams(0, -2, 1));
        free.setOnClickListener(v -> activateFreeMode());

        addHorizontalSpace(row1, dp(8));

        Button anklet = pillButton("Różowa opaska", ORANGE_DARK, ORANGE, true);
        row1.addView(anklet, new LinearLayout.LayoutParams(0, -2, 1));
        anklet.setOnClickListener(v -> showSetCodeDialog("Różowa opaska na kostkę", "Ustaw kod. Zmiany wymagają kodu, ale aktywnych blokad aplikacji nie da się usuwać.", code -> {
            Prefs.setAnkletMode(this, code);
            refreshStatus();
            Toast.makeText(this, "Tryb opaski aktywny.", Toast.LENGTH_LONG).show();
        }));

        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams r2p = new LinearLayout.LayoutParams(-1, -2);
        r2p.setMargins(0, dp(8), 0, 0);
        card.addView(row2, r2p);

        Button cuffs = pillButton("Różowe kajdanki", ORANGE, BLACK, true);
        row2.addView(cuffs, new LinearLayout.LayoutParams(0, -2, 1));
        cuffs.setOnClickListener(v -> showCuffsDialog());

        addHorizontalSpace(row2, dp(8));

        Button admin = pillButton("Admin urządzenia", CARD_2, TEXT, false);
        row2.addView(admin, new LinearLayout.LayoutParams(0, -2, 1));
        admin.setOnClickListener(v -> requestDeviceAdmin());

        TextView note = new TextView(this);
        note.setText("Wolny: pełna kontrola. Opaska: zmiany po kodzie, ale bez usuwania blokad aplikacji. Kajdanki: czasowa blokada zmian w aplikacji + opcjonalny Administrator urządzenia utrudnia odinstalowanie, ale nadal możesz cofnąć uprawnienia w ustawieniach Androida.");
        note.setTextSize(12);
        note.setTextColor(MUTED);
        note.setGravity(Gravity.CENTER);
        note.setLineSpacing(0, 1.08f);
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(-1, -2);
        np.setMargins(0, dp(10), 0, 0);
        card.addView(note, np);

        return card;
    }



    private void showMainMenu() {
        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(18), dp(18), dp(18), dp(18));
        box.setBackground(roundStroke(CARD, 24, ORANGE, 2));

        TextView title = sectionTitle("MENU APPBLOCKER");
        title.setGravity(Gravity.CENTER);
        box.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView hint = new TextView(this);
        hint.setText("Szybki panel nawigacji. Najważniejsza nowość: Pani Policjantka — zadania z automatyczną konsekwencją.");
        hint.setTextColor(MUTED);
        hint.setTextSize(13);
        hint.setGravity(Gravity.CENTER);
        hint.setLineSpacing(0, 1.08f);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, -2);
        hp.setMargins(0, dp(10), 0, dp(12));
        box.addView(hint, hp);

        Button police = pillButton("Pani Policjantka", ORANGE, BLACK, true);
        box.addView(police, new LinearLayout.LayoutParams(-1, -2));
        police.setOnClickListener(v -> {
            dialog.dismiss();
            if (mainScroll != null && policeSection != null) mainScroll.post(() -> mainScroll.smoothScrollTo(0, policeSection.getTop()));
        });

        Button refresh = pillButton("Odśwież status", CARD_2, TEXT, false);
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, -2);
        rp.setMargins(0, dp(8), 0, 0);
        box.addView(refresh, rp);
        refresh.setOnClickListener(v -> {
            refreshStatus();
            renderPoliceTasks();
            Toast.makeText(this, "Status odświeżony.", Toast.LENGTH_SHORT).show();
        });

        Button close = pillButton("Zamknij", CARD_2, TEXT, false);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
        cp.setMargins(0, dp(8), 0, 0);
        box.addView(close, cp);
        close.setOnClickListener(v -> dialog.dismiss());

        dialog.setContentView(box);
        dialog.setOnShowListener(d -> {
            Window w = dialog.getWindow();
            if (w != null) {
                w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                w.setLayout((int)(getResources().getDisplayMetrics().widthPixels * 0.92f), -2);
            }
        });
        dialog.show();
    }

    private View buildPoliceCard() {
        LinearLayout card = card();
        policeSection = card;
        card.addView(sectionTitle("PANI POLICJANTKA"), new LinearLayout.LayoutParams(-1, -2));

        policeStatus = statusBox();
        card.addView(policeStatus, statusLp());

        TextView intro = note("Ustal zadanie, termin i konsekwencję. Jeśli nie klikniesz ZALICZ przed terminem, Pani Policjantka automatycznie wykona wcześniej zatwierdzoną karę.");
        card.addView(intro, noteLp());

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(-1, -2);
        ap.setMargins(0, dp(12), 0, dp(10));
        card.addView(actions, ap);

        Button add = pillButton("Dodaj zadanie", ORANGE, BLACK, true);
        actions.addView(add, new LinearLayout.LayoutParams(0, -2, 1));
        add.setOnClickListener(v -> showPoliceTaskDialog());
        addHorizontalSpace(actions, dp(8));
        Button refresh = pillButton("Odśwież", CARD_2, TEXT, false);
        actions.addView(refresh, new LinearLayout.LayoutParams(0, -2, 1));
        refresh.setOnClickListener(v -> { renderPoliceTasks(); refreshStatus(); });

        policeTaskContainer = new LinearLayout(this);
        policeTaskContainer.setOrientation(LinearLayout.VERTICAL);
        card.addView(policeTaskContainer, new LinearLayout.LayoutParams(-1, -2));
        renderPoliceTasks();
        return card;
    }


    private void showPoliceTaskDialog() {
        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        ScrollView scroll = new ScrollView(this);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(18), dp(18), dp(18), dp(18));
        box.setBackground(roundStroke(CARD, 24, ORANGE, 2));
        scroll.addView(box, new ScrollView.LayoutParams(-1, -2));

        TextView title = sectionTitle("NOWE ZADANIE POLICJANTKI");
        title.setGravity(Gravity.CENTER);
        box.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView warning = note("Wyraźna zgoda: jeśli nie zaliczysz zadania przed terminem, AppBlocker automatycznie uruchomi wszystkie wybrane konsekwencje. Możesz wybrać deadline jednorazowy albo codzienny, np. codziennie do 23:00.");
        box.addView(warning, noteLp());

        EditText taskTitle = dialogInput("Nazwa zadania, np. Trening / Nauka", InputType.TYPE_CLASS_TEXT, "");
        box.addView(taskTitle, new LinearLayout.LayoutParams(-1, -2));

        TextView scheduleSelected = new TextView(this);
        scheduleSelected.setText("Harmonogram: jednorazowo");
        scheduleSelected.setTextColor(ORANGE);
        scheduleSelected.setTypeface(null, Typeface.BOLD);
        scheduleSelected.setGravity(Gravity.CENTER);
        scheduleSelected.setPadding(dp(8), dp(12), dp(8), dp(8));
        box.addView(scheduleSelected, new LinearLayout.LayoutParams(-1, -2));
        final String[] scheduleType = new String[]{"once"};

        LinearLayout scheduleRow = new LinearLayout(this);
        scheduleRow.setOrientation(LinearLayout.HORIZONTAL);
        box.addView(scheduleRow, new LinearLayout.LayoutParams(-1, -2));
        Button onceBtn = pillButton("Jednorazowo", ORANGE, BLACK, true);
        scheduleRow.addView(onceBtn, new LinearLayout.LayoutParams(0, -2, 1));
        onceBtn.setOnClickListener(v -> {
            scheduleType[0] = "once";
            scheduleSelected.setText("Harmonogram: jednorazowo");
        });
        addHorizontalSpace(scheduleRow, dp(8));
        Button dailyBtn = pillButton("Codziennie", ORANGE_DARK, ORANGE, true);
        scheduleRow.addView(dailyBtn, new LinearLayout.LayoutParams(0, -2, 1));
        dailyBtn.setOnClickListener(v -> {
            scheduleType[0] = "daily";
            scheduleSelected.setText("Harmonogram: codziennie");
        });

        EditText deadline = dialogInput("Jednorazowo: deadline za ile minut?", InputType.TYPE_CLASS_NUMBER, "60");
        LinearLayout.LayoutParams dp1 = new LinearLayout.LayoutParams(-1, -2);
        dp1.setMargins(0, dp(10), 0, 0);
        box.addView(deadline, dp1);

        EditText dailyTime = dialogInput("Codziennie do godziny HH:mm, np. 23:00", InputType.TYPE_CLASS_TEXT, "23:00");
        LinearLayout.LayoutParams dtp = new LinearLayout.LayoutParams(-1, -2);
        dtp.setMargins(0, dp(10), 0, 0);
        box.addView(dailyTime, dtp);

        EditText penaltyMinutes = dialogInput("Każda kara ma trwać ile minut?", InputType.TYPE_CLASS_NUMBER, "30");
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(-1, -2);
        pp.setMargins(0, dp(10), 0, 0);
        box.addView(penaltyMinutes, pp);

        TextView selected = new TextView(this);
        selected.setTextColor(ORANGE);
        selected.setTypeface(null, Typeface.BOLD);
        selected.setGravity(Gravity.CENTER);
        selected.setPadding(dp(8), dp(12), dp(8), dp(8));
        box.addView(selected, new LinearLayout.LayoutParams(-1, -2));
        final Set<String> selectedActions = new HashSet<>();
        selectedActions.add(Prefs.POLICE_ACTION_CUFFS);
        updatePoliceActionText(selected, selectedActions);

        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        box.addView(row1, new LinearLayout.LayoutParams(-1, -2));
        addPoliceActionToggle(row1, "Kajdanki", Prefs.POLICE_ACTION_CUFFS, selectedActions, selected);
        addHorizontalSpace(row1, dp(6));
        addPoliceActionToggle(row1, "Ustawienia", Prefs.POLICE_ACTION_SETTINGS, selectedActions, selected);

        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams r2p = new LinearLayout.LayoutParams(-1, -2);
        r2p.setMargins(0, dp(6), 0, 0);
        box.addView(row2, r2p);
        addPoliceActionToggle(row2, "WWW", Prefs.POLICE_ACTION_BROWSER, selectedActions, selected);
        addHorizontalSpace(row2, dp(6));
        addPoliceActionToggle(row2, "Instalacje", Prefs.POLICE_ACTION_INSTALL, selectedActions, selected);
        addHorizontalSpace(row2, dp(6));
        addPoliceActionToggle(row2, "Cisza", Prefs.POLICE_ACTION_SILENCE, selectedActions, selected);

        Button all = pillButton("PEŁNY LOCKDOWN: kajdanki + ustawienia + WWW + instalacje + cisza", ORANGE_DARK, ORANGE, true);
        LinearLayout.LayoutParams allp = new LinearLayout.LayoutParams(-1, -2);
        allp.setMargins(0, dp(8), 0, 0);
        box.addView(all, allp);
        all.setOnClickListener(v -> {
            selectedActions.clear();
            selectedActions.add(Prefs.POLICE_ACTION_CUFFS);
            selectedActions.add(Prefs.POLICE_ACTION_SETTINGS);
            selectedActions.add(Prefs.POLICE_ACTION_BROWSER);
            selectedActions.add(Prefs.POLICE_ACTION_INSTALL);
            selectedActions.add(Prefs.POLICE_ACTION_SILENCE);
            updatePoliceActionText(selected, selectedActions);
        });

        EditText code = dialogInput("Kod kar, min. 4 znaki", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD, "");
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
        cp.setMargins(0, dp(12), 0, 0);
        box.addView(code, cp);

        EditText consent = dialogInput("Wpisz: ZGADZAM SIĘ NA KARY", InputType.TYPE_CLASS_TEXT, "");
        LinearLayout.LayoutParams csp = new LinearLayout.LayoutParams(-1, -2);
        csp.setMargins(0, dp(10), 0, 0);
        box.addView(consent, csp);

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(-1, -2);
        ap.setMargins(0, dp(16), 0, 0);
        box.addView(actions, ap);

        Button cancel = pillButton("Anuluj", CARD_2, TEXT, false);
        actions.addView(cancel, new LinearLayout.LayoutParams(0, -2, 1));
        cancel.setOnClickListener(v -> dialog.dismiss());
        addHorizontalSpace(actions, dp(8));
        Button ok = pillButton("Przyjmuję", ORANGE, BLACK, true);
        actions.addView(ok, new LinearLayout.LayoutParams(0, -2, 1));
        ok.setOnClickListener(v -> {
            int penaltyMin = parseMinutes(penaltyMinutes);
            if (penaltyMin <= 0) return;
            if (selectedActions.isEmpty()) {
                Toast.makeText(this, "Wybierz przynajmniej jedną karę.", Toast.LENGTH_LONG).show();
                return;
            }
            if (code.getText().toString().length() < 4) {
                Toast.makeText(this, "Kod musi mieć przynajmniej 4 znaki.", Toast.LENGTH_LONG).show();
                return;
            }
            if (!normalizeConsent(consent.getText().toString()).equals(normalizeConsent("ZGADZAM SIĘ NA KARY"))) {
                Toast.makeText(this, "Dla wyraźnej zgody wpisz: ZGADZAM SIĘ NA KARY", Toast.LENGTH_LONG).show();
                return;
            }
            if (selectedActions.contains(Prefs.POLICE_ACTION_SILENCE) && !hasDndPolicyAccess()) {
                Toast.makeText(this, "Dla kary Cisza nadaj najpierw uprawnienie DND.", Toast.LENGTH_LONG).show();
                startActivity(new Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS));
                return;
            }

            long deadlineMillis;
            int dailyHour = 23;
            int dailyMinute = 0;
            if ("daily".equals(scheduleType[0])) {
                int[] hm = parseHourMinute(dailyTime.getText().toString());
                if (hm == null) {
                    Toast.makeText(this, "Podaj godzinę w formacie HH:mm, np. 23:00", Toast.LENGTH_LONG).show();
                    return;
                }
                dailyHour = hm[0];
                dailyMinute = hm[1];
                deadlineMillis = nextDailyDeadlineMillis(dailyHour, dailyMinute);
            } else {
                int deadlineMin = parseMinutes(deadline);
                if (deadlineMin <= 0) return;
                deadlineMillis = System.currentTimeMillis() + deadlineMin * 60_000L;
            }

            Prefs.addPoliceTask(this,
                    taskTitle.getText().toString(),
                    deadlineMillis,
                    joinPoliceActions(selectedActions),
                    penaltyMin,
                    code.getText().toString(),
                    scheduleType[0],
                    dailyHour,
                    dailyMinute);
            startMonitorService();
            renderPoliceTasks();
            refreshStatus();
            Toast.makeText(this, "Pani Policjantka przyjęła rozbudowane zadanie.", Toast.LENGTH_LONG).show();
            dialog.dismiss();
        });

        dialog.setContentView(scroll);
        dialog.setOnShowListener(d -> {
            Window w = dialog.getWindow();
            if (w != null) {
                w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                w.setLayout((int)(getResources().getDisplayMetrics().widthPixels * 0.94f), (int)(getResources().getDisplayMetrics().heightPixels * 0.88f));
            }
        });
        dialog.show();
    }

    private EditText dialogInput(String hint, int inputType, String value) {
        EditText input = new EditText(this);
        input.setInputType(inputType);
        input.setHint(hint);
        input.setText(value);
        input.setGravity(Gravity.CENTER);
        input.setTextColor(ORANGE);
        input.setHintTextColor(MUTED);
        input.setTypeface(null, Typeface.BOLD);
        input.setTextSize(16);
        input.setBackground(roundStroke(BLACK, 14, ORANGE, 1));
        input.setPadding(dp(12), dp(10), dp(12), dp(10));
        return input;
    }

    private void addPoliceActionToggle(LinearLayout row, String label, String value, Set<String> selectedActions, TextView selected) {
        Button b = pillButton(label, ORANGE_DARK, ORANGE, true);
        row.addView(b, new LinearLayout.LayoutParams(0, -2, 1));
        b.setOnClickListener(v -> {
            if (selectedActions.contains(value)) selectedActions.remove(value);
            else selectedActions.add(value);
            updatePoliceActionText(selected, selectedActions);
        });
    }

    private void updatePoliceActionText(TextView selected, Set<String> actions) {
        selected.setText("Konsekwencje: " + policeActionsLabel(joinPoliceActions(actions)));
    }

    private String joinPoliceActions(Set<String> actions) {
        StringBuilder sb = new StringBuilder();
        for (String action : actions) {
            if (sb.length() > 0) sb.append(',');
            sb.append(action);
        }
        return sb.length() == 0 ? Prefs.POLICE_ACTION_CUFFS : sb.toString();
    }

    private int[] parseHourMinute(String text) {
        if (text == null) return null;
        String value = text.trim();
        if (value.matches("^[0-9]{1,2}$")) value = value + ":00";
        String[] parts = value.split(":");
        if (parts.length != 2) return null;
        try {
            int h = Integer.parseInt(parts[0].trim());
            int m = Integer.parseInt(parts[1].trim());
            if (h < 0 || h > 23 || m < 0 || m > 59) return null;
            return new int[]{h, m};
        } catch (Exception e) {
            return null;
        }
    }

    private long nextDailyDeadlineMillis(int hour, int minute) {
        java.util.Calendar c = java.util.Calendar.getInstance();
        long now = System.currentTimeMillis();
        c.setTimeInMillis(now);
        c.set(java.util.Calendar.HOUR_OF_DAY, hour);
        c.set(java.util.Calendar.MINUTE, minute);
        c.set(java.util.Calendar.SECOND, 0);
        c.set(java.util.Calendar.MILLISECOND, 0);
        if (c.getTimeInMillis() <= now) c.add(java.util.Calendar.DAY_OF_YEAR, 1);
        return c.getTimeInMillis();
    }

    private void renderPoliceTasks() {
        if (policeTaskContainer == null) return;
        policeTaskContainer.removeAllViews();
        List<Prefs.PoliceTask> tasks = Prefs.getPoliceTasks(this);
        if (tasks.isEmpty()) {
            TextView empty = note("Brak zadań. Dodaj zadanie, termin i karę, jeśli chcesz oddać kontrolę Pani Policjantce.");
            empty.setBackground(roundStroke(Color.rgb(18, 18, 18), 14, Color.rgb(45, 45, 45), 1));
            empty.setPadding(dp(10), dp(10), dp(10), dp(10));
            policeTaskContainer.addView(empty, new LinearLayout.LayoutParams(-1, -2));
            return;
        }
        for (Prefs.PoliceTask task : tasks) {
            policeTaskContainer.addView(createPoliceTaskRow(task), taskRowLp());
        }
    }

    private LinearLayout.LayoutParams taskRowLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 0, 0, dp(8));
        return lp;
    }

    private View createPoliceTaskRow(Prefs.PoliceTask task) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(dp(12), dp(10), dp(12), dp(10));
        int stroke = task.punished ? DANGER : task.done ? OK : ORANGE;
        row.setBackground(roundStroke(PANEL, 18, stroke, task.done ? 1 : 2));

        TextView title = new TextView(this);
        title.setText(task.title);
        title.setTextColor(TEXT);
        title.setTextSize(15);
        title.setTypeface(null, Typeface.BOLD);
        row.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView meta = new TextView(this);
        long left = task.deadlineMillis - System.currentTimeMillis();
        String state = task.done ? "ZALICZONE" : task.punished ? "KARA WYKONANA" : left > 0 ? "pozostało " + formatDuration(left) : "PO TERMINIE";
        String schedule = "daily".equals(task.scheduleType)
                ? " · codziennie do " + String.format(Locale.getDefault(), "%02d:%02d", task.dailyHour, task.dailyMinute)
                : " · jednorazowo";
        String stats = "daily".equals(task.scheduleType)
                ? " · zaliczone: " + task.doneCount + " · kary: " + task.punishedCount
                : "";
        meta.setText(state + schedule + " · kary: " + policeActionsLabel(task.actions) + " / " + task.penaltyMinutes + " min" + stats);
        meta.setTextColor(task.punished ? DANGER : task.done ? OK : ORANGE);
        meta.setTextSize(12);
        meta.setTypeface(null, Typeface.BOLD);
        row.addView(meta, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(-1, -2);
        ap.setMargins(0, dp(8), 0, 0);
        row.addView(actions, ap);

        Button done = pillButton("ZALICZ", task.done || task.punished ? CARD_2 : ORANGE, task.done || task.punished ? MUTED : BLACK, true);
        actions.addView(done, new LinearLayout.LayoutParams(0, -2, 1));
        done.setEnabled(!task.done && !task.punished);
        done.setOnClickListener(v -> {
            Prefs.markPoliceTaskDone(this, task.id);
            renderPoliceTasks();
            refreshStatus();
            Toast.makeText(this, "Zadanie zaliczone.", Toast.LENGTH_LONG).show();
        });
        addHorizontalSpace(actions, dp(8));
        Button remove = pillButton("USUŃ", CARD_2, TEXT, false);
        actions.addView(remove, new LinearLayout.LayoutParams(0, -2, 1));
        remove.setOnClickListener(v -> removePoliceTask(task));
        return row;
    }

    private void removePoliceTask(Prefs.PoliceTask task) {
        if (Prefs.isCuffsLocked(this)) {
            Toast.makeText(this, "Kajdanki nie pozwalają usuwać zadań. Pozostało: " + formatDuration(Prefs.getCuffsRemainingMillis(this)), Toast.LENGTH_LONG).show();
            return;
        }
        if (Prefs.getControlMode(this) == Prefs.MODE_ANKLET) {
            requireCodeThen("Usunięcie zadania", () -> {
                Prefs.removePoliceTask(this, task.id);
                renderPoliceTasks();
                refreshStatus();
            });
            return;
        }
        Prefs.removePoliceTask(this, task.id);
        renderPoliceTasks();
        refreshStatus();
    }


    private String policeActionsLabel(String actions) {
        if (actions == null || actions.trim().isEmpty()) return policeActionLabel(Prefs.POLICE_ACTION_CUFFS);
        StringBuilder sb = new StringBuilder();
        String[] parts = actions.split(",");
        for (String part : parts) {
            String a = part == null ? "" : part.trim();
            if (a.length() == 0) continue;
            if (sb.length() > 0) sb.append(" + ");
            sb.append(policeActionLabel(a));
        }
        return sb.length() == 0 ? policeActionLabel(Prefs.POLICE_ACTION_CUFFS) : sb.toString();
    }

    private String policeActionLabel(String action) {
        if (Prefs.POLICE_ACTION_SETTINGS.equals(action)) return "Blokada ustawień";
        if (Prefs.POLICE_ACTION_BROWSER.equals(action)) return "Blokada przeglądarek";
        if (Prefs.POLICE_ACTION_INSTALL.equals(action)) return "Blokada instalacji";
        if (Prefs.POLICE_ACTION_SILENCE.equals(action)) return "Tryb ciszy";
        return "Różowe kajdanki";
    }

    private View buildSettingsLockCard() {
        LinearLayout card = card();
        card.addView(sectionTitle("BLOKADA USTAWIEŃ"), new LinearLayout.LayoutParams(-1, -2));

        settingsLockStatus = new TextView(this);
        settingsLockStatus.setTextSize(13);
        settingsLockStatus.setTypeface(null, Typeface.BOLD);
        settingsLockStatus.setPadding(dp(12), dp(10), dp(12), dp(10));
        LinearLayout.LayoutParams ssp = new LinearLayout.LayoutParams(-1, -2);
        ssp.setMargins(0, dp(10), 0, dp(10));
        card.addView(settingsLockStatus, ssp);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        card.addView(row, new LinearLayout.LayoutParams(-1, -2));

        TextView label = new TextView(this);
        label.setText("Czas blokady w minutach");
        label.setTextSize(15);
        label.setTextColor(MUTED);
        row.addView(label, new LinearLayout.LayoutParams(0, -2, 1));

        settingsLockMinutesInput = new EditText(this);
        settingsLockMinutesInput.setInputType(InputType.TYPE_CLASS_NUMBER);
        settingsLockMinutesInput.setText("30");
        settingsLockMinutesInput.setSelectAllOnFocus(true);
        settingsLockMinutesInput.setGravity(Gravity.CENTER);
        settingsLockMinutesInput.setTextColor(ORANGE);
        settingsLockMinutesInput.setTypeface(null, Typeface.BOLD);
        settingsLockMinutesInput.setTextSize(18);
        settingsLockMinutesInput.setPadding(dp(12), dp(8), dp(12), dp(8));
        settingsLockMinutesInput.setBackground(roundStroke(BLACK, 14, ORANGE, 1));
        row.addView(settingsLockMinutesInput, new LinearLayout.LayoutParams(dp(112), -2));

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(-1, -2);
        ap.setMargins(0, dp(12), 0, 0);
        card.addView(actions, ap);

        Button start = pillButton("Zablokuj ustawienia", ORANGE, BLACK, true);
        actions.addView(start, new LinearLayout.LayoutParams(0, -2, 1));
        start.setOnClickListener(v -> showSettingsLockDialog());

        addHorizontalSpace(actions, dp(8));

        Button clear = pillButton("Usuń", CARD_2, TEXT, false);
        actions.addView(clear, new LinearLayout.LayoutParams(0, -2, 1));
        clear.setOnClickListener(v -> removeSettingsLock());

        TextView note = new TextView(this);
        note.setText("Wymaga jawnej zgody tekstowej. Do końca czasu próba wejścia w Ustawienia/Bezpieczeństwo Xiaomi będzie wyrzucana na ekran główny. Po czasie blokada wygaśnie automatycznie.");
        note.setTextSize(12);
        note.setTextColor(MUTED);
        note.setGravity(Gravity.CENTER);
        note.setLineSpacing(0, 1.08f);
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(-1, -2);
        np.setMargins(0, dp(10), 0, 0);
        card.addView(note, np);

        return card;
    }



    private TextView statusBox() {
        TextView v = new TextView(this);
        v.setTextSize(13);
        v.setTypeface(null, Typeface.BOLD);
        v.setPadding(dp(12), dp(10), dp(12), dp(10));
        return v;
    }

    private LinearLayout.LayoutParams statusLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(10), 0, dp(10));
        return lp;
    }

    private EditText addMinutesRow(LinearLayout card, String labelText, String defaultValue) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        card.addView(row, new LinearLayout.LayoutParams(-1, -2));

        TextView label = new TextView(this);
        label.setText(labelText);
        label.setTextSize(15);
        label.setTextColor(MUTED);
        row.addView(label, new LinearLayout.LayoutParams(0, -2, 1));

        EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_NUMBER);
        input.setText(defaultValue);
        input.setSelectAllOnFocus(true);
        input.setGravity(Gravity.CENTER);
        input.setTextColor(ORANGE);
        input.setTypeface(null, Typeface.BOLD);
        input.setTextSize(18);
        input.setPadding(dp(12), dp(8), dp(12), dp(8));
        input.setBackground(roundStroke(BLACK, 14, ORANGE, 1));
        row.addView(input, new LinearLayout.LayoutParams(dp(112), -2));
        return input;
    }

    private void addStartRemoveRow(LinearLayout card, String startText, SimpleAction startAction, String removeText, SimpleAction removeAction) {
        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(-1, -2);
        ap.setMargins(0, dp(12), 0, 0);
        card.addView(actions, ap);

        Button start = pillButton(startText, ORANGE, BLACK, true);
        actions.addView(start, new LinearLayout.LayoutParams(0, -2, 1));
        start.setOnClickListener(v -> startAction.run());
        addHorizontalSpace(actions, dp(8));
        Button remove = pillButton(removeText, CARD_2, TEXT, false);
        actions.addView(remove, new LinearLayout.LayoutParams(0, -2, 1));
        remove.setOnClickListener(v -> removeAction.run());
    }

    private TextView note(String text) {
        TextView note = new TextView(this);
        note.setText(text);
        note.setTextSize(12);
        note.setTextColor(MUTED);
        note.setGravity(Gravity.CENTER);
        note.setLineSpacing(0, 1.08f);
        return note;
    }

    private LinearLayout.LayoutParams noteLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(10), 0, 0);
        return lp;
    }

    private View buildInstallerLockCard() {
        LinearLayout card = card();
        card.addView(sectionTitle("BLOKADA SKLEPÓW I APK"), new LinearLayout.LayoutParams(-1, -2));
        installLockStatus = statusBox();
        card.addView(installLockStatus, statusLp());
        installLockMinutesInput = addMinutesRow(card, "Czas blokady instalacji", "30");
        addStartRemoveRow(card,
                "Zablokuj instalacje",
                () -> showInstallLockDialog(),
                "Usuń",
                () -> removeInstallLock());
        TextView note = note("Czasowo blokuje Sklep Play/Mi Picks i instalatory APK. Wymaga zgody: BLOKUJĘ INSTALACJE.");
        card.addView(note, noteLp());
        return card;
    }

    private View buildBrowserLockCard() {
        LinearLayout card = card();
        card.addView(sectionTitle("BLOKADA PRZEGLĄDAREK"), new LinearLayout.LayoutParams(-1, -2));
        browserLockStatus = statusBox();
        card.addView(browserLockStatus, statusLp());
        browserLockMinutesInput = addMinutesRow(card, "Czas blokady przeglądarek", "30");
        addStartRemoveRow(card,
                "Zablokuj przeglądarki",
                () -> showBrowserLockDialog(),
                "Usuń",
                () -> removeBrowserLock());
        TextView note = note("Blokuje popularne przeglądarki: Chrome, Firefox, Brave, Edge, Opera, Mi Browser, Samsung Internet itd. Zgoda: BLOKUJĘ PRZEGLĄDARKI.");
        card.addView(note, noteLp());
        return card;
    }

    private View buildSilenceLockCard() {
        LinearLayout card = card();
        card.addView(sectionTitle("TRYB CISZY"), new LinearLayout.LayoutParams(-1, -2));
        silenceLockStatus = statusBox();
        card.addView(silenceLockStatus, statusLp());
        silenceLockMinutesInput = addMinutesRow(card, "Czas ciszy", "30");

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(-1, -2);
        ap.setMargins(0, dp(12), 0, 0);
        card.addView(actions, ap);

        Button start = pillButton("Start ciszy", ORANGE, BLACK, true);
        actions.addView(start, new LinearLayout.LayoutParams(0, -2, 1));
        start.setOnClickListener(v -> showSilenceLockDialog());
        addHorizontalSpace(actions, dp(8));
        Button permission = pillButton("Uprawnienie DND", CARD_2, TEXT, false);
        actions.addView(permission, new LinearLayout.LayoutParams(0, -2, 1));
        permission.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)));

        Button clear = pillButton("Usuń timer ciszy", CARD_2, TEXT, false);
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(-1, -2);
        clp.setMargins(0, dp(8), 0, 0);
        card.addView(clear, clp);
        clear.setOnClickListener(v -> removeSilenceLock());

        TextView note = note("Włącza Nie przeszkadzać na określony czas. Android wymaga dostępu do trybu Nie przeszkadzać. Zgoda: WŁĄCZAM CISZĘ.");
        card.addView(note, noteLp());
        return card;
    }

    private View buildWallpaperCard() {
        LinearLayout card = card();
        card.addView(sectionTitle("AUTO TAPETA"), new LinearLayout.LayoutParams(-1, -2));

        wallpaperStatus = new TextView(this);
        wallpaperStatus.setTextSize(13);
        wallpaperStatus.setTypeface(null, Typeface.BOLD);
        wallpaperStatus.setPadding(dp(12), dp(10), dp(12), dp(10));
        LinearLayout.LayoutParams wsp = new LinearLayout.LayoutParams(-1, -2);
        wsp.setMargins(0, dp(10), 0, dp(10));
        card.addView(wallpaperStatus, wsp);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        card.addView(row, new LinearLayout.LayoutParams(-1, -2));

        TextView label = new TextView(this);
        label.setText("Czas tapety w minutach");
        label.setTextSize(15);
        label.setTextColor(MUTED);
        row.addView(label, new LinearLayout.LayoutParams(0, -2, 1));

        wallpaperMinutesInput = new EditText(this);
        wallpaperMinutesInput.setInputType(InputType.TYPE_CLASS_NUMBER);
        wallpaperMinutesInput.setText("30");
        wallpaperMinutesInput.setSelectAllOnFocus(true);
        wallpaperMinutesInput.setGravity(Gravity.CENTER);
        wallpaperMinutesInput.setTextColor(ORANGE);
        wallpaperMinutesInput.setTypeface(null, Typeface.BOLD);
        wallpaperMinutesInput.setTextSize(18);
        wallpaperMinutesInput.setPadding(dp(12), dp(8), dp(12), dp(8));
        wallpaperMinutesInput.setBackground(roundStroke(BLACK, 14, ORANGE, 1));
        row.addView(wallpaperMinutesInput, new LinearLayout.LayoutParams(dp(112), -2));

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(-1, -2);
        ap.setMargins(0, dp(12), 0, 0);
        card.addView(actions, ap);

        Button pick = pillButton("Wybierz z galerii", CARD_2, TEXT, false);
        actions.addView(pick, new LinearLayout.LayoutParams(0, -2, 1));
        pick.setOnClickListener(v -> pickWallpaperImage());

        addHorizontalSpace(actions, dp(8));

        Button start = pillButton("Ustaw tapetę", ORANGE, BLACK, true);
        actions.addView(start, new LinearLayout.LayoutParams(0, -2, 1));
        start.setOnClickListener(v -> startWallpaperTimer());

        Button clear = pillButton("Usuń timer auto-tapety", CARD_2, TEXT, false);
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(-1, -2);
        clp.setMargins(0, dp(8), 0, 0);
        card.addView(clear, clp);
        clear.setOnClickListener(v -> clearWallpaperLock());

        TextView note = new TextView(this);
        note.setText("Bezpieczny tryb: Android/Xiaomi nadal może pozwolić ręcznie zmienić tapetę, ale AppBlocker będzie ją okresowo przywracał do końca timera. Po restarcie telefonu też spróbuje ustawić ją ponownie, jeśli timer nadal trwa.");
        note.setTextSize(12);
        note.setTextColor(MUTED);
        note.setGravity(Gravity.CENTER);
        note.setLineSpacing(0, 1.08f);
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(-1, -2);
        np.setMargins(0, dp(10), 0, 0);
        card.addView(note, np);

        return card;
    }

    private View buildScreenshotCard() {
        LinearLayout card = card();
        card.addView(sectionTitle("JAWNY MONITOR SCREENSHOTÓW"), new LinearLayout.LayoutParams(-1, -2));

        screenshotStatus = new TextView(this);
        screenshotStatus.setTextSize(13);
        screenshotStatus.setTypeface(null, Typeface.BOLD);
        screenshotStatus.setPadding(dp(12), dp(10), dp(12), dp(10));
        LinearLayout.LayoutParams ssp = new LinearLayout.LayoutParams(-1, -2);
        ssp.setMargins(0, dp(10), 0, dp(10));
        card.addView(screenshotStatus, ssp);

        screenshotIntervalLabel = new TextView(this);
        screenshotIntervalMin = Prefs.getScreenshotIntervalMin(this);
        screenshotIntervalLabel.setText("Co " + screenshotIntervalMin + " min");
        screenshotIntervalLabel.setTextColor(ORANGE);
        screenshotIntervalLabel.setTypeface(null, Typeface.BOLD);
        screenshotIntervalLabel.setTextSize(16);
        screenshotIntervalLabel.setGravity(Gravity.CENTER);
        card.addView(screenshotIntervalLabel, new LinearLayout.LayoutParams(-1, -2));

        SeekBar slider = new SeekBar(this);
        slider.setMax(18); // 2..20 min
        slider.setProgress(screenshotIntervalMin - 2);
        slider.setPadding(0, dp(8), 0, dp(8));
        card.addView(slider, new LinearLayout.LayoutParams(-1, -2));
        slider.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                screenshotIntervalMin = progress + 2;
                Prefs.setScreenshotIntervalMin(MainActivity.this, screenshotIntervalMin);
                screenshotIntervalLabel.setText("Co " + screenshotIntervalMin + " min");
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) { }
            @Override public void onStopTrackingTouch(SeekBar seekBar) { }
        });

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        card.addView(actions, new LinearLayout.LayoutParams(-1, -2));

        Button start = pillButton("Start monitor", ORANGE, BLACK, true);
        actions.addView(start, new LinearLayout.LayoutParams(0, -2, 1));
        start.setOnClickListener(v -> requestScreenshotMonitor());

        addHorizontalSpace(actions, dp(8));

        Button stop = pillButton("Stop", CARD_2, TEXT, false);
        actions.addView(stop, new LinearLayout.LayoutParams(0, -2, 1));
        stop.setOnClickListener(v -> stopScreenshotMonitor());

        TextView note = new TextView(this);
        note.setText("Android wymaga jawnej zgody i pokazuje powiadomienie. Screenshoty są zapisywane w Galerii: Pictures/monitor. Tego trybu nie robię ukrytego ani nieusuwalnego.");
        note.setTextSize(12);
        note.setTextColor(MUTED);
        note.setGravity(Gravity.CENTER);
        note.setLineSpacing(0, 1.08f);
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(-1, -2);
        np.setMargins(0, dp(10), 0, 0);
        card.addView(note, np);

        return card;
    }

    private View buildListHeader() {
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(16), dp(13), dp(16), dp(13));
        header.setBackground(roundStroke(CARD, 18, Color.rgb(35, 35, 35), 1));

        TextView title = new TextView(this);
        title.setText("APLIKACJE");
        title.setTextColor(TEXT);
        title.setTextSize(16);
        title.setTypeface(null, Typeface.BOLD);
        title.setLetterSpacing(0.06f);
        header.addView(title, new LinearLayout.LayoutParams(0, -2, 1));

        selectedCount = new TextView(this);
        selectedCount.setTextColor(BLACK);
        selectedCount.setTextSize(13);
        selectedCount.setTypeface(null, Typeface.BOLD);
        selectedCount.setGravity(Gravity.CENTER);
        selectedCount.setPadding(dp(12), dp(7), dp(12), dp(7));
        selectedCount.setBackground(round(ORANGE, 999));
        header.addView(selectedCount, new LinearLayout.LayoutParams(-2, -2));

        return header;
    }



    private interface CodeAction { void run(String code); }
    private interface SimpleAction { void run(); }
    private interface TimedCodeAction { void run(int minutes, String code); }

    private void activateFreeMode() {
        if (Prefs.isCuffsLocked(this)) {
            Toast.makeText(this, "Różowe kajdanki aktywne jeszcze: " + formatDuration(Prefs.getCuffsRemainingMillis(this)), Toast.LENGTH_LONG).show();
            return;
        }
        if (Prefs.getControlMode(this) == Prefs.MODE_ANKLET) {
            requireCodeThen("Wyjście z opaski", () -> {
                Prefs.setFreeMode(this);
                refreshStatus();
                Toast.makeText(this, "Tryb wolny aktywny.", Toast.LENGTH_LONG).show();
            });
            return;
        }
        Prefs.setFreeMode(this);
        refreshStatus();
        Toast.makeText(this, "Tryb wolny aktywny.", Toast.LENGTH_LONG).show();
    }

    private void showSetCodeDialog(String titleText, String hintText, CodeAction action) {
        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(18), dp(18), dp(18), dp(18));
        box.setBackground(roundStroke(CARD, 24, ORANGE, 2));

        TextView title = sectionTitle(titleText);
        title.setGravity(Gravity.CENTER);
        box.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView hint = new TextView(this);
        hint.setText(hintText);
        hint.setTextColor(MUTED);
        hint.setTextSize(13);
        hint.setGravity(Gravity.CENTER);
        hint.setLineSpacing(0, 1.08f);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, -2);
        hp.setMargins(0, dp(10), 0, dp(10));
        box.addView(hint, hp);

        EditText code = new EditText(this);
        code.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        code.setHint("Kod, min. 4 znaki");
        code.setGravity(Gravity.CENTER);
        code.setTextColor(ORANGE);
        code.setHintTextColor(MUTED);
        code.setTypeface(null, Typeface.BOLD);
        code.setTextSize(18);
        code.setBackground(roundStroke(BLACK, 14, ORANGE, 1));
        code.setPadding(dp(12), dp(10), dp(12), dp(10));
        box.addView(code, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(-1, -2);
        ap.setMargins(0, dp(16), 0, 0);
        box.addView(actions, ap);

        Button cancel = pillButton("Anuluj", CARD_2, TEXT, false);
        actions.addView(cancel, new LinearLayout.LayoutParams(0, -2, 1));
        cancel.setOnClickListener(v -> dialog.dismiss());

        addHorizontalSpace(actions, dp(8));

        Button ok = pillButton("Potwierdź", ORANGE, BLACK, true);
        actions.addView(ok, new LinearLayout.LayoutParams(0, -2, 1));
        ok.setOnClickListener(v -> {
            String value = code.getText().toString();
            if (value.length() < 4) {
                Toast.makeText(this, "Kod musi mieć przynajmniej 4 znaki.", Toast.LENGTH_LONG).show();
                return;
            }
            action.run(value);
            dialog.dismiss();
        });

        dialog.setContentView(box);
        dialog.setOnShowListener(d -> {
            Window w = dialog.getWindow();
            if (w != null) {
                w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                w.setLayout((int)(getResources().getDisplayMetrics().widthPixels * 0.92f), -2);
            }
        });
        dialog.show();
    }

    private void showCuffsDialog() {
        if (Prefs.isCuffsLocked(this)) {
            Toast.makeText(this, "Kajdanki już aktywne: " + formatDuration(Prefs.getCuffsRemainingMillis(this)), Toast.LENGTH_LONG).show();
            return;
        }

        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(18), dp(18), dp(18), dp(18));
        box.setBackground(roundStroke(CARD, 24, ORANGE, 2));

        TextView title = sectionTitle("RÓŻOWE KAJDANKI");
        title.setGravity(Gravity.CENTER);
        box.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView warning = new TextView(this);
        warning.setText("Wyraźna zgoda: do końca czasu aplikacja nie pozwoli usuwać/stopować blokad, zmieniać auto-tapety ani wyłączać monitora screenshotów z poziomu UI. Administrator urządzenia utrudnia odinstalowanie, ale nadal możesz cofnąć go w ustawieniach Androida.");
        warning.setTextColor(ORANGE);
        warning.setTextSize(13);
        warning.setGravity(Gravity.CENTER);
        warning.setLineSpacing(0, 1.08f);
        LinearLayout.LayoutParams wp = new LinearLayout.LayoutParams(-1, -2);
        wp.setMargins(0, dp(10), 0, dp(10));
        box.addView(warning, wp);

        EditText minutes = new EditText(this);
        minutes.setInputType(InputType.TYPE_CLASS_NUMBER);
        minutes.setText("60");
        minutes.setGravity(Gravity.CENTER);
        minutes.setTextColor(ORANGE);
        minutes.setTypeface(null, Typeface.BOLD);
        minutes.setTextSize(18);
        minutes.setBackground(roundStroke(BLACK, 14, ORANGE, 1));
        minutes.setPadding(dp(12), dp(10), dp(12), dp(10));
        box.addView(minutes, new LinearLayout.LayoutParams(-1, -2));

        TextView minHint = new TextView(this);
        minHint.setText("Czas kajdanek w minutach, maks. 24h");
        minHint.setTextColor(MUTED);
        minHint.setTextSize(12);
        minHint.setGravity(Gravity.CENTER);
        box.addView(minHint, new LinearLayout.LayoutParams(-1, -2));

        EditText code = new EditText(this);
        code.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        code.setHint("Kod, min. 4 znaki");
        code.setGravity(Gravity.CENTER);
        code.setTextColor(ORANGE);
        code.setHintTextColor(MUTED);
        code.setTypeface(null, Typeface.BOLD);
        code.setTextSize(18);
        code.setBackground(roundStroke(BLACK, 14, ORANGE, 1));
        code.setPadding(dp(12), dp(10), dp(12), dp(10));
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
        cp.setMargins(0, dp(12), 0, 0);
        box.addView(code, cp);

        EditText consent = new EditText(this);
        consent.setInputType(InputType.TYPE_CLASS_TEXT);
        consent.setHint("Wpisz: ZGADZAM SIĘ");
        consent.setGravity(Gravity.CENTER);
        consent.setTextColor(ORANGE);
        consent.setHintTextColor(MUTED);
        consent.setTypeface(null, Typeface.BOLD);
        consent.setTextSize(16);
        consent.setBackground(roundStroke(BLACK, 14, ORANGE, 1));
        consent.setPadding(dp(12), dp(10), dp(12), dp(10));
        LinearLayout.LayoutParams cp2 = new LinearLayout.LayoutParams(-1, -2);
        cp2.setMargins(0, dp(12), 0, 0);
        box.addView(consent, cp2);

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(-1, -2);
        ap.setMargins(0, dp(16), 0, 0);
        box.addView(actions, ap);

        Button cancel = pillButton("Anuluj", CARD_2, TEXT, false);
        actions.addView(cancel, new LinearLayout.LayoutParams(0, -2, 1));
        cancel.setOnClickListener(v -> dialog.dismiss());

        addHorizontalSpace(actions, dp(8));

        Button ok = pillButton("Aktywuj", ORANGE, BLACK, true);
        actions.addView(ok, new LinearLayout.LayoutParams(0, -2, 1));
        ok.setOnClickListener(v -> {
            int mins = parseMinutes(minutes);
            if (mins <= 0) return;
            String c = code.getText().toString();
            if (c.length() < 4) {
                Toast.makeText(this, "Kod musi mieć przynajmniej 4 znaki.", Toast.LENGTH_LONG).show();
                return;
            }
            String typed = consent.getText().toString().trim();
            if (!typed.equalsIgnoreCase("ZGADZAM SIĘ") && !typed.equalsIgnoreCase("ZGADZAM SIE")) {
                Toast.makeText(this, "Dla wyraźnej zgody wpisz: ZGADZAM SIĘ", Toast.LENGTH_LONG).show();
                return;
            }
            Prefs.setCuffsMode(this, c, System.currentTimeMillis() + mins * 60_000L);
            refreshStatus();
            Toast.makeText(this, "Różowe kajdanki aktywne na " + mins + " min.", Toast.LENGTH_LONG).show();
            if (!isDeviceAdminActive()) requestDeviceAdmin();
            dialog.dismiss();
        });

        dialog.setContentView(box);
        dialog.setOnShowListener(d -> {
            Window w = dialog.getWindow();
            if (w != null) {
                w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                w.setLayout((int)(getResources().getDisplayMetrics().widthPixels * 0.92f), -2);
            }
        });
        dialog.show();
    }

    private void requireCodeThen(String title, SimpleAction action) {
        showSetCodeDialog(title, "Wpisz ustawiony kod kontroli.", code -> {
            if (!Prefs.verifyControlCode(this, code)) {
                Toast.makeText(this, "Błędny kod.", Toast.LENGTH_LONG).show();
                return;
            }
            action.run();
        });
    }

    private boolean denyIfCuffs(String actionName) {
        if (!Prefs.isCuffsLocked(this)) return false;
        Toast.makeText(this, actionName + " zablokowane przez różowe kajdanki. Pozostało: " + formatDuration(Prefs.getCuffsRemainingMillis(this)), Toast.LENGTH_LONG).show();
        return true;
    }

    private void requireProtectedChange(String title, SimpleAction action) {
        if (denyIfCuffs(title)) return;
        if (Prefs.getControlMode(this) == Prefs.MODE_ANKLET) {
            requireCodeThen(title, action);
        } else {
            action.run();
        }
    }

    private void requestDeviceAdmin() {
        try {
            Intent intent = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
            intent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, getDeviceAdminComponent());
            intent.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                    "Różowe kajdanki: utrudnia odinstalowanie AppBlocker, dopóki sam nie cofniesz administratora urządzenia w ustawieniach Androida.");
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "Nie udało się otworzyć administratora urządzenia.", Toast.LENGTH_LONG).show();
        }
    }

    private boolean isDeviceAdminActive() {
        try {
            DevicePolicyManager dpm = (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);
            return dpm != null && dpm.isAdminActive(getDeviceAdminComponent());
        } catch (Exception e) {
            return false;
        }
    }

    private ComponentName getDeviceAdminComponent() {
        return new ComponentName(this, AppDeviceAdminReceiver.class);
    }



    private void showInstallLockDialog() {
        showTimedConsentDialog(
                "BLOKADA SKLEPÓW I APK",
                "Do końca czasu AppBlocker będzie blokował Sklep Play/Mi Picks oraz instalatory APK.",
                installLockMinutesInput,
                "BLOKUJĘ INSTALACJE",
                (minutes, code) -> {
                    Prefs.setInstallLock(this, System.currentTimeMillis() + minutes * 60_000L, code);
                    startMonitorService();
                    refreshStatus();
                    Toast.makeText(this, "Instalacje zablokowane na " + minutes + " min.", Toast.LENGTH_LONG).show();
                }
        );
    }

    private void removeInstallLock() {
        removeSpecialLock("USUŃ BLOKADĘ INSTALACJI", "install");
    }

    private void showBrowserLockDialog() {
        showTimedConsentDialog(
                "BLOKADA PRZEGLĄDAREK",
                "Do końca czasu AppBlocker będzie blokował popularne przeglądarki internetowe.",
                browserLockMinutesInput,
                "BLOKUJĘ PRZEGLĄDARKI",
                (minutes, code) -> {
                    Prefs.setBrowserLock(this, System.currentTimeMillis() + minutes * 60_000L, code);
                    startMonitorService();
                    refreshStatus();
                    Toast.makeText(this, "Przeglądarki zablokowane na " + minutes + " min.", Toast.LENGTH_LONG).show();
                }
        );
    }

    private void removeBrowserLock() {
        removeSpecialLock("USUŃ BLOKADĘ PRZEGLĄDAREK", "browser");
    }

    private void showSilenceLockDialog() {
        if (!hasDndPolicyAccess()) {
            Toast.makeText(this, "Najpierw nadaj dostęp do trybu Nie przeszkadzać.", Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS));
            return;
        }
        showTimedConsentDialog(
                "TRYB CISZY",
                "Do końca czasu AppBlocker będzie utrzymywał tryb Nie przeszkadzać.",
                silenceLockMinutesInput,
                "WŁĄCZAM CISZĘ",
                (minutes, code) -> {
                    Prefs.setSilenceLock(this, System.currentTimeMillis() + minutes * 60_000L, code);
                    applyDndNow(true);
                    startMonitorService();
                    refreshStatus();
                    Toast.makeText(this, "Tryb ciszy aktywny na " + minutes + " min.", Toast.LENGTH_LONG).show();
                }
        );
    }

    private void removeSilenceLock() {
        if (Prefs.isCuffsLocked(this)) {
            Toast.makeText(this, "Kajdanki nie pozwalają usuwać trybu ciszy. Pozostało: " + formatDuration(Prefs.getCuffsRemainingMillis(this)), Toast.LENGTH_LONG).show();
            return;
        }
        removeSpecialLock("USUŃ TRYB CISZY", "silence");
    }

    private void showTimedConsentDialog(String titleText, String warningText, EditText minutesSource, String consentPhrase, TimedCodeAction action) {
        if (!hasRequiredPermissions() && !"TRYB CISZY".equals(titleText)) {
            Toast.makeText(this, "Najpierw włącz Dostępność awaryjną albo Usage+Nakładkę.", Toast.LENGTH_LONG).show();
            ensurePermissionsOrOpenSettings();
            return;
        }

        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(18), dp(18), dp(18), dp(18));
        box.setBackground(roundStroke(CARD, 24, ORANGE, 2));

        TextView title = sectionTitle(titleText);
        title.setGravity(Gravity.CENTER);
        box.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView warning = new TextView(this);
        warning.setText("Wyraźna zgoda: " + warningText + " Blokada wygaśnie automatycznie.");
        warning.setTextColor(ORANGE);
        warning.setTextSize(13);
        warning.setGravity(Gravity.CENTER);
        warning.setLineSpacing(0, 1.08f);
        LinearLayout.LayoutParams wp = new LinearLayout.LayoutParams(-1, -2);
        wp.setMargins(0, dp(10), 0, dp(10));
        box.addView(warning, wp);

        EditText minutes = new EditText(this);
        minutes.setInputType(InputType.TYPE_CLASS_NUMBER);
        minutes.setText(minutesSource == null ? "30" : minutesSource.getText().toString());
        minutes.setGravity(Gravity.CENTER);
        minutes.setTextColor(ORANGE);
        minutes.setTypeface(null, Typeface.BOLD);
        minutes.setTextSize(18);
        minutes.setBackground(roundStroke(BLACK, 14, ORANGE, 1));
        minutes.setPadding(dp(12), dp(10), dp(12), dp(10));
        box.addView(minutes, new LinearLayout.LayoutParams(-1, -2));

        TextView minHint = new TextView(this);
        minHint.setText("Czas w minutach, maks. 24h");
        minHint.setTextColor(MUTED);
        minHint.setTextSize(12);
        minHint.setGravity(Gravity.CENTER);
        box.addView(minHint, new LinearLayout.LayoutParams(-1, -2));

        EditText code = new EditText(this);
        code.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        code.setHint("Kod usunięcia, min. 4 znaki");
        code.setGravity(Gravity.CENTER);
        code.setTextColor(ORANGE);
        code.setHintTextColor(MUTED);
        code.setTypeface(null, Typeface.BOLD);
        code.setTextSize(17);
        code.setBackground(roundStroke(BLACK, 14, ORANGE, 1));
        code.setPadding(dp(12), dp(10), dp(12), dp(10));
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
        cp.setMargins(0, dp(12), 0, 0);
        box.addView(code, cp);

        EditText consent = new EditText(this);
        consent.setInputType(InputType.TYPE_CLASS_TEXT);
        consent.setHint("Wpisz: " + consentPhrase);
        consent.setGravity(Gravity.CENTER);
        consent.setTextColor(ORANGE);
        consent.setHintTextColor(MUTED);
        consent.setTypeface(null, Typeface.BOLD);
        consent.setTextSize(16);
        consent.setBackground(roundStroke(BLACK, 14, ORANGE, 1));
        consent.setPadding(dp(12), dp(10), dp(12), dp(10));
        LinearLayout.LayoutParams cp2 = new LinearLayout.LayoutParams(-1, -2);
        cp2.setMargins(0, dp(12), 0, 0);
        box.addView(consent, cp2);

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(-1, -2);
        ap.setMargins(0, dp(16), 0, 0);
        box.addView(actions, ap);

        Button cancel = pillButton("Anuluj", CARD_2, TEXT, false);
        actions.addView(cancel, new LinearLayout.LayoutParams(0, -2, 1));
        cancel.setOnClickListener(v -> dialog.dismiss());
        addHorizontalSpace(actions, dp(8));
        Button ok = pillButton("Aktywuj", ORANGE, BLACK, true);
        actions.addView(ok, new LinearLayout.LayoutParams(0, -2, 1));
        ok.setOnClickListener(v -> {
            int mins = parseMinutes(minutes);
            if (mins <= 0) return;
            String codeValue = code.getText().toString();
            if (codeValue.length() < 4) {
                Toast.makeText(this, "Kod musi mieć przynajmniej 4 znaki.", Toast.LENGTH_LONG).show();
                return;
            }
            if (!normalizeConsent(consent.getText().toString()).equals(normalizeConsent(consentPhrase))) {
                Toast.makeText(this, "Dla wyraźnej zgody wpisz: " + consentPhrase, Toast.LENGTH_LONG).show();
                return;
            }
            action.run(mins, codeValue);
            dialog.dismiss();
        });

        dialog.setContentView(box);
        dialog.setOnShowListener(d -> {
            Window w = dialog.getWindow();
            if (w != null) {
                w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                w.setLayout((int)(getResources().getDisplayMetrics().widthPixels * 0.92f), -2);
            }
        });
        dialog.show();
    }

    private String normalizeConsent(String text) {
        if (text == null) return "";
        return text.trim().toUpperCase(Locale.ROOT).replace('Ę', 'E').replace('Ą', 'A').replace('Ł', 'L').replace('Ó', 'O').replace('Ś', 'S').replace('Ż', 'Z').replace('Ź', 'Z').replace('Ć', 'C').replace('Ń', 'N');
    }

    private void removeSpecialLock(String titleText, String kind) {
        boolean active;
        if ("install".equals(kind)) active = Prefs.isInstallLockActive(this);
        else if ("browser".equals(kind)) active = Prefs.isBrowserLockActive(this);
        else if ("silence".equals(kind)) active = Prefs.isSilenceLockActive(this);
        else active = false;

        if (!active) {
            Toast.makeText(this, "Ta blokada nie jest aktywna.", Toast.LENGTH_LONG).show();
            return;
        }
        if (Prefs.isCuffsLocked(this)) {
            Toast.makeText(this, "Kajdanki blokują usuwanie. Pozostało: " + formatDuration(Prefs.getCuffsRemainingMillis(this)), Toast.LENGTH_LONG).show();
            return;
        }

        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(18), dp(18), dp(18), dp(18));
        box.setBackground(roundStroke(CARD, 24, ORANGE, 2));

        TextView title = sectionTitle(titleText);
        title.setGravity(Gravity.CENTER);
        box.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView hint = new TextView(this);
        hint.setText("Wpisz kod ustawiony przy tej blokadzie. W trybie opaski zadziała też kod opaski.");
        hint.setTextColor(MUTED);
        hint.setTextSize(13);
        hint.setGravity(Gravity.CENTER);
        hint.setLineSpacing(0, 1.08f);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, -2);
        hp.setMargins(0, dp(10), 0, dp(10));
        box.addView(hint, hp);

        EditText code = new EditText(this);
        code.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        code.setHint("Kod");
        code.setGravity(Gravity.CENTER);
        code.setTextColor(ORANGE);
        code.setHintTextColor(MUTED);
        code.setTypeface(null, Typeface.BOLD);
        code.setTextSize(18);
        code.setBackground(roundStroke(BLACK, 14, ORANGE, 1));
        code.setPadding(dp(12), dp(10), dp(12), dp(10));
        box.addView(code, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(-1, -2);
        ap.setMargins(0, dp(16), 0, 0);
        box.addView(actions, ap);
        Button cancel = pillButton("Anuluj", CARD_2, TEXT, false);
        actions.addView(cancel, new LinearLayout.LayoutParams(0, -2, 1));
        cancel.setOnClickListener(v -> dialog.dismiss());
        addHorizontalSpace(actions, dp(8));
        Button ok = pillButton("Usuń", ORANGE, BLACK, true);
        actions.addView(ok, new LinearLayout.LayoutParams(0, -2, 1));
        ok.setOnClickListener(v -> {
            String value = code.getText().toString();
            boolean valid = Prefs.verifyControlCode(this, value);
            if ("install".equals(kind)) valid = valid || Prefs.verifyInstallLockCode(this, value);
            if ("browser".equals(kind)) valid = valid || Prefs.verifyBrowserLockCode(this, value);
            if ("silence".equals(kind)) valid = valid || Prefs.verifySilenceLockCode(this, value);
            if (!valid) {
                Toast.makeText(this, "Błędny kod.", Toast.LENGTH_LONG).show();
                return;
            }
            if ("install".equals(kind)) Prefs.clearInstallLock(this);
            if ("browser".equals(kind)) Prefs.clearBrowserLock(this);
            if ("silence".equals(kind)) {
                Prefs.clearSilenceLock(this);
                applyDndNow(false);
            }
            refreshStatus();
            Toast.makeText(this, "Blokada usunięta.", Toast.LENGTH_LONG).show();
            dialog.dismiss();
        });
        dialog.setContentView(box);
        dialog.setOnShowListener(d -> {
            Window w = dialog.getWindow();
            if (w != null) {
                w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                w.setLayout((int)(getResources().getDisplayMetrics().widthPixels * 0.92f), -2);
            }
        });
        dialog.show();
    }

    private boolean hasDndPolicyAccess() {
        try {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            return nm != null && (Build.VERSION.SDK_INT < 23 || nm.isNotificationPolicyAccessGranted());
        } catch (Exception e) {
            return false;
        }
    }

    private void applyDndNow(boolean enable) {
        try {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm == null) return;
            if (Build.VERSION.SDK_INT >= 23 && !nm.isNotificationPolicyAccessGranted()) return;
            nm.setInterruptionFilter(enable ? NotificationManager.INTERRUPTION_FILTER_NONE : NotificationManager.INTERRUPTION_FILTER_ALL);
        } catch (Exception ignored) { }
    }

    private void showSettingsLockDialog() {
        if (!hasRequiredPermissions()) {
            Toast.makeText(this, "Najpierw włącz Dostępność awaryjną albo Usage+Nakładkę.", Toast.LENGTH_LONG).show();
            ensurePermissionsOrOpenSettings();
            return;
        }

        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(18), dp(18), dp(18), dp(18));
        box.setBackground(roundStroke(CARD, 24, ORANGE, 2));

        TextView title = sectionTitle("CZASOWA BLOKADA USTAWIEŃ");
        title.setGravity(Gravity.CENTER);
        box.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView warning = new TextView(this);
        warning.setText("Wyraźna zgoda: do końca ustawionego czasu AppBlocker będzie blokował wejście w Ustawienia Androida/Xiaomi. Blokada wygaśnie automatycznie.");
        warning.setTextColor(ORANGE);
        warning.setTextSize(13);
        warning.setGravity(Gravity.CENTER);
        warning.setLineSpacing(0, 1.08f);
        LinearLayout.LayoutParams wp = new LinearLayout.LayoutParams(-1, -2);
        wp.setMargins(0, dp(10), 0, dp(10));
        box.addView(warning, wp);

        EditText minutes = new EditText(this);
        minutes.setInputType(InputType.TYPE_CLASS_NUMBER);
        minutes.setText(settingsLockMinutesInput == null ? "30" : settingsLockMinutesInput.getText().toString());
        minutes.setGravity(Gravity.CENTER);
        minutes.setTextColor(ORANGE);
        minutes.setTypeface(null, Typeface.BOLD);
        minutes.setTextSize(18);
        minutes.setBackground(roundStroke(BLACK, 14, ORANGE, 1));
        minutes.setPadding(dp(12), dp(10), dp(12), dp(10));
        box.addView(minutes, new LinearLayout.LayoutParams(-1, -2));

        TextView minHint = new TextView(this);
        minHint.setText("Czas w minutach, maks. 24h");
        minHint.setTextColor(MUTED);
        minHint.setTextSize(12);
        minHint.setGravity(Gravity.CENTER);
        box.addView(minHint, new LinearLayout.LayoutParams(-1, -2));

        EditText code = new EditText(this);
        code.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        code.setHint("Kod odblokowania, min. 4 znaki");
        code.setGravity(Gravity.CENTER);
        code.setTextColor(ORANGE);
        code.setHintTextColor(MUTED);
        code.setTypeface(null, Typeface.BOLD);
        code.setTextSize(17);
        code.setBackground(roundStroke(BLACK, 14, ORANGE, 1));
        code.setPadding(dp(12), dp(10), dp(12), dp(10));
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
        cp.setMargins(0, dp(12), 0, 0);
        box.addView(code, cp);

        EditText consent = new EditText(this);
        consent.setInputType(InputType.TYPE_CLASS_TEXT);
        consent.setHint("Wpisz: BLOKUJĘ USTAWIENIA");
        consent.setGravity(Gravity.CENTER);
        consent.setTextColor(ORANGE);
        consent.setHintTextColor(MUTED);
        consent.setTypeface(null, Typeface.BOLD);
        consent.setTextSize(16);
        consent.setBackground(roundStroke(BLACK, 14, ORANGE, 1));
        consent.setPadding(dp(12), dp(10), dp(12), dp(10));
        LinearLayout.LayoutParams cp2 = new LinearLayout.LayoutParams(-1, -2);
        cp2.setMargins(0, dp(12), 0, 0);
        box.addView(consent, cp2);

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(-1, -2);
        ap.setMargins(0, dp(16), 0, 0);
        box.addView(actions, ap);

        Button cancel = pillButton("Anuluj", CARD_2, TEXT, false);
        actions.addView(cancel, new LinearLayout.LayoutParams(0, -2, 1));
        cancel.setOnClickListener(v -> dialog.dismiss());

        addHorizontalSpace(actions, dp(8));

        Button ok = pillButton("Aktywuj", ORANGE, BLACK, true);
        actions.addView(ok, new LinearLayout.LayoutParams(0, -2, 1));
        ok.setOnClickListener(v -> {
            int mins = parseMinutes(minutes);
            if (mins <= 0) return;
            String codeValue = code.getText().toString();
            if (codeValue.length() < 4) {
                Toast.makeText(this, "Kod musi mieć przynajmniej 4 znaki.", Toast.LENGTH_LONG).show();
                return;
            }
            String typed = consent.getText().toString().trim();
            if (!typed.equalsIgnoreCase("BLOKUJĘ USTAWIENIA") && !typed.equalsIgnoreCase("BLOKUJE USTAWIENIA")) {
                Toast.makeText(this, "Dla wyraźnej zgody wpisz: BLOKUJĘ USTAWIENIA", Toast.LENGTH_LONG).show();
                return;
            }
            Prefs.setSettingsLock(this, System.currentTimeMillis() + mins * 60_000L, codeValue);
            startMonitorService();
            refreshStatus();
            Toast.makeText(this, "Ustawienia zablokowane na " + mins + " min.", Toast.LENGTH_LONG).show();
            dialog.dismiss();
        });

        dialog.setContentView(box);
        dialog.setOnShowListener(d -> {
            Window w = dialog.getWindow();
            if (w != null) {
                w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                w.setLayout((int)(getResources().getDisplayMetrics().widthPixels * 0.92f), -2);
            }
        });
        dialog.show();
    }

    private void removeSettingsLock() {
        if (!Prefs.isSettingsLockActive(this)) {
            Toast.makeText(this, "Blokada ustawień nie jest aktywna.", Toast.LENGTH_LONG).show();
            return;
        }
        if (Prefs.isCuffsLocked(this)) {
            Toast.makeText(this, "Kajdanki nie pozwalają usuwać blokady ustawień. Pozostało: " + formatDuration(Prefs.getCuffsRemainingMillis(this)), Toast.LENGTH_LONG).show();
            return;
        }

        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(18), dp(18), dp(18), dp(18));
        box.setBackground(roundStroke(CARD, 24, ORANGE, 2));

        TextView title = sectionTitle("USUŃ BLOKADĘ USTAWIEŃ");
        title.setGravity(Gravity.CENTER);
        box.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView hint = new TextView(this);
        hint.setText("Wpisz kod ustawiony przy blokadzie ustawień. W trybie opaski zadziała też kod opaski.");
        hint.setTextColor(MUTED);
        hint.setTextSize(13);
        hint.setGravity(Gravity.CENTER);
        hint.setLineSpacing(0, 1.08f);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, -2);
        hp.setMargins(0, dp(10), 0, dp(10));
        box.addView(hint, hp);

        EditText code = new EditText(this);
        code.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        code.setHint("Kod");
        code.setGravity(Gravity.CENTER);
        code.setTextColor(ORANGE);
        code.setHintTextColor(MUTED);
        code.setTypeface(null, Typeface.BOLD);
        code.setTextSize(18);
        code.setBackground(roundStroke(BLACK, 14, ORANGE, 1));
        code.setPadding(dp(12), dp(10), dp(12), dp(10));
        box.addView(code, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(-1, -2);
        ap.setMargins(0, dp(16), 0, 0);
        box.addView(actions, ap);

        Button cancel = pillButton("Anuluj", CARD_2, TEXT, false);
        actions.addView(cancel, new LinearLayout.LayoutParams(0, -2, 1));
        cancel.setOnClickListener(v -> dialog.dismiss());

        addHorizontalSpace(actions, dp(8));

        Button ok = pillButton("Usuń", ORANGE, BLACK, true);
        actions.addView(ok, new LinearLayout.LayoutParams(0, -2, 1));
        ok.setOnClickListener(v -> {
            String value = code.getText().toString();
            boolean valid = Prefs.verifySettingsLockCode(this, value) || Prefs.verifyControlCode(this, value);
            if (!valid) {
                Toast.makeText(this, "Błędny kod.", Toast.LENGTH_LONG).show();
                return;
            }
            Prefs.clearSettingsLock(this);
            refreshStatus();
            Toast.makeText(this, "Blokada ustawień usunięta.", Toast.LENGTH_LONG).show();
            dialog.dismiss();
        });

        dialog.setContentView(box);
        dialog.setOnShowListener(d -> {
            Window w = dialog.getWindow();
            if (w != null) {
                w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                w.setLayout((int)(getResources().getDisplayMetrics().widthPixels * 0.92f), -2);
            }
        });
        dialog.show();
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_PICK_WALLPAPER) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                Uri uri = data.getData();
                try {
                    final int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                    getContentResolver().takePersistableUriPermission(uri, flags & Intent.FLAG_GRANT_READ_URI_PERMISSION);
                } catch (Exception ignored) { }
                Prefs.setWallpaperUri(this, uri.toString());
                Toast.makeText(this, "Wybrano tapetę. Teraz ustaw czas i kliknij Ustaw tapetę.", Toast.LENGTH_LONG).show();
                refreshStatus();
            }
            return;
        }

        if (requestCode == REQUEST_SCREEN_CAPTURE) {
            if (resultCode == RESULT_OK && data != null) {
                Intent service = new Intent(this, ScreenshotCaptureService.class);
                service.setAction(ScreenshotCaptureService.ACTION_START);
                service.putExtra(ScreenshotCaptureService.EXTRA_RESULT_CODE, resultCode);
                service.putExtra(ScreenshotCaptureService.EXTRA_RESULT_DATA, data);
                service.putExtra(ScreenshotCaptureService.EXTRA_INTERVAL_MIN, Prefs.getScreenshotIntervalMin(this));
                try {
                    if (Build.VERSION.SDK_INT >= 26) startForegroundService(service);
                    else startService(service);
                    Toast.makeText(this, "Monitor screenshotów uruchomiony. Zapis: Galeria/Pictures/monitor.", Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    Toast.makeText(this, "Nie udało się uruchomić monitora screenshotów: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            } else {
                Toast.makeText(this, "Zgoda na przechwytywanie ekranu została anulowana.", Toast.LENGTH_LONG).show();
            }
            refreshStatus();
        }
    }

    private void pickWallpaperImage() {
        requireProtectedChange("Zmiana auto-tapety", this::openWallpaperPicker);
    }

    private void openWallpaperPicker() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/*");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try {
            startActivityForResult(intent, REQUEST_PICK_WALLPAPER);
        } catch (Exception e) {
            Toast.makeText(this, "Nie udało się otworzyć galerii.", Toast.LENGTH_LONG).show();
        }
    }

    private void startWallpaperTimer() {
        requireProtectedChange("Zmiana auto-tapety", this::doStartWallpaperTimer);
    }

    private void doStartWallpaperTimer() {
        String uriString = Prefs.getWallpaperUri(this);
        if (uriString == null || uriString.length() == 0) {
            Toast.makeText(this, "Najpierw wybierz obraz z galerii.", Toast.LENGTH_LONG).show();
            openWallpaperPicker();
            return;
        }
        int minutes = parseMinutes(wallpaperMinutesInput);
        if (minutes <= 0) return;

        Uri uri = Uri.parse(uriString);
        if (!applyWallpaper(uri)) return;

        long end = System.currentTimeMillis() + minutes * 60_000L;
        Prefs.setWallpaperEndTime(this, end);
        startMonitorService();
        Toast.makeText(this, "Tapeta ustawiona na " + minutes + " min. AppBlocker będzie ją szybko przywracał, także po odblokowaniu/restarcie.", Toast.LENGTH_LONG).show();
        refreshStatus();
    }


    private void clearWallpaperLock() {
        requireProtectedChange("Usunięcie auto-tapety", () -> {
            Prefs.clearWallpaperTimer(this);
            Toast.makeText(this, "Timer auto-tapety usunięty. Obecna tapeta nie zostanie zmieniona.", Toast.LENGTH_LONG).show();
            refreshStatus();
        });
    }

    private boolean applyWallpaper(Uri uri) {
        InputStream in = null;
        try {
            in = getContentResolver().openInputStream(uri);
            if (in == null) throw new Exception("Brak dostępu do obrazu");
            WallpaperManager.getInstance(this).setStream(in);
            return true;
        } catch (Exception e) {
            Toast.makeText(this, "Nie udało się ustawić tapety: " + e.getMessage(), Toast.LENGTH_LONG).show();
            return false;
        } finally {
            if (in != null) {
                try { in.close(); } catch (Exception ignored) { }
            }
        }
    }

    private void requestScreenshotMonitor() {
        requireProtectedChange("Start monitora screenshotów", this::doRequestScreenshotMonitor);
    }

    private void doRequestScreenshotMonitor() {
        Prefs.setScreenshotIntervalMin(this, screenshotIntervalMin);
        try {
            MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
            if (mpm == null) throw new Exception("Brak MediaProjectionManager");
            startActivityForResult(mpm.createScreenCaptureIntent(), REQUEST_SCREEN_CAPTURE);
        } catch (Exception e) {
            Toast.makeText(this, "Nie udało się poprosić o zgodę na screenshoty: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void stopScreenshotMonitor() {
        requireProtectedChange("Stop monitora screenshotów", () -> {
            Intent service = new Intent(this, ScreenshotCaptureService.class);
            service.setAction(ScreenshotCaptureService.ACTION_STOP);
            try { startService(service); } catch (Exception ignored) { }
            Toast.makeText(this, "Wysłano polecenie zatrzymania monitora screenshotów.", Toast.LENGTH_LONG).show();
            refreshStatus();
        });
    }

    private void loadApps() {
        apps.clear();
        PackageManager pm = getPackageManager();
        Intent intent = new Intent(Intent.ACTION_MAIN, null);
        intent.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> infos = pm.queryIntentActivities(intent, 0);
        Set<String> seen = new HashSet<>();
        for (ResolveInfo info : infos) {
            if (info.activityInfo == null) continue;
            String pkg = info.activityInfo.packageName;
            if (pkg == null || seen.contains(pkg)) continue;
            if (pkg.equals(getPackageName()) || isSafetyPackage(pkg)) continue;
            seen.add(pkg);
            String label;
            Drawable icon = null;
            try {
                CharSequence cs = info.loadLabel(pm);
                label = cs == null ? pkg : cs.toString();
                icon = info.loadIcon(pm);
            } catch (Exception e) {
                label = pkg;
            }
            apps.add(new AppItem(label, pkg, icon));
        }
        Collections.sort(apps, new Comparator<AppItem>() {
            @Override public int compare(AppItem a, AppItem b) {
                return a.label.compareToIgnoreCase(b.label);
            }
        });
        renderAppList();
        refreshStatus();
    }

    private void renderAppList() {
        if (appContainer == null) return;
        appContainer.removeAllViews();

        if (apps.isEmpty()) {
            TextView empty = new TextView(this);
            empty.setText("Nie znaleziono aplikacji do wyświetlenia.");
            empty.setTextColor(MUTED);
            empty.setTextSize(14);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(dp(12), dp(18), dp(12), dp(18));
            empty.setBackground(roundStroke(CARD, 18, Color.rgb(35, 35, 35), 1));
            appContainer.addView(empty, new LinearLayout.LayoutParams(-1, -2));
            return;
        }

        for (AppItem app : apps) {
            View row = createAppRow(app);
            LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, -2);
            rp.setMargins(0, 0, 0, dp(8));
            appContainer.addView(row, rp);
        }
    }

    private View createAppRow(AppItem app) {
        boolean selected = selectedPackages.contains(app.packageName);
        boolean active = Prefs.isPackageActive(this, app.packageName);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(12), dp(10), dp(12), dp(10));
        row.setClickable(true);
        row.setBackground(active
                ? roundStroke(Color.rgb(30, 17, 0), 18, ORANGE, 2)
                : selected
                    ? roundStroke(Color.rgb(18, 10, 0), 18, ORANGE, 1)
                    : roundStroke(PANEL, 18, Color.rgb(28, 28, 28), 1));
        row.setOnClickListener(v -> {
            if (selectedPackages.contains(app.packageName)) selectedPackages.remove(app.packageName);
            else selectedPackages.add(app.packageName);
            renderAppList();
            refreshStatus();
        });

        ImageView icon = new ImageView(this);
        if (app.icon != null) icon.setImageDrawable(app.icon);
        icon.setPadding(dp(6), dp(6), dp(6), dp(6));
        icon.setBackground(roundStroke(BLACK, 14, active || selected ? ORANGE : Color.rgb(35, 35, 35), active || selected ? 2 : 1));
        row.addView(icon, new LinearLayout.LayoutParams(dp(50), dp(50)));

        LinearLayout middle = new LinearLayout(this);
        middle.setOrientation(LinearLayout.VERTICAL);
        middle.setPadding(dp(12), 0, dp(8), 0);
        row.addView(middle, new LinearLayout.LayoutParams(0, -2, 1));

        TextView name = new TextView(this);
        name.setText(app.label);
        name.setTextColor(TEXT);
        name.setTextSize(15);
        name.setTypeface(null, Typeface.BOLD);
        name.setSingleLine(true);
        middle.addView(name, new LinearLayout.LayoutParams(-1, -2));

        TextView pkg = new TextView(this);
        pkg.setText(app.packageName);
        pkg.setTextColor(MUTED);
        pkg.setTextSize(11);
        pkg.setSingleLine(true);
        middle.addView(pkg, new LinearLayout.LayoutParams(-1, -2));

        TextView appStatus = new TextView(this);
        int attempts = Prefs.getAttemptCount(this, app.packageName);
        long penalty = Prefs.getPenaltyMillis(this, app.packageName);
        String disciplineTail = attempts > 0 ? " · próby: " + attempts : "";
        if (penalty > 0) disciplineTail += " · kara +" + formatDuration(penalty);
        if (active) {
            appStatus.setText("AKTYWNA · " + formatDuration(Prefs.remainingMillis(this, app.packageName)) + disciplineTail);
            appStatus.setTextColor(ORANGE);
        } else if (selected) {
            appStatus.setText("Wybrana do grupowej blokady" + disciplineTail);
            appStatus.setTextColor(ORANGE);
        } else if (attempts > 0) {
            appStatus.setText("Dziennik: " + attempts + " prób ucieczki" + (penalty > 0 ? " · kara +" + formatDuration(penalty) : ""));
            appStatus.setTextColor(MUTED);
        } else {
            appStatus.setText("Dotknij, aby zaznaczyć");
            appStatus.setTextColor(MUTED);
        }
        appStatus.setTextSize(12);
        appStatus.setTypeface(null, active ? Typeface.BOLD : Typeface.NORMAL);
        middle.addView(appStatus, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout right = new LinearLayout(this);
        right.setOrientation(LinearLayout.VERTICAL);
        right.setGravity(Gravity.CENTER);
        row.addView(right, new LinearLayout.LayoutParams(-2, -2));

        TextView check = new TextView(this);
        check.setText(selected ? "✓" : "");
        check.setGravity(Gravity.CENTER);
        check.setTextSize(18);
        check.setTypeface(null, Typeface.BOLD);
        check.setTextColor(BLACK);
        check.setBackground(round(selected ? ORANGE : Color.rgb(30, 30, 30), 999));
        right.addView(check, new LinearLayout.LayoutParams(dp(34), dp(34)));

        Button set = pillButton(active ? "PRZEDŁUŻ" : "USTAW", active ? ORANGE : ORANGE_DARK, active ? BLACK : ORANGE, true);
        set.setTextSize(11);
        set.setPadding(dp(8), dp(6), dp(8), dp(6));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(dp(86), -2);
        bp.setMargins(0, dp(6), 0, 0);
        right.addView(set, bp);
        set.setOnClickListener(v -> showTimerDialog(app));

        if (active) {
            Button cancelBlock = pillButton("USUŃ", CARD_2, TEXT, false);
            cancelBlock.setTextSize(11);
            cancelBlock.setPadding(dp(8), dp(6), dp(8), dp(6));
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(dp(86), -2);
            cp.setMargins(0, dp(6), 0, 0);
            right.addView(cancelBlock, cp);
            cancelBlock.setOnClickListener(v -> cancelAppBlock(app));
        }

        return row;
    }


    private void cancelAppBlock(AppItem app) {
        if (Prefs.isCuffsLocked(this)) {
            Toast.makeText(this, "Kajdanki nie pozwalają usuwać blokad. Pozostało: " + formatDuration(Prefs.getCuffsRemainingMillis(this)), Toast.LENGTH_LONG).show();
            return;
        }
        if (Prefs.getControlMode(this) == Prefs.MODE_ANKLET) {
            Toast.makeText(this, "Różowa opaska nie pozwala usuwać aktywnych blokad aplikacji.", Toast.LENGTH_LONG).show();
            return;
        }
        Prefs.removeBlock(this, app.packageName);
        renderAppList();
        refreshStatus();
        Toast.makeText(this, "Usunięto blokadę: " + app.label, Toast.LENGTH_LONG).show();
    }

    private void showTimerDialog(AppItem app) {
        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(18), dp(18), dp(18), dp(18));
        box.setBackground(roundStroke(CARD, 24, ORANGE, 2));

        TextView title = sectionTitle("INDYWIDUALNA BLOKADA");
        title.setGravity(Gravity.CENTER);
        box.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView name = new TextView(this);
        name.setText(app.label);
        name.setTextColor(TEXT);
        name.setTextSize(18);
        name.setTypeface(null, Typeface.BOLD);
        name.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(-1, -2);
        np.setMargins(0, dp(10), 0, dp(4));
        box.addView(name, np);

        TextView hint = new TextView(this);
        long existing = Prefs.getEndTime(this, app.packageName);
        if (existing > System.currentTimeMillis()) {
            hint.setText("Aktualnie aktywna: " + formatDuration(existing - System.currentTimeMillis()) + ". Możesz tylko przedłużyć, nie skrócić.");
            hint.setTextColor(ORANGE);
        } else {
            hint.setText("Ustaw osobny timer tylko dla tej aplikacji.");
            hint.setTextColor(MUTED);
        }
        hint.setTextSize(13);
        hint.setGravity(Gravity.CENTER);
        hint.setLineSpacing(0, 1.08f);
        box.addView(hint, new LinearLayout.LayoutParams(-1, -2));

        EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_NUMBER);
        input.setText("30");
        input.setSelectAllOnFocus(true);
        input.setGravity(Gravity.CENTER);
        input.setTextColor(ORANGE);
        input.setTypeface(null, Typeface.BOLD);
        input.setTextSize(22);
        input.setPadding(dp(12), dp(10), dp(12), dp(10));
        input.setBackground(roundStroke(BLACK, 14, ORANGE, 1));
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(-1, -2);
        ip.setMargins(0, dp(14), 0, dp(12));
        box.addView(input, ip);

        LinearLayout quickRow = new LinearLayout(this);
        quickRow.setOrientation(LinearLayout.HORIZONTAL);
        box.addView(quickRow, new LinearLayout.LayoutParams(-1, -2));
        int[] quick = new int[]{15, 30, 60};
        for (int i = 0; i < quick.length; i++) {
            int m = quick[i];
            Button b = pillButton(m + " min", ORANGE_DARK, ORANGE, false);
            b.setOnClickListener(v -> input.setText(String.valueOf(m)));
            quickRow.addView(b, new LinearLayout.LayoutParams(0, -2, 1));
            if (i < quick.length - 1) addHorizontalSpace(quickRow, dp(8));
        }

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(-1, -2);
        ap.setMargins(0, dp(16), 0, 0);
        box.addView(actions, ap);

        Button cancel = pillButton("Anuluj", CARD_2, TEXT, false);
        actions.addView(cancel, new LinearLayout.LayoutParams(0, -2, 1));
        cancel.setOnClickListener(v -> dialog.dismiss());

        addHorizontalSpace(actions, dp(8));

        Button confirm = pillButton("Zablokuj", ORANGE, BLACK, true);
        actions.addView(confirm, new LinearLayout.LayoutParams(0, -2, 1));
        confirm.setOnClickListener(v -> {
            if (!ensurePermissionsOrOpenSettings()) return;
            int minutes = parseMinutes(input);
            if (minutes <= 0) return;
            long desiredEnd = System.currentTimeMillis() + minutes * 60_000L;
            long before = Prefs.getEndTime(this, app.packageName);
            Prefs.saveBlock(this, app.packageName, desiredEnd);
            startMonitorService();
            renderAppList();
            refreshStatus();
            if (before > desiredEnd) {
                Toast.makeText(this, "Nie skracam aktywnej blokady. Zostaje dłuższy czas.", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, "Zablokowano: " + app.label + " na " + minutes + " min.", Toast.LENGTH_LONG).show();
            }
            dialog.dismiss();
        });

        dialog.setContentView(box);
        dialog.setOnShowListener(d -> {
            Window w = dialog.getWindow();
            if (w != null) {
                w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                w.setLayout((int)(getResources().getDisplayMetrics().widthPixels * 0.92f), -2);
            }
        });
        dialog.show();
    }

    private void startGroupBlock() {
        if (!ensurePermissionsOrOpenSettings()) return;
        if (selectedPackages.isEmpty()) {
            Toast.makeText(this, "Wybierz przynajmniej jedną aplikację.", Toast.LENGTH_LONG).show();
            return;
        }
        int minutes = parseMinutes(minutesInput);
        if (minutes <= 0) return;

        long end = System.currentTimeMillis() + minutes * 60_000L;
        Prefs.saveBlocks(this, selectedPackages, end);
        startMonitorService();
        Toast.makeText(this, "Blokada uruchomiona dla " + selectedPackages.size() + " aplikacji na " + minutes + " min.", Toast.LENGTH_LONG).show();
        renderAppList();
        refreshStatus();
    }

    private int parseMinutes(EditText input) {
        int minutes;
        try {
            minutes = Integer.parseInt(input.getText().toString().trim());
        } catch (Exception e) {
            Toast.makeText(this, "Podaj liczbę minut.", Toast.LENGTH_LONG).show();
            return -1;
        }
        if (minutes <= 0) {
            Toast.makeText(this, "Timer musi być większy od zera.", Toast.LENGTH_LONG).show();
            return -1;
        }
        if (minutes > 1440) {
            Toast.makeText(this, "W wersji testowej limit to 1440 minut, czyli 24 godziny.", Toast.LENGTH_LONG).show();
            return -1;
        }
        return minutes;
    }

    private void refreshStatus() {
        boolean usage = hasUsageAccess();
        boolean overlay = canDrawOverlay();
        boolean accessibility = isAccessibilityEnabled();

        if (accessibility) {
            String extra = (usage && overlay) ? " + USAGE/NAKŁADKA" : "";
            permissionStatus.setText("✓ TRYB AWARYJNY DOSTĘPNOŚCI WŁĄCZONY" + extra);
            permissionStatus.setTextColor(OK);
            permissionStatus.setBackground(roundStroke(Color.rgb(5, 20, 8), 14, OK, 1));
        } else if (usage && overlay) {
            permissionStatus.setText("✓ DOSTĘP DO UŻYCIA + NAKŁADKA WŁĄCZONE");
            permissionStatus.setTextColor(OK);
            permissionStatus.setBackground(roundStroke(Color.rgb(5, 20, 8), 14, OK, 1));
        } else {
            String missing = "⚠ BRAKUJE: ";
            if (!accessibility) missing += "DOSTĘPNOŚĆ AWARYJNA ";
            if (!usage) missing += "DOSTĘP DO UŻYCIA ";
            if (!overlay) missing += "NAKŁADKA ";
            permissionStatus.setText(missing.trim());
            permissionStatus.setTextColor(DANGER);
            permissionStatus.setBackground(roundStroke(Color.rgb(22, 6, 6), 14, DANGER, 1));
        }

        int count = Prefs.activeCount(this);
        if (count > 0) {
            status.setText("LOCKDOWN AKTYWNY · " + count + " aplikacji · max " + formatDuration(Prefs.remainingMillis(this)));
            status.setTextColor(ORANGE);
            status.setBackground(roundStroke(Color.rgb(18, 10, 0), 14, ORANGE, 1));
        } else {
            status.setText("BRAK AKTYWNEJ BLOKADY");
            status.setTextColor(MUTED);
            status.setBackground(roundStroke(Color.rgb(18, 18, 18), 14, Color.rgb(45, 45, 45), 1));
        }
        if (controlModeStatus != null) {
            int mode = Prefs.getControlMode(this);
            if (mode == Prefs.MODE_CUFFS) {
                controlModeStatus.setText("TRYB: RÓŻOWE KAJDANKI · pozostało " + formatDuration(Prefs.getCuffsRemainingMillis(this)));
                controlModeStatus.setTextColor(ORANGE);
                controlModeStatus.setBackground(roundStroke(Color.rgb(18, 10, 0), 14, ORANGE, 1));
            } else if (mode == Prefs.MODE_ANKLET) {
                controlModeStatus.setText("TRYB: RÓŻOWA OPASKA · zmiany po kodzie · blokad aplikacji nie usuwasz");
                controlModeStatus.setTextColor(ORANGE);
                controlModeStatus.setBackground(roundStroke(Color.rgb(18, 10, 0), 14, ORANGE, 1));
            } else {
                controlModeStatus.setText("TRYB: WOLNY · możesz usuwać blokady i zmieniać moduły");
                controlModeStatus.setTextColor(MUTED);
                controlModeStatus.setBackground(roundStroke(Color.rgb(18, 18, 18), 14, Color.rgb(45, 45, 45), 1));
            }
        }

        if (adminStatus != null) {
            if (isDeviceAdminActive()) {
                adminStatus.setText("Administrator urządzenia: WŁĄCZONY · odinstalowanie wymaga cofnięcia administratora w ustawieniach");
                adminStatus.setTextColor(ORANGE);
            } else {
                adminStatus.setText("Administrator urządzenia: WYŁĄCZONY · kajdanki działają tylko w aplikacji");
                adminStatus.setTextColor(MUTED);
            }
        }

        if (policeStatus != null) {
            int open = Prefs.getPoliceOpenCount(this);
            int punished = Prefs.getPolicePunishedCount(this);
            if (open > 0) {
                policeStatus.setText("PANI POLICJANTKA: " + open + " zadań pod obserwacją · wykonane kary: " + punished);
                policeStatus.setTextColor(ORANGE);
                policeStatus.setBackground(roundStroke(Color.rgb(18, 10, 0), 14, ORANGE, 1));
            } else if (punished > 0) {
                policeStatus.setText("PANI POLICJANTKA: brak aktywnych zadań · wykonane kary: " + punished);
                policeStatus.setTextColor(MUTED);
                policeStatus.setBackground(roundStroke(Color.rgb(18, 18, 18), 14, Color.rgb(45, 45, 45), 1));
            } else {
                policeStatus.setText("PANI POLICJANTKA: brak aktywnych zadań");
                policeStatus.setTextColor(MUTED);
                policeStatus.setBackground(roundStroke(Color.rgb(18, 18, 18), 14, Color.rgb(45, 45, 45), 1));
            }
        }

        if (settingsLockStatus != null) {
            if (Prefs.isSettingsLockActive(this)) {
                settingsLockStatus.setText("USTAWIENIA LOCK: AKTYWNE · pozostało " + formatDuration(Prefs.getSettingsLockRemainingMillis(this)));
                settingsLockStatus.setTextColor(ORANGE);
                settingsLockStatus.setBackground(roundStroke(Color.rgb(18, 10, 0), 14, ORANGE, 1));
            } else {
                settingsLockStatus.setText("Brak aktywnej blokady ustawień");
                settingsLockStatus.setTextColor(MUTED);
                settingsLockStatus.setBackground(roundStroke(Color.rgb(18, 18, 18), 14, Color.rgb(45, 45, 45), 1));
            }
        }

        if (installLockStatus != null) {
            if (Prefs.isInstallLockActive(this)) {
                installLockStatus.setText("INSTALACJE LOCK: AKTYWNE · pozostało " + formatDuration(Prefs.getInstallLockRemainingMillis(this)));
                installLockStatus.setTextColor(ORANGE);
                installLockStatus.setBackground(roundStroke(Color.rgb(18, 10, 0), 14, ORANGE, 1));
            } else {
                installLockStatus.setText("Brak aktywnej blokady instalacji");
                installLockStatus.setTextColor(MUTED);
                installLockStatus.setBackground(roundStroke(Color.rgb(18, 18, 18), 14, Color.rgb(45, 45, 45), 1));
            }
        }

        if (browserLockStatus != null) {
            if (Prefs.isBrowserLockActive(this)) {
                browserLockStatus.setText("PRZEGLĄDARKI LOCK: AKTYWNE · pozostało " + formatDuration(Prefs.getBrowserLockRemainingMillis(this)));
                browserLockStatus.setTextColor(ORANGE);
                browserLockStatus.setBackground(roundStroke(Color.rgb(18, 10, 0), 14, ORANGE, 1));
            } else {
                browserLockStatus.setText("Brak aktywnej blokady przeglądarek");
                browserLockStatus.setTextColor(MUTED);
                browserLockStatus.setBackground(roundStroke(Color.rgb(18, 18, 18), 14, Color.rgb(45, 45, 45), 1));
            }
        }

        if (silenceLockStatus != null) {
            if (Prefs.isSilenceLockActive(this)) {
                silenceLockStatus.setText("TRYB CISZY: AKTYWNY · pozostało " + formatDuration(Prefs.getSilenceLockRemainingMillis(this)));
                silenceLockStatus.setTextColor(ORANGE);
                silenceLockStatus.setBackground(roundStroke(Color.rgb(18, 10, 0), 14, ORANGE, 1));
            } else if (!hasDndPolicyAccess()) {
                silenceLockStatus.setText("Brak uprawnienia DND · kliknij Uprawnienie DND");
                silenceLockStatus.setTextColor(DANGER);
                silenceLockStatus.setBackground(roundStroke(Color.rgb(22, 6, 6), 14, DANGER, 1));
            } else {
                silenceLockStatus.setText("Brak aktywnego trybu ciszy");
                silenceLockStatus.setTextColor(MUTED);
                silenceLockStatus.setBackground(roundStroke(Color.rgb(18, 18, 18), 14, Color.rgb(45, 45, 45), 1));
            }
        }

        if (wallpaperStatus != null) {
            String uri = Prefs.getWallpaperUri(this);
            if (Prefs.isWallpaperActive(this)) {
                wallpaperStatus.setText("TAPETA LOCK: AKTYWNA · pozostało " + formatDuration(Prefs.wallpaperRemainingMillis(this)));
                wallpaperStatus.setTextColor(ORANGE);
                wallpaperStatus.setBackground(roundStroke(Color.rgb(18, 10, 0), 14, ORANGE, 1));
            } else if (uri != null && uri.length() > 0) {
                wallpaperStatus.setText("Tapeta wybrana · ustaw czas i kliknij Ustaw tapetę");
                wallpaperStatus.setTextColor(MUTED);
                wallpaperStatus.setBackground(roundStroke(Color.rgb(18, 18, 18), 14, Color.rgb(45, 45, 45), 1));
            } else {
                wallpaperStatus.setText("Brak wybranej tapety");
                wallpaperStatus.setTextColor(MUTED);
                wallpaperStatus.setBackground(roundStroke(Color.rgb(18, 18, 18), 14, Color.rgb(45, 45, 45), 1));
            }
        }

        if (screenshotStatus != null) {
            screenshotStatus.setText("Interwał: " + Prefs.getScreenshotIntervalMin(this) + " min · folder: Pictures/monitor · tryb jawny");
            screenshotStatus.setTextColor(ORANGE);
            screenshotStatus.setBackground(roundStroke(Color.rgb(18, 10, 0), 14, ORANGE, 1));
        }

        selectedCount.setText(selectedPackages.size() + " WYBRANO");

        if (disciplineStatus != null) {
            boolean discipline = Prefs.isDisciplineEnabled(this);
            if (discipline) {
                disciplineStatus.setText("KARA ZA UCIECZKĘ: ON · każda realna próba może dodać +1 min, limit +10 min na aplikację");
                disciplineStatus.setTextColor(ORANGE);
                disciplineStatus.setBackground(roundStroke(Color.rgb(18, 10, 0), 14, ORANGE, 1));
                disciplineToggle.setText("Wyłącz karę za ucieczkę");
            } else {
                disciplineStatus.setText("KARA ZA UCIECZKĘ: OFF · próby będą tylko zapisywane w dzienniku");
                disciplineStatus.setTextColor(MUTED);
                disciplineStatus.setBackground(roundStroke(Color.rgb(18, 18, 18), 14, Color.rgb(45, 45, 45), 1));
                disciplineToggle.setText("Włącz karę za ucieczkę");
            }
        }
        if (journalStatus != null) {
            journalStatus.setText("DZIENNIK PRZEWINIEŃ: " + Prefs.getTotalAttemptCount(this) + " prób ucieczki zapisanych łącznie.");
        }
    }

    private boolean ensurePermissionsOrOpenSettings() {
        if (hasRequiredPermissions()) return true;

        if (!isAccessibilityEnabled()) {
            Toast.makeText(this, "Włącz Dostępność awaryjną: AppBlocker Monitor. To najważniejszy tryb dla Xiaomi.", Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            return false;
        }
        if (!hasUsageAccess()) {
            Toast.makeText(this, "Opcjonalnie włącz też Dostęp do użycia dla AppBlocker.", Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS));
            return false;
        }
        if (!canDrawOverlay()) {
            Toast.makeText(this, "Opcjonalnie zezwól też na wyświetlanie nakładki.", Toast.LENGTH_LONG).show();
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
            startActivity(intent);
            return false;
        }
        return false;
    }

    private boolean hasRequiredPermissions() {
        return isAccessibilityEnabled() || (hasUsageAccess() && canDrawOverlay());
    }

    private boolean hasUsageAccess() {
        try {
            AppOpsManager appOps = (AppOpsManager) getSystemService(Context.APP_OPS_SERVICE);
            if (appOps == null) return false;
            int mode;
            if (Build.VERSION.SDK_INT >= 29) {
                mode = appOps.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), getPackageName());
            } else {
                mode = appOps.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), getPackageName());
            }
            return mode == AppOpsManager.MODE_ALLOWED;
        } catch (Exception e) {
            return false;
        }
    }

    private boolean canDrawOverlay() {
        return Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this);
    }

    private void startMonitorService() {
        Intent i = new Intent(this, BlockMonitorService.class);
        try {
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i);
            else startService(i);
        } catch (Exception e) {
            try { startService(i); } catch (Exception ignored) { }
        }
    }

    private boolean isSafetyPackage(String pkg) {
        return pkg.equals("com.android.settings")
                || pkg.equals("com.google.android.settings")
                || pkg.equals("com.google.android.permissioncontroller")
                || pkg.equals("com.android.permissioncontroller")
                || pkg.equals("com.google.android.packageinstaller")
                || pkg.equals("com.android.packageinstaller");
    }

    private String formatDuration(long millis) {
        long seconds = Math.max(0, millis / 1000);
        long hours = seconds / 3600;
        long minutes = (seconds % 3600) / 60;
        long secs = seconds % 60;
        if (hours > 0) return String.format(Locale.getDefault(), "%02d:%02d:%02d", hours, minutes, secs);
        return String.format(Locale.getDefault(), "%02d:%02d", minutes, secs);
    }

    // Zostawione jako informacja pomocnicza dla osób, które ręcznie włączyły starą usługę Dostępności.
    private boolean isAccessibilityEnabled() {
        AccessibilityManager am = (AccessibilityManager) getSystemService(Context.ACCESSIBILITY_SERVICE);
        if (am == null) return false;
        List<AccessibilityServiceInfo> enabled = am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK);
        ComponentName expected = new ComponentName(this, AppBlockerAccessibilityService.class);
        for (AccessibilityServiceInfo info : enabled) {
            String id = info.getId();
            if (id == null) continue;
            ComponentName actual = ComponentName.unflattenFromString(id);
            if (expected.equals(actual)) return true;
            if (id.contains(getPackageName()) && id.contains("AppBlockerAccessibilityService")) return true;
        }
        return false;
    }

    private LinearLayout card() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(15), dp(16), dp(15));
        card.setBackground(roundStroke(CARD, 22, Color.rgb(35, 35, 35), 1));
        return card;
    }

    private TextView sectionTitle(String text) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(ORANGE);
        v.setTextSize(17);
        v.setTypeface(null, Typeface.BOLD);
        v.setLetterSpacing(0.09f);
        return v;
    }

    private Button pillButton(String text, int color, int textColor, boolean bold) {
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setText(text);
        b.setTextSize(14);
        b.setTextColor(textColor);
        b.setTypeface(null, bold ? Typeface.BOLD : Typeface.NORMAL);
        b.setPadding(dp(10), dp(10), dp(10), dp(10));
        if (color == ORANGE) b.setBackground(round(color, 14));
        else b.setBackground(roundStroke(color, 14, Color.rgb(50, 50, 50), 1));
        return b;
    }

    private LinearLayout.LayoutParams blockLp(int l, int t, int r, int b) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(dp(l), dp(t), dp(r), dp(b));
        return lp;
    }

    private void addHorizontalSpace(LinearLayout row, int width) {
        View s = new View(this);
        row.addView(s, new LinearLayout.LayoutParams(width, 1));
    }

    private GradientDrawable round(int color, int radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        return d;
    }

    private GradientDrawable roundStroke(int color, int radiusDp, int strokeColor, int strokeDp) {
        GradientDrawable d = round(color, radiusDp);
        d.setStroke(dp(strokeDp), strokeColor);
        return d;
    }

    private GradientDrawable gradient(int start, int end, GradientDrawable.Orientation orientation, int radiusDp, int strokeColor, int strokeDp) {
        GradientDrawable d = new GradientDrawable(orientation, new int[]{start, end});
        d.setCornerRadius(dp(radiusDp));
        d.setStroke(dp(strokeDp), strokeColor);
        return d;
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private static class AppItem {
        final String label;
        final String packageName;
        final Drawable icon;
        AppItem(String label, String packageName, Drawable icon) {
            this.label = label;
            this.packageName = packageName;
            this.icon = icon;
        }
    }
}
