package pl.arena.appblocker;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class BlockActivity extends Activity {
    public static final String EXTRA_BLOCKED_PACKAGE = "blocked_package";
    private static final int ORANGE = Color.rgb(255, 144, 0);
    private static final int BLACK = Color.rgb(0, 0, 0);
    private static final int TEXT = Color.rgb(245, 245, 245);
    private static final int MUTED = Color.rgb(175, 175, 175);

    private final Handler handler = new Handler(Looper.getMainLooper());
    private TextView title;
    private TextView subtitle;
    private TextView countdown;
    private String blockedPackage;

    private final Runnable ticker = new Runnable() {
        @Override public void run() {
            updateCountdown();
            handler.postDelayed(this, 1000);
        }
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        blockedPackage = getIntent().getStringExtra(EXTRA_BLOCKED_PACKAGE);
        buildUi();
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        blockedPackage = intent.getStringExtra(EXTRA_BLOCKED_PACKAGE);
        updateCountdown();
    }

    @Override protected void onResume() {
        super.onResume();
        handler.removeCallbacks(ticker);
        handler.post(ticker);
    }

    @Override protected void onPause() {
        super.onPause();
        handler.removeCallbacks(ticker);
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(dp(24), dp(24), dp(24), dp(24));
        root.setBackgroundColor(BLACK);

        title = new TextView(this);
        title.setTextColor(ORANGE);
        title.setTextSize(28);
        title.setGravity(Gravity.CENTER);
        title.setText("APLIKACJA ZABLOKOWANA");
        title.setTypeface(null, 1);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        subtitle = new TextView(this);
        subtitle.setTextColor(MUTED);
        subtitle.setTextSize(17);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setPadding(0, dp(16), 0, dp(8));
        root.addView(subtitle, new LinearLayout.LayoutParams(-1, -2));

        countdown = new TextView(this);
        countdown.setTextColor(ORANGE);
        countdown.setTextSize(32);
        countdown.setGravity(Gravity.CENTER);
        countdown.setTypeface(null, 1);
        countdown.setPadding(0, dp(8), 0, dp(24));
        root.addView(countdown, new LinearLayout.LayoutParams(-1, -2));

        TextView info = new TextView(this);
        info.setTextColor(MUTED);
        info.setTextSize(15);
        info.setGravity(Gravity.CENTER);
        info.setText("W tej wersji testowej nie ma przycisku odblokowania. Blokada kończy się automatycznie po upływie ustawionego czasu.");
        root.addView(info, new LinearLayout.LayoutParams(-1, -2));

        Button home = new Button(this);
        home.setText("Wróć na ekran główny");
        home.setTextColor(BLACK);
        home.setBackgroundColor(ORANGE);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, -2);
        bp.setMargins(0, dp(28), 0, 0);
        root.addView(home, bp);
        home.setOnClickListener(v -> {
            Intent startMain = new Intent(Intent.ACTION_MAIN);
            startMain.addCategory(Intent.CATEGORY_HOME);
            startMain.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(startMain);
        });

        setContentView(root);
        updateCountdown();
    }

    private void updateCountdown() {
        long end = Prefs.getEndTime(this, blockedPackage);
        long left = Math.max(0, end - System.currentTimeMillis());
        String appName = getAppName(blockedPackage);
        SimpleDateFormat fmt = new SimpleDateFormat("HH:mm:ss", Locale.getDefault());
        subtitle.setText(appName + " jest niedostępna do " + fmt.format(new Date(end)) + ".");

        if (left <= 0) {
            countdown.setText("00:00");
            title.setText("BLOKADA ZAKOŃCZONA");
            subtitle.setText("Możesz już wrócić do aplikacji.");
            handler.removeCallbacks(ticker);
            handler.postDelayed(this::finish, 1200);
            return;
        }

        long seconds = left / 1000;
        long hours = seconds / 3600;
        long minutes = (seconds % 3600) / 60;
        long secs = seconds % 60;
        if (hours > 0) {
            countdown.setText(String.format(Locale.getDefault(), "%02d:%02d:%02d", hours, minutes, secs));
        } else {
            countdown.setText(String.format(Locale.getDefault(), "%02d:%02d", minutes, secs));
        }
    }

    private String getAppName(String pkg) {
        if (pkg == null || pkg.trim().isEmpty()) return "Wybrana aplikacja";
        try {
            PackageManager pm = getPackageManager();
            ApplicationInfo ai = pm.getApplicationInfo(pkg, 0);
            CharSequence label = pm.getApplicationLabel(ai);
            return label == null ? pkg : label.toString();
        } catch (Exception e) {
            return pkg;
        }
    }

    @Override public void onBackPressed() {
        Intent startMain = new Intent(Intent.ACTION_MAIN);
        startMain.addCategory(Intent.CATEGORY_HOME);
        startMain.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(startMain);
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
