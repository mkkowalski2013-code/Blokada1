package pl.arena.appblocker;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.app.WallpaperManager;
import android.app.usage.UsageEvents;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class BlockMonitorService extends Service {
    private static final int NOTIFICATION_ID = 9001;
    private static final String CHANNEL_ID = "appblocker_monitor";

    private static final int ORANGE = Color.rgb(255, 144, 0); // #FF9000
    private static final int BLACK = Color.rgb(0, 0, 0);
    private static final int TEXT = Color.rgb(245, 245, 245);
    private static final int MUTED = Color.rgb(175, 175, 175);

    private final Handler handler = new Handler(Looper.getMainLooper());
    private WindowManager windowManager;
    private View overlayView;
    private TextView overlayAppName;
    private TextView overlayCommand;
    private TextView overlayCountdown;
    private TextView overlaySubtitle;
    private TextView overlayAttempts;
    private String overlayPackage = "";
    private long lastWallpaperApplyAt = 0L;
    private boolean dndApplied = false;

    private final Runnable monitorLoop = new Runnable() {
        @Override public void run() {
            tick();
            handler.postDelayed(this, 450);
        }
    };

    @Override public void onCreate() {
        super.onCreate();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        createNotificationChannel();
        startForeground(NOTIFICATION_ID, buildNotification());
        if (Prefs.isWallpaperActive(this)) applyWallpaperNow();
        handler.post(monitorLoop);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        startForeground(NOTIFICATION_ID, buildNotification());
        if (Prefs.isWallpaperActive(this)) applyWallpaperNow();
        handler.removeCallbacks(monitorLoop);
        handler.post(monitorLoop);
        return START_STICKY;
    }

    @Override public IBinder onBind(Intent intent) {
        return null;
    }

    private void tick() {
        boolean hasBlocks = Prefs.hasAnyActive(this);
        boolean wallpaperActive = Prefs.isWallpaperActive(this);
        boolean settingsActive = Prefs.isSettingsLockActive(this);
        boolean policePending = Prefs.hasPendingPoliceTasks(this);
        Prefs.checkPoliceTasksAndApply(this);
        boolean specialActive = Prefs.hasAnySpecialTimedLock(this);

        if (wallpaperActive) applyWallpaperIfDue();
        else Prefs.clearWallpaperTimer(this);
        applySilenceIfNeeded();

        if (!hasBlocks && !specialActive && !policePending) {
            hideOverlay();
            if (!wallpaperActive) stopSelf();
            return;
        }

        if (!canDrawOverlay()) {
            hideOverlay();
            return;
        }

        String top = getTopPackage();
        if (top == null || top.length() == 0) return;

        if (top.equals(getPackageName())) {
            // Jeśli nasza nakładka została zaliczona jako aktywne okno, nie zdejmuj jej.
            if (overlayView != null) return;
            hideOverlay();
            return;
        }

        if (isNoisePackage(top) && overlayView != null) return;

        if (Prefs.isSettingsLockActive(this) && isSettingsPackage(top)) {
            showOverlay(top);
            return;
        }

        if (Prefs.isInstallLockActive(this) && isInstallerPackage(top)) {
            showOverlay(top);
            return;
        }

        if (Prefs.isBrowserLockActive(this) && isBrowserPackage(top)) {
            showOverlay(top);
            return;
        }

        if (isSafetyPackage(top)) {
            hideOverlay();
            return;
        }

        if (Prefs.isPackageActive(this, top)) {
            Prefs.recordDisciplineHit(this, top);
            showOverlay(top);
        } else {
            hideOverlay();
        }
    }


    private void applyWallpaperIfDue() {
        long now = System.currentTimeMillis();
        if (now - lastWallpaperApplyAt < 8_000L) return;
        lastWallpaperApplyAt = now;
        applyWallpaperNow();
    }

    private void applyWallpaperNow() {
        String uriString = Prefs.getWallpaperUri(this);
        if (uriString == null || uriString.length() == 0) return;
        InputStream in = null;
        try {
            in = getContentResolver().openInputStream(Uri.parse(uriString));
            if (in != null) WallpaperManager.getInstance(this).setStream(in);
        } catch (Exception ignored) {
        } finally {
            if (in != null) {
                try { in.close(); } catch (Exception ignored) { }
            }
        }
    }


    private void applySilenceIfNeeded() {
        try {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm == null) return;
            if (Build.VERSION.SDK_INT >= 23 && !nm.isNotificationPolicyAccessGranted()) return;
            if (Prefs.isSilenceLockActive(this)) {
                nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_NONE);
                dndApplied = true;
            } else if (dndApplied) {
                nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_ALL);
                dndApplied = false;
            }
        } catch (Exception ignored) {
        }
    }

    private String getTopPackage() {
        try {
            UsageStatsManager usm = (UsageStatsManager) getSystemService(Context.USAGE_STATS_SERVICE);
            if (usm == null) return null;
            long now = System.currentTimeMillis();
            UsageEvents events = usm.queryEvents(now - 12_000L, now);
            UsageEvents.Event event = new UsageEvents.Event();
            String latestPkg = null;
            long latestTime = 0L;

            while (events.hasNextEvent()) {
                events.getNextEvent(event);
                int type = event.getEventType();
                boolean foreground = type == UsageEvents.Event.MOVE_TO_FOREGROUND;
                if (Build.VERSION.SDK_INT >= 29) {
                    foreground = foreground || type == UsageEvents.Event.ACTIVITY_RESUMED;
                }
                if (foreground && event.getPackageName() != null && event.getTimeStamp() >= latestTime) {
                    latestTime = event.getTimeStamp();
                    latestPkg = event.getPackageName();
                }
            }
            return latestPkg;
        } catch (Exception e) {
            return null;
        }
    }

    private void showOverlay(String packageName) {
        boolean specialTarget = isSpecialLockTarget(packageName);
        if (!specialTarget && !Prefs.isPackageActive(this, packageName)) {
            hideOverlay();
            return;
        }

        if (overlayView != null && packageName.equals(overlayPackage)) {
            updateOverlayCountdown();
            return;
        }

        hideOverlay();
        overlayPackage = packageName;
        overlayView = buildOverlay(packageName);

        int type;
        if (Build.VERSION.SDK_INT >= 26) type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        else type = WindowManager.LayoutParams.TYPE_PHONE;

        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                type,
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                        | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
                PixelFormat.TRANSLUCENT
        );
        params.gravity = Gravity.TOP | Gravity.START;
        params.setTitle("AppBlocker lockdown overlay");

        try {
            windowManager.addView(overlayView, params);
            overlayView.setFocusableInTouchMode(true);
            overlayView.requestFocus();
        } catch (Exception e) {
            overlayView = null;
        }
    }

    private View buildOverlay(String packageName) {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(dp(22), dp(22), dp(22), dp(22));
        root.setClickable(true);
        root.setFocusable(true);
        root.setFocusableInTouchMode(true);
        root.setBackground(gradient(BLACK, Color.rgb(35, 20, 0), GradientDrawable.Orientation.TL_BR));
        root.setOnKeyListener((v, keyCode, event) -> {
            if (keyCode == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_UP) {
                goHome();
                hideOverlay();
                return true;
            }
            return true;
        });

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER_HORIZONTAL);
        card.setPadding(dp(24), dp(26), dp(24), dp(24));
        card.setBackground(roundStroke(Color.rgb(7, 7, 7), 30, ORANGE, 2));
        root.addView(card, new LinearLayout.LayoutParams(-1, -2));

        TextView mark = new TextView(this);
        mark.setText("LOCK");
        mark.setTextSize(22);
        mark.setTypeface(null, Typeface.BOLD);
        mark.setLetterSpacing(0.08f);
        mark.setTextColor(ORANGE);
        mark.setGravity(Gravity.CENTER);
        mark.setBackground(roundStroke(BLACK, 999, ORANGE, 2));
        card.addView(mark, new LinearLayout.LayoutParams(dp(98), dp(72)));

        TextView title = new TextView(this);
        title.setText(titleForPackage(packageName));
        title.setTextSize(25);
        title.setTypeface(null, Typeface.BOLD);
        title.setLetterSpacing(0.04f);
        title.setTextColor(TEXT);
        title.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-1, -2);
        tp.setMargins(0, dp(18), 0, 0);
        card.addView(title, tp);

        overlayAppName = new TextView(this);
        overlayAppName.setText(labelForPackage(packageName));
        overlayAppName.setTextSize(18);
        overlayAppName.setTypeface(null, Typeface.BOLD);
        overlayAppName.setTextColor(ORANGE);
        overlayAppName.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(-1, -2);
        ap.setMargins(0, dp(10), 0, 0);
        card.addView(overlayAppName, ap);

        overlayCommand = new TextView(this);
        overlayCommand.setText(commandFor(packageName));
        overlayCommand.setTextSize(15);
        overlayCommand.setTypeface(null, Typeface.BOLD);
        overlayCommand.setTextColor(TEXT);
        overlayCommand.setGravity(Gravity.CENTER);
        overlayCommand.setLineSpacing(0, 1.08f);
        overlayCommand.setPadding(dp(10), dp(10), dp(10), dp(10));
        overlayCommand.setBackground(roundStroke(Color.rgb(18, 10, 0), 18, Color.rgb(70, 40, 0), 1));
        LinearLayout.LayoutParams cmdp = new LinearLayout.LayoutParams(-1, -2);
        cmdp.setMargins(0, dp(14), 0, 0);
        card.addView(overlayCommand, cmdp);

        overlayCountdown = new TextView(this);
        overlayCountdown.setTextSize(43);
        overlayCountdown.setTypeface(null, Typeface.BOLD);
        overlayCountdown.setTextColor(ORANGE);
        overlayCountdown.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
        cp.setMargins(0, dp(12), 0, 0);
        card.addView(overlayCountdown, cp);

        overlaySubtitle = new TextView(this);
        overlaySubtitle.setTextSize(15);
        overlaySubtitle.setTextColor(MUTED);
        overlaySubtitle.setGravity(Gravity.CENTER);
        overlaySubtitle.setLineSpacing(0, 1.08f);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2);
        sp.setMargins(0, dp(6), 0, dp(18));
        card.addView(overlaySubtitle, sp);

        overlayAttempts = new TextView(this);
        overlayAttempts.setTextSize(13);
        overlayAttempts.setTextColor(ORANGE);
        overlayAttempts.setGravity(Gravity.CENTER);
        overlayAttempts.setTypeface(null, Typeface.BOLD);
        LinearLayout.LayoutParams atp = new LinearLayout.LayoutParams(-1, -2);
        atp.setMargins(0, 0, 0, dp(12));
        card.addView(overlayAttempts, atp);

        TextView info = new TextView(this);
        info.setText("LOCKDOWN aktywny. Nie ma przycisku odblokowania do końca timera.");
        info.setTextSize(14);
        info.setTextColor(MUTED);
        info.setGravity(Gravity.CENTER);
        info.setPadding(dp(10), dp(12), dp(10), dp(12));
        info.setBackground(roundStroke(Color.rgb(18, 10, 0), 18, Color.rgb(70, 40, 0), 1));
        card.addView(info, new LinearLayout.LayoutParams(-1, -2));

        Button home = new Button(this);
        home.setAllCaps(false);
        home.setText("Wróć na ekran główny");
        home.setTextSize(16);
        home.setTextColor(BLACK);
        home.setTypeface(null, Typeface.BOLD);
        home.setPadding(dp(14), dp(12), dp(14), dp(12));
        home.setBackground(round(ORANGE, 16));
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, -2);
        hp.setMargins(0, dp(22), 0, 0);
        card.addView(home, hp);
        home.setOnClickListener(v -> {
            goHome();
            hideOverlay();
        });

        updateOverlayCountdown();
        return root;
    }

    private void updateOverlayCountdown() {
        if (overlayView == null || overlayCountdown == null || overlayPackage == null) return;
        long end = endTimeForPackage(overlayPackage);
        long left = Math.max(0, end - System.currentTimeMillis());
        if (left <= 0) {
            hideOverlay();
            return;
        }

        long seconds = left / 1000;
        long hours = seconds / 3600;
        long minutes = (seconds % 3600) / 60;
        long secs = seconds % 60;
        String leftText = hours > 0
                ? String.format(Locale.getDefault(), "%02d:%02d:%02d", hours, minutes, secs)
                : String.format(Locale.getDefault(), "%02d:%02d", minutes, secs);
        overlayCountdown.setText(leftText);

        SimpleDateFormat fmt = new SimpleDateFormat("HH:mm:ss", Locale.getDefault());
        overlaySubtitle.setText("Dostęp wróci automatycznie o " + fmt.format(new Date(end)) + ".");
        if (overlayCommand != null) overlayCommand.setText(commandFor(overlayPackage));
        if (overlayAttempts != null) {
            if (isSpecialLockTarget(overlayPackage)) {
                overlayAttempts.setText(specialStatusForPackage(overlayPackage));
            } else {
                int attempts = Prefs.getAttemptCount(this, overlayPackage);
                long penalty = Prefs.getPenaltyMillis(this, overlayPackage);
                String text = "PRÓBY UCIECZKI: " + attempts;
                if (penalty > 0) text += " · KARA: +" + formatDuration(penalty);
                overlayAttempts.setText(text);
            }
        }
    }

    private String commandFor(String packageName) {
        if (isSettingsPackage(packageName)) return "ROZKAZ: ustawienia są zamknięte do końca wybranego czasu.";
        if (isInstallerPackage(packageName)) return "ROZKAZ: instalowanie nowych aplikacji jest zablokowane.";
        if (isBrowserPackage(packageName)) return "ROZKAZ: przeglądarka zostaje zamknięta. Wracasz do celu.";
        int n = Prefs.getAttemptCount(this, packageName);
        String[] commands = new String[]{
                "ROZKAZ: odkładasz to teraz. Timer nie negocjuje.",
                "Nie ma targowania. Wracasz do celu.",
                "Próba ucieczki zapisana. Dyscyplina zostaje.",
                "Zablokowane znaczy zablokowane. Posłusznie wróć na Home.",
                "Komendant mówi: koniec rozpraszania."
        };
        return commands[Math.abs(n) % commands.length];
    }

    private String formatDuration(long millis) {
        long seconds = Math.max(0, millis / 1000);
        long minutes = seconds / 60;
        long secs = seconds % 60;
        if (minutes >= 60) {
            long hours = minutes / 60;
            long rem = minutes % 60;
            return String.format(Locale.getDefault(), "%02d:%02d:%02d", hours, rem, secs);
        }
        return String.format(Locale.getDefault(), "%02d:%02d", minutes, secs);
    }

    private void hideOverlay() {
        if (overlayView != null && windowManager != null) {
            try { windowManager.removeView(overlayView); } catch (Exception ignored) { }
        }
        overlayView = null;
        overlayPackage = "";
    }

    private void goHome() {
        Intent startMain = new Intent(Intent.ACTION_MAIN);
        startMain.addCategory(Intent.CATEGORY_HOME);
        startMain.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try { startActivity(startMain); } catch (Exception ignored) { }
    }

    private boolean canDrawOverlay() {
        return Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this);
    }

    private String getAppName(String pkg) {
        if (pkg == null || pkg.trim().isEmpty()) return "Wybrana aplikacja";
        try {
            PackageManager pm = getPackageManager();
            ApplicationInfo ai = pm.getApplicationInfo(pkg, 0);
            CharSequence label = pm.getApplicationLabel(ai);
            return label == null ? pkg : label.toString();
        } catch (Exception e) {
            return pkg;
        }
    }

    private boolean isNoisePackage(String pkg) {
        return pkg.equals("android")
                || pkg.equals("com.android.systemui")
                || pkg.equals("com.google.android.apps.nexuslauncher")
                || pkg.equals("com.sec.android.app.launcher")
                || pkg.equals("com.miui.home")
                || pkg.equals("com.huawei.android.launcher")
                || pkg.equals("com.oppo.launcher")
                || pkg.equals("com.vivo.launcher");
    }

    private boolean isSpecialLockTarget(String pkg) {
        return (Prefs.isSettingsLockActive(this) && isSettingsPackage(pkg))
                || (Prefs.isInstallLockActive(this) && isInstallerPackage(pkg))
                || (Prefs.isBrowserLockActive(this) && isBrowserPackage(pkg));
    }

    private long endTimeForPackage(String pkg) {
        if (isSettingsPackage(pkg) && Prefs.isSettingsLockActive(this)) return Prefs.getSettingsLockEndTime(this);
        if (isInstallerPackage(pkg) && Prefs.isInstallLockActive(this)) return Prefs.getInstallLockEndTime(this);
        if (isBrowserPackage(pkg) && Prefs.isBrowserLockActive(this)) return Prefs.getBrowserLockEndTime(this);
        return Prefs.getEndTime(this, pkg);
    }

    private String titleForPackage(String pkg) {
        if (isSettingsPackage(pkg)) return "USTAWIENIA ZABLOKOWANE";
        if (isInstallerPackage(pkg)) return "INSTALACJE ZABLOKOWANE";
        if (isBrowserPackage(pkg)) return "PRZEGLĄDARKA ZABLOKOWANA";
        return "APLIKACJA ZABLOKOWANA";
    }

    private String labelForPackage(String pkg) {
        if (isSettingsPackage(pkg)) return "Panel ustawień";
        if (isInstallerPackage(pkg)) return "Sklep / instalator APK";
        if (isBrowserPackage(pkg)) return "Przeglądarka internetowa";
        return getAppName(pkg);
    }

    private String specialStatusForPackage(String pkg) {
        if (isSettingsPackage(pkg)) return "BLOKADA USTAWIEŃ · wygaśnie automatycznie";
        if (isInstallerPackage(pkg)) return "BLOKADA INSTALACJI · wygaśnie automatycznie";
        if (isBrowserPackage(pkg)) return "BLOKADA PRZEGLĄDAREK · wygaśnie automatycznie";
        return "BLOKADA SPECJALNA";
    }

    private boolean isSettingsPackage(String pkg) {
        return pkg != null && (
                pkg.equals("com.android.settings")
                || pkg.equals("com.google.android.settings")
                || pkg.equals("com.miui.securitycenter")
                || pkg.equals("com.miui.permcenter")
                || pkg.equals("com.miui.powerkeeper")
                || pkg.equals("com.lbe.security.miui")
                || pkg.equals("com.miui.securityadd")
        );
    }

    private boolean isInstallerPackage(String pkg) {
        return pkg != null && (
                pkg.equals("com.android.vending")
                || pkg.equals("com.xiaomi.mipicks")
                || pkg.equals("com.mi.global.shop")
                || pkg.equals("com.google.android.packageinstaller")
                || pkg.equals("com.android.packageinstaller")
                || pkg.equals("com.miui.packageinstaller")
                || pkg.equals("com.google.android.permissioncontroller")
                || pkg.equals("com.android.permissioncontroller")
        );
    }

    private boolean isBrowserPackage(String pkg) {
        return pkg != null && (
                pkg.equals("com.android.chrome")
                || pkg.equals("com.chrome.beta")
                || pkg.equals("com.chrome.dev")
                || pkg.equals("org.mozilla.firefox")
                || pkg.equals("org.mozilla.firefox_beta")
                || pkg.equals("com.brave.browser")
                || pkg.equals("com.microsoft.emmx")
                || pkg.equals("com.opera.browser")
                || pkg.equals("com.opera.mini.native")
                || pkg.equals("com.duckduckgo.mobile.android")
                || pkg.equals("com.UCMobile.intl")
                || pkg.equals("com.sec.android.app.sbrowser")
                || pkg.equals("com.mi.globalbrowser")
                || pkg.equals("com.miui.browser")
        );
    }

    private boolean isSafetyPackage(String pkg) {
        return pkg.equals("com.android.settings")
                || pkg.equals("com.google.android.settings")
                || pkg.equals("com.google.android.permissioncontroller")
                || pkg.equals("com.android.permissioncontroller")
                || pkg.equals("com.google.android.packageinstaller")
                || pkg.equals("com.android.packageinstaller");
    }

    private Notification buildNotification() {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(
                this,
                0,
                open,
                Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0
        );

        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);

        int count = Prefs.activeCount(this);
        String text = count == 1 ? "Monitoruje 1 aktywną blokadę" : "Monitoruje " + count + " aktywnych blokad";
        if (Prefs.isWallpaperActive(this)) text += " · tapeta lock";
        if (Prefs.isSettingsLockActive(this)) text += " · ustawienia lock";
        if (Prefs.isInstallLockActive(this)) text += " · instalacje lock";
        if (Prefs.isBrowserLockActive(this)) text += " · browser lock";
        if (Prefs.isSilenceLockActive(this)) text += " · cisza";
        if (Prefs.getPoliceOpenCount(this) > 0) text += " · policjantka: " + Prefs.getPoliceOpenCount(this);
        return builder
                .setSmallIcon(android.R.drawable.ic_lock_lock)
                .setContentTitle("AppBlocker działa")
                .setContentText(text)
                .setContentIntent(pi)
                .setOngoing(true)
                .build();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationChannel ch = new NotificationChannel(
                CHANNEL_ID,
                "AppBlocker monitor",
                NotificationManager.IMPORTANCE_LOW
        );
        ch.setDescription("Stały monitor aktywnych blokad aplikacji");
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm != null) nm.createNotificationChannel(ch);
    }

    private GradientDrawable round(int color, int radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        return d;
    }

    private GradientDrawable roundStroke(int color, int radiusDp, int strokeColor, int strokeDp) {
        GradientDrawable d = round(color, radiusDp);
        d.setStroke(dp(strokeDp), strokeColor);
        return d;
    }

    private GradientDrawable gradient(int start, int end, GradientDrawable.Orientation orientation) {
        GradientDrawable d = new GradientDrawable(orientation, new int[]{start, end});
        d.setCornerRadius(0);
        return d;
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override public void onDestroy() {
        handler.removeCallbacks(monitorLoop);
        hideOverlay();
        super.onDestroy();
    }
}
