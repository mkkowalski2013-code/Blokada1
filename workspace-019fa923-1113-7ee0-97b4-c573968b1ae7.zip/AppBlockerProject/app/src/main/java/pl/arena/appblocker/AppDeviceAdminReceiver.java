package pl.arena.appblocker;

import android.app.admin.DeviceAdminReceiver;

public class AppDeviceAdminReceiver extends DeviceAdminReceiver {
}
