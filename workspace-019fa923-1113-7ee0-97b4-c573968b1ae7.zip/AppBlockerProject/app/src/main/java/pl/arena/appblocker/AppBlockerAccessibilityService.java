package pl.arena.appblocker;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class AppBlockerAccessibilityService extends AccessibilityService {
    private static final int ORANGE = Color.rgb(255, 144, 0); // #FF9000
    private static final int BLACK = Color.rgb(0, 0, 0);
    private static final int TEXT = Color.rgb(245, 245, 245);
    private static final int MUTED = Color.rgb(175, 175, 175);

    private final Handler handler = new Handler(Looper.getMainLooper());
    private WindowManager windowManager;
    private View overlayView;
    private TextView overlayAppName;
    private TextView overlayCommand;
    private TextView overlayCountdown;
    private TextView overlaySubtitle;
    private TextView overlayAttempts;
    private String overlayPackage = "";
    private long lastHomeAt = 0L;
    private long lastHandleAt = 0L;
    private String lastHandledPackage = "";

    private final Runnable poller = new Runnable() {
        @Override public void run() {
            pollActiveWindow();
            handler.postDelayed(this, 300);
        }
    };

    private final Runnable overlayTicker = new Runnable() {
        @Override public void run() {
            updateOverlayCountdown();
            if (overlayView != null) handler.postDelayed(this, 1000);
        }
    };

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);

        AccessibilityServiceInfo info = new AccessibilityServiceInfo();
        info.eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
                | AccessibilityEvent.TYPE_WINDOWS_CHANGED
                | AccessibilityEvent.TYPE_VIEW_FOCUSED
                | AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED;
        info.feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC;
        info.flags = AccessibilityServiceInfo.FLAG_INCLUDE_NOT_IMPORTANT_VIEWS
                | AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS
                | AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS;
        info.notificationTimeout = 30;
        setServiceInfo(info);

        handler.removeCallbacks(poller);
        handler.post(poller);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || event.getPackageName() == null) return;
        int type = event.getEventType();
        boolean interesting = type == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
                || type == AccessibilityEvent.TYPE_WINDOWS_CHANGED
                || type == AccessibilityEvent.TYPE_VIEW_FOCUSED
                || type == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED;
        if (!interesting) return;
        handlePackage(event.getPackageName().toString());
    }

    private void pollActiveWindow() {
        if (!Prefs.hasAnyActive(this) && !Prefs.hasAnySpecialTimedLock(this)) {
            hideOverlay();
            return;
        }

        String pkg = getPackageFromActiveRoot();
        if (pkg == null || pkg.length() == 0) pkg = getPackageFromWindows();
        if (pkg != null && pkg.length() > 0) handlePackage(pkg);
    }

    private String getPackageFromActiveRoot() {
        AccessibilityNodeInfo root = null;
        try {
            root = getRootInActiveWindow();
            if (root != null && root.getPackageName() != null) {
                return root.getPackageName().toString();
            }
        } catch (Exception ignored) {
        } finally {
            if (root != null) {
                try { root.recycle(); } catch (Exception ignored) { }
            }
        }
        return null;
    }

    private String getPackageFromWindows() {
        try {
            List<AccessibilityWindowInfo> windows = getWindows();
            if (windows == null) return null;

            String fallback = null;
            for (AccessibilityWindowInfo w : windows) {
                if (w == null) continue;
                AccessibilityNodeInfo root = null;
                try {
                    root = w.getRoot();
                    if (root == null || root.getPackageName() == null) continue;
                    String pkg = root.getPackageName().toString();
                    if (fallback == null) fallback = pkg;
                    if (w.isActive() || w.isFocused()) return pkg;
                } catch (Exception ignored) {
                } finally {
                    if (root != null) {
                        try { root.recycle(); } catch (Exception ignored) { }
                    }
                }
            }
            return fallback;
        } catch (Exception e) {
            return null;
        }
    }

    private void handlePackage(String packageName) {
        if (packageName == null || packageName.length() == 0) return;

        if (!Prefs.hasAnyActive(this) && !Prefs.hasAnySpecialTimedLock(this)) {
            hideOverlay();
            return;
        }

        if (packageName.equals(getPackageName())) {
            // Jeśli aktywna jest nasza własna nakładka, nie zdejmuj jej.
            if (overlayView != null) return;
            return;
        }

        if (isNoisePackage(packageName) && overlayView != null) return;

        if (Prefs.isSettingsLockActive(this) && isSettingsPackage(packageName)) {
            long now = System.currentTimeMillis();
            if (packageName.equals(lastHandledPackage) && now - lastHandleAt < 250) return;
            lastHandledPackage = packageName;
            lastHandleAt = now;
            forceBlock(packageName);
            return;
        }

        if (Prefs.isInstallLockActive(this) && isInstallerPackage(packageName)) {
            long now = System.currentTimeMillis();
            if (packageName.equals(lastHandledPackage) && now - lastHandleAt < 250) return;
            lastHandledPackage = packageName;
            lastHandleAt = now;
            forceBlock(packageName);
            return;
        }

        if (Prefs.isBrowserLockActive(this) && isBrowserPackage(packageName)) {
            long now = System.currentTimeMillis();
            if (packageName.equals(lastHandledPackage) && now - lastHandleAt < 250) return;
            lastHandledPackage = packageName;
            lastHandleAt = now;
            forceBlock(packageName);
            return;
        }

        if (isSafetyPackage(packageName)) {
            hideOverlay();
            return;
        }

        if (Prefs.isPackageActive(this, packageName)) {
            long now = System.currentTimeMillis();
            if (packageName.equals(lastHandledPackage) && now - lastHandleAt < 250) return;
            lastHandledPackage = packageName;
            lastHandleAt = now;
            forceBlock(packageName);
        } else if (overlayView != null && !isNoisePackage(packageName)) {
            hideOverlay();
        }
    }

    private void forceBlock(String packageName) {
        Prefs.recordDisciplineHit(this, packageName);
        long now = System.currentTimeMillis();
        // Najważniejsze: od razu wyrzuć użytkownika z zablokowanej aplikacji.
        // To działa nawet wtedy, gdy Xiaomi opóźnia/ukrywa nakładki.
        if (now - lastHomeAt > 700) {
            performGlobalAction(GLOBAL_ACTION_HOME);
            lastHomeAt = now;
        }
        showOverlay(packageName);
    }

    private void showOverlay(String packageName) {
        boolean specialTarget = isSpecialLockTarget(packageName);
        if (!specialTarget && !Prefs.isPackageActive(this, packageName)) {
            hideOverlay();
            return;
        }

        if (overlayView != null && packageName.equals(overlayPackage)) {
            updateOverlayCountdown();
            return;
        }

        hideOverlay();
        overlayPackage = packageName;
        overlayView = buildOverlay(packageName);

        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                        | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
                PixelFormat.TRANSLUCENT
        );
        params.gravity = Gravity.TOP | Gravity.START;
        params.setTitle("AppBlocker accessibility lockdown");

        try {
            windowManager.addView(overlayView, params);
            overlayView.setFocusableInTouchMode(true);
            overlayView.requestFocus();
            handler.removeCallbacks(overlayTicker);
            handler.post(overlayTicker);
        } catch (Exception e) {
            overlayView = null;
            // Fallback awaryjny — jeśli nakładka nie przejdzie, zostaje samo wyrzucanie na Home.
        }
    }

    private View buildOverlay(String packageName) {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(dp(22), dp(22), dp(22), dp(22));
        root.setClickable(true);
        root.setFocusable(true);
        root.setFocusableInTouchMode(true);
        root.setBackground(gradient(BLACK, Color.rgb(35, 20, 0), GradientDrawable.Orientation.TL_BR));
        root.setOnKeyListener((v, keyCode, event) -> {
            if (keyCode == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_UP) {
                performGlobalAction(GLOBAL_ACTION_HOME);
                hideOverlay();
                return true;
            }
            return true;
        });

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER_HORIZONTAL);
        card.setPadding(dp(24), dp(26), dp(24), dp(24));
        card.setBackground(roundStroke(Color.rgb(7, 7, 7), 30, ORANGE, 2));
        root.addView(card, new LinearLayout.LayoutParams(-1, -2));

        TextView mark = new TextView(this);
        mark.setText("LOCK");
        mark.setTextSize(22);
        mark.setTypeface(null, Typeface.BOLD);
        mark.setLetterSpacing(0.08f);
        mark.setTextColor(ORANGE);
        mark.setGravity(Gravity.CENTER);
        mark.setBackground(roundStroke(BLACK, 999, ORANGE, 2));
        card.addView(mark, new LinearLayout.LayoutParams(dp(98), dp(72)));

        TextView title = new TextView(this);
        title.setText(titleForPackage(packageName));
        title.setTextSize(25);
        title.setTypeface(null, Typeface.BOLD);
        title.setLetterSpacing(0.04f);
        title.setTextColor(TEXT);
        title.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-1, -2);
        tp.setMargins(0, dp(18), 0, 0);
        card.addView(title, tp);

        overlayAppName = new TextView(this);
        overlayAppName.setText(labelForPackage(packageName));
        overlayAppName.setTextSize(18);
        overlayAppName.setTypeface(null, Typeface.BOLD);
        overlayAppName.setTextColor(ORANGE);
        overlayAppName.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(-1, -2);
        ap.setMargins(0, dp(10), 0, 0);
        card.addView(overlayAppName, ap);

        overlayCommand = new TextView(this);
        overlayCommand.setText(commandFor(packageName));
        overlayCommand.setTextSize(15);
        overlayCommand.setTypeface(null, Typeface.BOLD);
        overlayCommand.setTextColor(TEXT);
        overlayCommand.setGravity(Gravity.CENTER);
        overlayCommand.setLineSpacing(0, 1.08f);
        overlayCommand.setPadding(dp(10), dp(10), dp(10), dp(10));
        overlayCommand.setBackground(roundStroke(Color.rgb(18, 10, 0), 18, Color.rgb(70, 40, 0), 1));
        LinearLayout.LayoutParams cmdp = new LinearLayout.LayoutParams(-1, -2);
        cmdp.setMargins(0, dp(14), 0, 0);
        card.addView(overlayCommand, cmdp);

        overlayCountdown = new TextView(this);
        overlayCountdown.setTextSize(43);
        overlayCountdown.setTypeface(null, Typeface.BOLD);
        overlayCountdown.setTextColor(ORANGE);
        overlayCountdown.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
        cp.setMargins(0, dp(12), 0, 0);
        card.addView(overlayCountdown, cp);

        overlaySubtitle = new TextView(this);
        overlaySubtitle.setTextSize(15);
        overlaySubtitle.setTextColor(MUTED);
        overlaySubtitle.setGravity(Gravity.CENTER);
        overlaySubtitle.setLineSpacing(0, 1.08f);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2);
        sp.setMargins(0, dp(6), 0, dp(18));
        card.addView(overlaySubtitle, sp);

        overlayAttempts = new TextView(this);
        overlayAttempts.setTextSize(13);
        overlayAttempts.setTextColor(ORANGE);
        overlayAttempts.setGravity(Gravity.CENTER);
        overlayAttempts.setTypeface(null, Typeface.BOLD);
        LinearLayout.LayoutParams atp = new LinearLayout.LayoutParams(-1, -2);
        atp.setMargins(0, 0, 0, dp(12));
        card.addView(overlayAttempts, atp);

        TextView info = new TextView(this);
        info.setText("Tryb awaryjny: AppBlocker wyrzucił Cię z aplikacji na ekran główny.");
        info.setTextSize(14);
        info.setTextColor(MUTED);
        info.setGravity(Gravity.CENTER);
        info.setPadding(dp(10), dp(12), dp(10), dp(12));
        info.setBackground(roundStroke(Color.rgb(18, 10, 0), 18, Color.rgb(70, 40, 0), 1));
        card.addView(info, new LinearLayout.LayoutParams(-1, -2));

        Button home = new Button(this);
        home.setAllCaps(false);
        home.setText("Zostań na ekranie głównym");
        home.setTextSize(16);
        home.setTextColor(BLACK);
        home.setTypeface(null, Typeface.BOLD);
        home.setPadding(dp(14), dp(12), dp(14), dp(12));
        home.setBackground(round(ORANGE, 16));
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, -2);
        hp.setMargins(0, dp(22), 0, 0);
        card.addView(home, hp);
        home.setOnClickListener(v -> {
            performGlobalAction(GLOBAL_ACTION_HOME);
            hideOverlay();
        });

        updateOverlayCountdown();
        return root;
    }

    private void updateOverlayCountdown() {
        if (overlayView == null || overlayCountdown == null || overlayPackage == null) return;
        long end = endTimeForPackage(overlayPackage);
        long left = Math.max(0, end - System.currentTimeMillis());
        if (left <= 0) {
            hideOverlay();
            return;
        }

        long seconds = left / 1000;
        long hours = seconds / 3600;
        long minutes = (seconds % 3600) / 60;
        long secs = seconds % 60;
        String leftText = hours > 0
                ? String.format(Locale.getDefault(), "%02d:%02d:%02d", hours, minutes, secs)
                : String.format(Locale.getDefault(), "%02d:%02d", minutes, secs);
        overlayCountdown.setText(leftText);

        SimpleDateFormat fmt = new SimpleDateFormat("HH:mm:ss", Locale.getDefault());
        overlaySubtitle.setText("Dostęp wróci automatycznie o " + fmt.format(new Date(end)) + ".");
        if (overlayCommand != null) overlayCommand.setText(commandFor(overlayPackage));
        if (overlayAttempts != null) {
            if (isSpecialLockTarget(overlayPackage)) {
                overlayAttempts.setText(specialStatusForPackage(overlayPackage));
            } else {
                int attempts = Prefs.getAttemptCount(this, overlayPackage);
                long penalty = Prefs.getPenaltyMillis(this, overlayPackage);
                String text = "PRÓBY UCIECZKI: " + attempts;
                if (penalty > 0) text += " · KARA: +" + formatDuration(penalty);
                overlayAttempts.setText(text);
            }
        }
    }

    private String commandFor(String packageName) {
        if (isSettingsPackage(packageName)) return "ROZKAZ: ustawienia są zamknięte do końca wybranego czasu.";
        if (isInstallerPackage(packageName)) return "ROZKAZ: instalowanie nowych aplikacji jest zablokowane.";
        if (isBrowserPackage(packageName)) return "ROZKAZ: przeglądarka zostaje zamknięta. Wracasz do celu.";
        int n = Prefs.getAttemptCount(this, packageName);
        String[] commands = new String[]{
                "ROZKAZ: odkładasz to teraz. Timer nie negocjuje.",
                "Nie ma targowania. Wracasz do celu.",
                "Próba ucieczki zapisana. Dyscyplina zostaje.",
                "Zablokowane znaczy zablokowane. Posłusznie wróć na Home.",
                "Komendant mówi: koniec rozpraszania."
        };
        return commands[Math.abs(n) % commands.length];
    }

    private String formatDuration(long millis) {
        long seconds = Math.max(0, millis / 1000);
        long minutes = seconds / 60;
        long secs = seconds % 60;
        if (minutes >= 60) {
            long hours = minutes / 60;
            long rem = minutes % 60;
            return String.format(Locale.getDefault(), "%02d:%02d:%02d", hours, rem, secs);
        }
        return String.format(Locale.getDefault(), "%02d:%02d", minutes, secs);
    }

    private void hideOverlay() {
        handler.removeCallbacks(overlayTicker);
        if (overlayView != null && windowManager != null) {
            try { windowManager.removeView(overlayView); } catch (Exception ignored) { }
        }
        overlayView = null;
        overlayPackage = "";
    }

    private String getAppName(String pkg) {
        if (pkg == null || pkg.trim().isEmpty()) return "Wybrana aplikacja";
        try {
            PackageManager pm = getPackageManager();
            ApplicationInfo ai = pm.getApplicationInfo(pkg, 0);
            CharSequence label = pm.getApplicationLabel(ai);
            return label == null ? pkg : label.toString();
        } catch (Exception e) {
            return pkg;
        }
    }

    private boolean isNoisePackage(String pkg) {
        return pkg.equals("android")
                || pkg.equals("com.android.systemui")
                || pkg.equals("com.google.android.apps.nexuslauncher")
                || pkg.equals("com.sec.android.app.launcher")
                || pkg.equals("com.miui.home")
                || pkg.equals("com.huawei.android.launcher")
                || pkg.equals("com.oppo.launcher")
                || pkg.equals("com.vivo.launcher");
    }

    private boolean isSpecialLockTarget(String pkg) {
        return (Prefs.isSettingsLockActive(this) && isSettingsPackage(pkg))
                || (Prefs.isInstallLockActive(this) && isInstallerPackage(pkg))
                || (Prefs.isBrowserLockActive(this) && isBrowserPackage(pkg));
    }

    private long endTimeForPackage(String pkg) {
        if (isSettingsPackage(pkg) && Prefs.isSettingsLockActive(this)) return Prefs.getSettingsLockEndTime(this);
        if (isInstallerPackage(pkg) && Prefs.isInstallLockActive(this)) return Prefs.getInstallLockEndTime(this);
        if (isBrowserPackage(pkg) && Prefs.isBrowserLockActive(this)) return Prefs.getBrowserLockEndTime(this);
        return Prefs.getEndTime(this, pkg);
    }

    private String titleForPackage(String pkg) {
        if (isSettingsPackage(pkg)) return "USTAWIENIA ZABLOKOWANE";
        if (isInstallerPackage(pkg)) return "INSTALACJE ZABLOKOWANE";
        if (isBrowserPackage(pkg)) return "PRZEGLĄDARKA ZABLOKOWANA";
        return "APLIKACJA ZABLOKOWANA";
    }

    private String labelForPackage(String pkg) {
        if (isSettingsPackage(pkg)) return "Panel ustawień";
        if (isInstallerPackage(pkg)) return "Sklep / instalator APK";
        if (isBrowserPackage(pkg)) return "Przeglądarka internetowa";
        return getAppName(pkg);
    }

    private String specialStatusForPackage(String pkg) {
        if (isSettingsPackage(pkg)) return "BLOKADA USTAWIEŃ · wygaśnie automatycznie";
        if (isInstallerPackage(pkg)) return "BLOKADA INSTALACJI · wygaśnie automatycznie";
        if (isBrowserPackage(pkg)) return "BLOKADA PRZEGLĄDAREK · wygaśnie automatycznie";
        return "BLOKADA SPECJALNA";
    }

    private boolean isSettingsPackage(String pkg) {
        return pkg != null && (
                pkg.equals("com.android.settings")
                || pkg.equals("com.google.android.settings")
                || pkg.equals("com.miui.securitycenter")
                || pkg.equals("com.miui.permcenter")
                || pkg.equals("com.miui.powerkeeper")
                || pkg.equals("com.lbe.security.miui")
                || pkg.equals("com.miui.securityadd")
        );
    }

    private boolean isInstallerPackage(String pkg) {
        return pkg != null && (
                pkg.equals("com.android.vending")
                || pkg.equals("com.xiaomi.mipicks")
                || pkg.equals("com.mi.global.shop")
                || pkg.equals("com.google.android.packageinstaller")
                || pkg.equals("com.android.packageinstaller")
                || pkg.equals("com.miui.packageinstaller")
                || pkg.equals("com.google.android.permissioncontroller")
                || pkg.equals("com.android.permissioncontroller")
        );
    }

    private boolean isBrowserPackage(String pkg) {
        return pkg != null && (
                pkg.equals("com.android.chrome")
                || pkg.equals("com.chrome.beta")
                || pkg.equals("com.chrome.dev")
                || pkg.equals("org.mozilla.firefox")
                || pkg.equals("org.mozilla.firefox_beta")
                || pkg.equals("com.brave.browser")
                || pkg.equals("com.microsoft.emmx")
                || pkg.equals("com.opera.browser")
                || pkg.equals("com.opera.mini.native")
                || pkg.equals("com.duckduckgo.mobile.android")
                || pkg.equals("com.UCMobile.intl")
                || pkg.equals("com.sec.android.app.sbrowser")
                || pkg.equals("com.mi.globalbrowser")
                || pkg.equals("com.miui.browser")
        );
    }

    private boolean isSafetyPackage(String pkg) {
        return pkg.equals("com.android.settings")
                || pkg.equals("com.google.android.settings")
                || pkg.equals("com.google.android.permissioncontroller")
                || pkg.equals("com.android.permissioncontroller")
                || pkg.equals("com.google.android.packageinstaller")
                || pkg.equals("com.android.packageinstaller");
    }

    private GradientDrawable round(int color, int radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        return d;
    }

    private GradientDrawable roundStroke(int color, int radiusDp, int strokeColor, int strokeDp) {
        GradientDrawable d = round(color, radiusDp);
        d.setStroke(dp(strokeDp), strokeColor);
        return d;
    }

    private GradientDrawable gradient(int start, int end, GradientDrawable.Orientation orientation) {
        GradientDrawable d = new GradientDrawable(orientation, new int[]{start, end});
        d.setCornerRadius(0);
        return d;
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override public void onInterrupt() { }

    @Override public void onDestroy() {
        handler.removeCallbacks(poller);
        hideOverlay();
        super.onDestroy();
    }
}
